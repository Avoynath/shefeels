
import httpx
import asyncio

import requests
from app.services.app_config import get_config_value_from_cache
import tiktoken
from app.api.v1.deps import get_headers_api
import json
import re
from typing import Any, Union

async def generate_chat(url_generate_chat, headers, wait_time, sleep_time_loop):
    """
    Asynchronously polls a chat generation endpoint until completion or timeout.

    Args:
        url_generate_chat (str): The URL to poll for chat generation status/output.
        headers (dict): HTTP headers for the request (e.g., auth).
        wait_time (float): Maximum time (in seconds) to wait for completion.
        sleep_time_loop (float): Time (in seconds) to sleep between polls.

    Returns:
        tuple: (is_chat_generated (bool), response_output (str))
            is_chat_generated: True if chat was generated before timeout, else False.
            response_output: The generated chat output if available, else ''.
    """
    import time
    time_start = time.time()
    response_output = ''
    is_chat_generated = False
    async with httpx.AsyncClient() as client:
        while True:
            response = await client.get(url_generate_chat, headers=headers)
            response_json = response.json()
            status = response_json.get('status')
            print('Status : ', status)
            if status == 'COMPLETED':
                response_output = response_json['output'][0]['choices'][0]['tokens'][0]
                is_chat_generated = True
                break
            time_end = time.time()
            total_time = time_end - time_start
            if total_time > wait_time:
                break
            await asyncio.sleep(sleep_time_loop)
    return is_chat_generated, response_output



async def approximate_token_count(messages: list) -> int:
    """
    Approximate token count for a list of messages (dicts with 'role' and 'content').
    Uses cl100k_base encoding (default for GPT-3.5/4).
    """
    encoding = tiktoken.get_encoding("cl100k_base")
    total_tokens = 0
    for msg in messages:
        total_tokens += len(encoding.encode(msg["content"]))
    
    return total_tokens

async def get_compliance_check(user_prompt: str) -> bool:
    """
    Check if the given text passes compliance using an external API.

    Args:
        user_prompt (str): The text to be checked for compliance.

    Returns:
        bool: True if the text is compliant, False otherwise.
    """
    api_url = await get_config_value_from_cache("COMPLIANCE_API_URL")
    headers = await get_headers_api()
    username = await get_config_value_from_cache("PRIVATE_CLOUD_API_USERNAME")
    payload = {"query": user_prompt, "username": username}
    print(f"Checking compliance for prompt ", api_url, username, payload)
    response = requests.post(api_url, headers=headers, json=payload)
    print(f"Compliance check response: {response.status_code} {response.text}")
    if response.status_code == 200:
        result = response.json()
        print(f"Compliance check result: {result}")
        if result.get("result") == "ok":
            return True, result.get("result")
        else:
            return False, result.get("result")
    return False, "Unknown error"


def parse_story_json(loose_text: str) -> dict:
    """
    Parse a loosely-formatted JSON block where the `story` value contains
    unescaped newlines and quotes. Returns a proper Python dict.
    """
    # --- Extract title ---
    m_title = re.search(r'"title"\s*:\s*"([^"]*)"', loose_text, flags=re.DOTALL)
    if not m_title:
        raise ValueError("Could not find a valid \"title\" field.")
    title = m_title.group(1).strip()

    # --- Extract story (assumed last field before closing brace) ---
    key_idx = loose_text.find('"story"')
    if key_idx == -1:
        raise ValueError("Could not find a valid \"story\" field.")

    colon_idx = loose_text.find(":", key_idx)
    if colon_idx == -1:
        raise ValueError("Malformed story field: missing colon after \"story\".")

    # First quote after the colon begins the raw story text (unescaped)
    start_quote_idx = loose_text.find('"', colon_idx + 1)
    if start_quote_idx == -1:
        raise ValueError("Malformed story field: opening quote not found.")

    # The story is the last quoted string before the final '}'.
    # We find the last quote that occurs before the last closing brace.
    last_brace_idx = loose_text.rfind("}")
    if last_brace_idx == -1:
        raise ValueError("Malformed JSON block: closing brace '}' not found.")

    end_quote_idx = loose_text.rfind('"', 0, last_brace_idx)
    if end_quote_idx == -1 or end_quote_idx <= start_quote_idx:
        raise ValueError("Malformed story field: closing quote not found.")

    story_raw = loose_text[start_quote_idx + 1 : end_quote_idx]

    # Normalize line endings; keep content exactly as provided otherwise.
    # (json.dumps will escape quotes/newlines properly)
    story = story_raw.replace("\r\n", "\n").replace("\r", "\n")

    return {"title": title, "story": story}