from app.api.v1.deps import get_headers_api
from app.services.app_config import get_config_value_from_cache
from app.core.aws_s3 import generate_presigned_url
import urllib.parse
import re
import requests
from typing import Optional
import requests
import base64
from PIL import Image
import io
from app.api.v1.deps import get_headers_api
from app.services.app_config import get_config_value_from_cache
from typing import Optional
import datetime
import aiohttp
import base64
from typing import Optional
import os, re
from pathlib import Path
import json

# You can tweak these defaults to taste.
_DEFAULT_QUALITY_TAGS = (
    "highly detailed, sharp focus, clean edges, coherent anatomy, natural proportions, "
    "consistent identity across the image, no duplicates of the subject"
)

_DEFAULT_NEGATIVES = (
    "lowres, blurry, jpeg artifacts, watermark, text, logo, oversharpen, "
    "deformed, disfigured, extra limbs, extra fingers, fused fingers, missing fingers, "
    "bad hands, bad feet, mutated, out of frame, cropped face, poor lighting"
)
# Load pose prompts from JSON file
pose_prompt_mapping_video = {}
with open("./app/core/pose_prompts.json", "r") as f:
    data = f.read()
    pose_prompt_mapping_video = json.loads(data)
# You can tweak these defaults to taste.
_DEFAULT_QUALITY_TAGS = (
    "highly realistic, highly detailed, sharp focus, masterpiece, highest quality "
    "consistent identity across the image, no duplicates of the subject"
)

_DEFAULT_NEGATIVES = (
    "((watermark)), ((label)), ((text)), ((disfigured)), cartoon, 3d, ((bad art)), ((deformed)), ((extra limbs)), ((b&w)), weird colors, ((chromatic aberration)), blurry, (((duplicate))), ((morbid)), ((mutilated)), [out of frame], extra fingers, mutated hands, ((poorly drawn hands)), ((poorly drawn face)), (((mutation))), ((ugly)), ((bad anatomy)), (((bad proportions))), cloned face, (malformed limbs), ((missing arms)), ((missing legs)), (((extra arms))), (((extra legs))), (fused fingers), (too many fingers), (((long neck))), Photoshop, video game, tiling, cross-eye, body out of frame, gross proportions"
    
)
def _merge_negatives(user_negative: Optional[str]) -> str:
    if not user_negative:
        return _DEFAULT_NEGATIVES
    # De-dupe in a simple, fast way
    base = {t.strip().lower() for t in _DEFAULT_NEGATIVES.split(",")}
    extra = {t.strip().lower() for t in user_negative.split(",")}
    merged = ", ".join(sorted({*base, *extra}))
    return merged

def _clean(value: Optional[str]) -> str:
    return " ".join((value or "").strip().split())

def create_prompt_json(
    character_name: str,
    character_age: int,
    character_gender: str,
    character_style: str,
    character_bio: str,
    character_ethnicity: str,
    character_body_type: str,
    character_eye_colour: str,
    character_hair_style: str,
    character_hair_colour: str,
    character_personality: str,
    character_voice_type: str,
    character_relationship_type: str,
    character_clothing: str,
    character_special_features: str,
    character_background: str,
    character_breast_size: str = "",
    character_butt_size: str = "",
    character_dick_size: str = "",
    positive_prompt: str = "",
    negative_prompt: str = ""
) -> str:
    """
    Create a JSON structure containing all character prompt components.
    This makes it easy to modify specific parts (like pose) during image generation.
    """
    prompt_data = {
        "identity": {
            "name": _clean(character_name),
            "age": character_age,
            "gender": _clean(character_gender),
            "style": _clean(character_style),
            "ethnicity": _clean(character_ethnicity),
            "bio": _clean(character_bio)
        },
        "appearance": {
            "body_type": _clean(character_body_type),
            "breast_size": _clean(character_breast_size),
            "butt_size": _clean(character_butt_size),
            "dick_size": _clean(character_dick_size),
            "eye_colour": _clean(character_eye_colour),
            "hair_style": _clean(character_hair_style),
            "hair_colour": _clean(character_hair_colour)
        },
        "personality": {
            "traits": _clean(character_personality),
            "voice_type": _clean(character_voice_type),
            "relationship_type": _clean(character_relationship_type)
        },
        "clothing": _clean(character_clothing),
        "special_features": _clean(character_special_features),
        "background": _clean(character_background),
        "defaults": {
            "pose": "standing naturally, facing camera",
            "background": "clean uncluttered background",
            "outfit": "casual outfit"
        },
        "prompts": {
            "positive": _clean(positive_prompt),
            "negative": _clean(negative_prompt)
        }
    }
    
    return json.dumps(prompt_data, indent=2)

def build_prompt_from_json(prompt_json: str) -> str:
    """
    Build a complete prompt from stored JSON data, optionally overriding pose, background, or outfit.
    """
    try:
        data = json.loads(prompt_json)
    except json.JSONDecodeError:
        print(f"ERROR: Invalid JSON in stored prompt: {prompt_json[:200]}...")
        return "realistic portrait, high quality"
    
    print("=" * 80)
    print("BUILDING PROMPT FROM STORED JSON:")
    print(f"Original JSON data keys: {list(data.keys())}")
    
    # Extract components
    identity = data.get("identity", {})
    appearance = data.get("appearance", {})
    personality = data.get("personality", {})
    clothing = data.get("clothing", "")
    special_features = data.get("special_features", "")
    background = data.get("background", "")
    defaults = data.get("defaults", {})
    prompts = data.get("prompts", {})
    
    # 1. Identity block with style
    identity_block = f"{identity.get('name', 'character')}, {identity.get('age', 25)}-year-old {identity.get('gender', 'female').lower()}"
    
    if identity.get('style'):
        identity_block += f", {identity.get('style').lower()} style"
        print(f"✅ STYLE FROM JSON: '{identity.get('style')}'")
    else:
        identity_block += ", realistic style"
        print("❌ NO STYLE IN JSON, using fallback 'realistic'")
     
    if identity.get('ethnicity') and identity.get('ethnicity').lower() != "caucasian":
        identity_block += f", {identity.get('ethnicity')}"
    
    if identity.get('bio'):
        identity_block += f", {identity.get('bio')}"
    
    print(f"1. IDENTITY BLOCK: '{identity_block}'")
    prompt_final = f"IDENTITY: '{identity_block}' \n"
    # 2. Physique block
    physique_parts = []
    if appearance.get('body_type'):
        physique_parts.append(f"{appearance.get('body_type').lower()} build")
    
    # Add body size features
    if appearance.get('breast_size') and identity.get('gender', '').lower() == 'female':
        physique_parts.append(f"{appearance.get('breast_size').lower()} breasts")
    if appearance.get('butt_size'):
        physique_parts.append(f"{appearance.get('butt_size').lower()} butt")
    if appearance.get('dick_size') and identity.get('gender', '').lower() == 'male':
        physique_parts.append(f"{appearance.get('dick_size').lower()} penis")
    
    if appearance.get('eye_colour'):
        physique_parts.append(f"{appearance.get('eye_colour').lower()} eyes")
    if appearance.get('hair_colour') and appearance.get('hair_style'):
        physique_parts.append(f"{appearance.get('hair_colour').lower()} {appearance.get('hair_style').lower()} hair")
    elif appearance.get('hair_colour'):
        physique_parts.append(f"{appearance.get('hair_colour').lower()} hair")
    elif appearance.get('hair_style'):
        physique_parts.append(f"{appearance.get('hair_style').lower()} hair")
    
    physique_block = ", ".join(physique_parts)
    
    # Add special features to physique if available
    if special_features:
        physique_block += f", {special_features.lower()}"
    
    print(f"2. PHYSIQUE BLOCK: '{physique_block}'")
    prompt_final += f"PHYSIQUE: '{physique_block}' \n"
    
    # 3. Clothing block (use override or default)
    clothing_block = clothing or defaults.get("outfit", "casual outfit")
    print(f"3. CLOTHING BLOCK: '{clothing_block}'")
    prompt_final += f"CLOTHING: '{clothing_block}' \n"
    # 4. Background block (use override or default)
    background_block = background or defaults.get("background", "urban cityscape")
    print(f"4. BACKGROUND BLOCK: '{background_block}'")
    prompt_final += f"BACKGROUND: '{background_block}' \n"

    # 6. Camera block
    camera_block = "85mm f/1.4, three-quarter portrait"
    print(f"7. CAMERA BLOCK: '{camera_block}'")

    # 8. Quality block
    quality_block = f"cinematic photo, {_DEFAULT_QUALITY_TAGS}"
    if prompts.get('positive'):
        quality_block += f", {prompts.get('positive')}"
    print(f"8. QUALITY BLOCK: '{quality_block}'")
    prompt_final += f"QUALITY: '{quality_block}' \n"
    # Build final prompt
    prompt_parts = [
        identity_block,
        physique_block,
        # clothing_block,
        # pose_block,
        # action_block,
        # accessories_block,
        background_block,
        camera_block,
        quality_block
    ]
    
    final_prompt = ", ".join(part for part in prompt_parts if part.strip())
    ####################
    final_prompt = prompt_final
    ############################
    print("=" * 80)
    print("FINAL PROMPT FROM JSON:")
    print(f"'{final_prompt}'")
    print("=" * 80)
    
    return final_prompt, identity_block, physique_block, clothing_block, background_block, camera_block, quality_block

def modify_character_prompt_for_image_generation(
    original_prompt: str,
    new_outfit: str = "",
    new_pose: str = "",
    new_action: str = "",
    new_accessories: str = "",
    additional_positive: str = ""
) -> str:
    """
    Modify the original character creation prompt for image generation.
    
    Strategy:
    1. Keep the character identity, style, and appearance from original prompt
    2. Replace/modify action/pose, background, and outfit as needed
    3. Add additional positive prompts if provided
    
    This ensures 100% consistency with the original character while allowing
    customization of pose and scene.
    """
    print(f"MODIFYING PROMPT:")
    print(f"  Original: '{original_prompt}'")
    print(f"  New pose: '{new_pose}'")
    print(f"  New accessories: '{new_accessories}'")
    print(f"  New action: '{new_action}'")
    print(f"  New outfit: '{new_outfit}'")
    print(f"  Additional positive: '{additional_positive}'")
    
    # Clean the inputs
    original_prompt = _clean(original_prompt)
    new_pose = _clean(new_pose)
    new_accessories = _clean(new_accessories)
    new_action = _clean(new_action)
    new_outfit = _clean(new_outfit)
    additional_positive = _clean(additional_positive)
    
    if not original_prompt:
        print("  WARNING: Original prompt is empty, using fallback")
        return f"portrait, {new_pose}, {additional_positive}".strip(", ")
    
    # Strategy: Replace action/pose keywords in the original prompt
    # Common action/pose keywords that might appear in character prompts
    pose_keywords = ["kneeling", "Sitting", "Squatting", "Standing", "Stretching"
        ]
    
    # Find and replace pose-related content
    modified_prompt = original_prompt
    
    # If we have a new pose, try to replace existing pose keywords
    # Handle outfit replacement if provided
    if new_outfit:
        outfit_keywords = [ 
            "Jeans", "Jumpsuit", "Leather", "Pajamas", "Satin Robe", "Tank Top"
            ]
        
        outfit_replaced = False
        for keyword in outfit_keywords:
            if keyword.lower() in modified_prompt.lower():
                # Replace the clothing description
                # Try to find pattern like "wearing [something]" and replace the something part
                pattern = re.compile(f"({re.escape(keyword)})[^,]*", re.IGNORECASE)
                modified_prompt = pattern.sub(f"\\1 {new_outfit}", modified_prompt, count=1)
                print(f"  Replaced outfit with '{new_outfit}'")
                outfit_replaced = True
                break
        
        if not outfit_replaced:
            # Append outfit if no existing clothing found
            modified_prompt += f", wearing {new_outfit}"
            print(f"  Appended outfit: 'wearing {new_outfit}'")
    if new_pose:
        # First, try to find and replace specific pose keywords
        for keyword in pose_keywords:
            if keyword.lower() in modified_prompt.lower():
                # Case-insensitive replacement
                pattern = re.compile(re.escape(keyword), re.IGNORECASE)
                modified_prompt = pattern.sub(new_pose, modified_prompt, count=1)
                print(f"  Replaced '{keyword}' with '{new_pose}'")
                break
        else:
            # If no specific pose keyword found, append the new pose
            modified_prompt += f", {new_pose}"
            print(f"  Appended new pose: '{new_pose}'")
    
    # Handle background/environment if provided
    if new_action:
        action_keywords = [
            "Dining", "Playing Soccer", "Swimming", "Tanning", "indoor", "Working Out"
        ]
        
        background_replaced = False
        for keyword in new_action:
            if keyword.lower() in modified_prompt.lower():
                # This is more complex - we'd need more sophisticated parsing
                # For now, just append the new background
                break

        # For simplicity, always append action for now
        modified_prompt += f", {new_action}"
        print(f"  Appended action: '{new_action}'")
    if new_accessories:
        accessories_keywords = [
            "Choker", "Earing", "Hat", "Necklace", "Scarf", "Sunglass", "Tattos"
        ]

        accessories_replaced = False
        for keyword in accessories_keywords:
            if keyword.lower() in modified_prompt.lower():
                # This is more complex - we'd need more sophisticated parsing
                # For now, just append the new background
                break

        # For simplicity, always append action for now
        modified_prompt += f", {new_action}"
        print(f"  Appended action: '{new_action}'")

    # Add additional positive prompts
    if additional_positive:
        modified_prompt += f", {additional_positive}"
        print(f"  Added additional positive: '{additional_positive}'")
    
    # Clean up any double commas or extra spaces
    modified_prompt = re.sub(r',\s*,', ',', modified_prompt)
    modified_prompt = re.sub(r'\s+', ' ', modified_prompt)
    modified_prompt = modified_prompt.strip(", ")
    
    print(f"  FINAL MODIFIED: '{modified_prompt}'")
    return modified_prompt

async def build_image_prompt(
    character_name: str,
    character_age: int,
    character_gender: str,
    character_style: str,
    character_bio: str,
    character_ethnicity: str,
    character_body_type: str,
    character_eye_colour: str,
    character_hair_style: str,
    character_hair_colour: str,
    character_breast_size: str = "",
    character_butt_size: str = "",
    character_special_features: str = "",
    character_clothing: str = "",
    outfit: str = "",
    pose: str = "",
    action: str = "",
    accessories: str = "",
    positive_prompt: str = "",
    negative_prompt: str = "",
    background: str = ""
) -> str:
    """
    Build a robust image-to-image prompt following the Simple Prompting Guide structure:
    [name, age & gender], [physique/face], [clothing], [action/pose], [environment + lighting], [camera/style], [quality tags]

    Notes:
    - Uses character attributes to build consistent identity
    - Follows left-to-right token weighting by placing name/age/gender first
    - Keeps each block to one concept to avoid dilution
    """
    print("=" * 80)
    print("BUILD_IMAGE_PROMPT - INPUT PARAMETERS:")
    print(f"character_name: '{character_name}'")
    print(f"character_age: {character_age}")
    print(f"character_gender: '{character_gender}'")
    print(f"character_style: '{character_style}'")
    print(f"character_bio: '{character_bio}'")
    print(f"character_ethnicity: '{character_ethnicity}'")
    print(f"character_body_type: '{character_body_type}'")
    print(f"character_eye_colour: '{character_eye_colour}'")
    print(f"character_hair_style: '{character_hair_style}'")
    print(f"character_hair_colour: '{character_hair_colour}'")
    print(f"character_breast_size: '{character_breast_size}'")
    print(f"character_butt_size: '{character_butt_size}'")
    print(f"character_special_features: '{character_special_features}'")
    print(f"character_clothing: '{character_clothing}'")
    print(f"pose: '{pose}'")
    print(f"outfit: '{outfit}'")
    print(f"accessories: '{accessories}'")
    print(f"action: '{action}'")
    print(f"positive_prompt: '{positive_prompt}'")
    print(f"negative_prompt: '{negative_prompt}'")
    print("=" * 80)
    
    # Clean inputs
    character_name = _clean(character_name)
    character_style = _clean(character_style)
    character_bio = _clean(character_bio)
    pose = _clean(pose)
    accessories = _clean(accessories)
    action = _clean(action)
    outfit = _clean(outfit)
    positive_prompt = _clean(positive_prompt)
    merged_negatives = _merge_negatives(_clean(negative_prompt))
    
    print("CLEANED INPUTS:")
    print(f"character_name: '{character_name}'")
    print(f"character_style: '{character_style}'")
    print(f"character_bio: '{character_bio}'")
    print(f"pose: '{pose}'")
    print(f"accessories: '{accessories}'")
    print(f"action: '{action}'")
    print(f"outfit: '{outfit}'")
    print(f"positive_prompt: '{positive_prompt}'")
    print(f"merged_negatives: '{merged_negatives}'")
    print("-" * 40)
    
    # 1. Start with fictional name block + STYLE (most important for token weighting)
    identity_block = f"{character_name}, {character_age}-year-old {character_gender.lower()}"
    
    # ADD STYLE RIGHT AFTER NAME AND AGE - CRITICAL FOR ANIME/REALISTIC
    if character_style:
        identity_block += f", {character_style.lower()} style"
        print(f"✅ STYLE ADDED: '{character_style.lower()} style'")
    else:
        print(f"❌ NO STYLE FOUND: character_style is '{character_style}' (empty/null)")
        # FALLBACK: Add default realistic style if no style is provided
        identity_block += f", realistic style"
        print(f"✅ FALLBACK STYLE ADDED: 'realistic style'")
    
    if character_ethnicity and character_ethnicity.lower() != "caucasian":
        identity_block += f", {character_ethnicity}"
    
    # Add bio context if available (important for personality/role)
    if character_bio:
        identity_block += f", {character_bio}"
    
    print(f"1. IDENTITY BLOCK (with STYLE): '{identity_block}'")
    
    # 2. Physique and face features
    physique_parts = []
    
    if character_body_type:
        physique_parts.append(f"{character_body_type.lower()} build")
    
    # Add breast and butt size specifications
    if character_breast_size:
        physique_parts.append(f"{character_breast_size.lower()} breasts")
    
    if character_butt_size:
        physique_parts.append(f"{character_butt_size.lower()} butt")
    
    face_features = []
    if character_eye_colour:
        face_features.append(f"{character_eye_colour.lower()} eyes")
    if character_hair_colour and character_hair_style:
        face_features.append(f"{character_hair_colour.lower()} {character_hair_style.lower()} hair")
    elif character_hair_colour:
        face_features.append(f"{character_hair_colour.lower()} hair")
    elif character_hair_style:
        face_features.append(f"{character_hair_style.lower()} hair")
    
    # Add special features (pregnant, piercings, tattoos, etc.)
    if character_special_features:
        special_features_list = [f.strip().lower() for f in character_special_features.split(',') if f.strip()]
        physique_parts.extend(special_features_list)
    
    # Combine all physique elements
    all_physique_features = physique_parts + face_features
    physique_block = ', '.join(all_physique_features) if all_physique_features else ""
            
    print(f"2. PHYSIQUE BLOCK: '{physique_block}'")
    
    # 3. Clothing - use character's default clothing if no outfit override provided
    if outfit:
        clothing_block = outfit
    elif character_clothing:
        clothing_block = character_clothing
    else:
        clothing_block = "casual outfit"
    
    print(f"3. CLOTHING BLOCK: '{clothing_block}'")
    
    # 4. Pose with specific verb - THIS IS WHERE POSE GOES
    pose_block = pose or "standing naturally, facing camera"
    print(f"4. BLOCK: '{pose_block}'")

    # 4.5. Background - use provided background or default
    if background:
        background_block = background
    else:
        background_block = ""

    # 5. Action/Environment - use action if provided, else default background
    if action:
        action_block = action
    else:
        action_block = "standing in a dynamic pose"
    action_block += ", clean uncluttered background, soft natural lighting, gentle contrast"
    print(f"5. ACTION BLOCK: '{action_block}'")

    # 6. Accessories
    if accessories:
        accessories_block = f", wearing {accessories.lower()}"
    else:
        accessories_block = "no accessories"
    print(f"6. ACCESSORIES ADDED: '{accessories_block.lower()}'")
    
    # 7. Camera and style - specific lens for perspective
    camera_block = "85mm f/1.4, three-quarter portrait"
    print(f"6. CAMERA BLOCK: '{camera_block}'")
    
    # 8. Quality tags - PRESERVE ANIME/REALISTIC STYLE FROM POSITIVE_PROMPT
    quality_block = f"cinematic photo, {_DEFAULT_QUALITY_TAGS}"
    if positive_prompt:
        # Ensure anime/realistic attributes are preserved
        quality_block += f", {positive_prompt}"

    print(f"8. QUALITY BLOCK: '{quality_block}'")

    # Construct prompt following the guide structure
    prompt_parts = [
        identity_block,
        physique_block,
        clothing_block,
        pose_block,
        action_block,
        accessories_block,
        camera_block,
        quality_block
    ]
    
    # Filter out empty parts and join
    prompt = ", ".join(part for part in prompt_parts if part.strip())
    
    print("=" * 80)
    print("FINAL ASSEMBLED PROMPT:")
    print(f"'{prompt}'")
    print("=" * 80)
    
    return prompt

async def fetch_image_as_base64(s3_image_url: str) -> str:
    """
    Download an image from the given presigned S3 URL and return its base64 string.

    Args:
        s3_image_url (str): Presigned URL of the S3 image.

    Returns:
        str: Base64-encoded string of the image.

    Raises:
        ValueError: If the request fails or returns a non-200 status.
    """
    # Accept either:
    # - A full presigned HTTP URL
    # - An S3 key like "image/u/123/.../file.png"
    # - A s3://bucket/key style URL
    url = s3_image_url or ""

    # If this looks like an s3 key (no scheme, no host) we need to generate a presigned URL
    parsed = urllib.parse.urlparse(url)

    # If scheme is empty and there's no netloc, treat as s3 key
    if not parsed.scheme and not parsed.netloc:
        # generate presigned url using the key
        try:
            url = await generate_presigned_url(url)
        except Exception as e:
            raise ValueError(f"Failed to generate presigned URL for s3 key: {e}")

    # If scheme is s3://bucket/key -> extract key and generate presigned url
    if parsed.scheme == "s3":
        # parsed.netloc is the bucket, parsed.path is the key
        s3_key = parsed.path.lstrip("/")
        try:
            url = await generate_presigned_url(s3_key)
        except Exception as e:
            raise ValueError(f"Failed to generate presigned URL for s3 url: {e}")

    # Now url should be an HTTP(s) URL we can fetch
    async with aiohttp.ClientSession() as session:
        try:
            async with session.get(url) as response:
                if response.status != 200:
                    raise ValueError(f"Failed to fetch image, status: {response.status}")
                image_bytes = await response.read()
                base64_str = base64.b64encode(image_bytes).decode("utf-8")
                return base64_str
        except aiohttp.client_exceptions.InvalidURL as e:
            raise ValueError(f"Invalid URL provided for image fetch: {url}")

async def face_swap(source_image_base64: str, target_image_base64: str) -> requests.Response:
    """
    Perform face swap using the external API.
    
    Args:
        source_image_base64: Base64 string of the source image (character's original face)
        target_image_base64: Base64 string of the target image (newly generated image)
        
    Returns:
        requests.Response: The response from the face swap API
    """
    face_swap_url = "https://api.lightspeedcloud.ai/api/v1/image/faceswap"
    username = await get_config_value_from_cache("PRIVATE_CLOUD_API_USERNAME")
    headers = await get_headers_api()
    
    print(f"FACE_SWAP API CALL:")
    print(f"URL: {face_swap_url}")
    print(f"Username: {username}")
    print(f"Source image length: {len(source_image_base64)} chars")
    print(f"Target image length: {len(target_image_base64)} chars")
    
    data = {
        "source_image": source_image_base64,
        "target_image": target_image_base64,
        "username": username
    }
    
    try:
        response = requests.post(face_swap_url, headers=headers, json=data)
        print(f"Face swap API response status: {response.status_code}")
        
        if response.status_code == 200:
            response_json = response.json()
            print(f"Face swap successful, response keys: {list(response_json.keys())}")
            if "data" in response_json and "image_data" in response_json["data"]:
                result_length = len(response_json["data"]["image_data"])
                print(f"Face swapped image length: {result_length} chars")
        else:
            print(f"Face swap failed with status {response.status_code}")
            print(f"Response content: {response.text[:500]}...")
            
        return response
        
    except Exception as e:
        print(f"Face swap API error: {e}")
        # Create a mock response object for consistency
        class MockResponse:
            def __init__(self):
                self.status_code = 500
                
            def json(self):
                return {"error": str(e)}
                
        return MockResponse()

async def detect_video_effect_from_prompt(prompt, lora_effects=None):
    """Use chat API to intelligently detect video effect from user prompt"""
    
    # Get effects list from the passed lora_effects or use default
    if lora_effects:
        effects_list = list(lora_effects.keys())
    else:
        effects_list = [
            "deepthroat", "missionary", "cowgirl", "blowjob", "doggystyle", 
            "reverse_cowgirl", "anal", "cumshot", "fingering", "facials",
            "tit_fuck", "foot_job", "scissoring", "kiss", "squirt",
            "matrix_shot", "rotation", "orbit", "squish", "inflate"
        ]
    
    try:
        # Use existing chat API to analyze prompt
        chat_api_url = await get_config_value_from_cache("CHAT_API_URL")
        headers = await get_headers_api()
        
        analysis_prompt = f"""
        Analyze this user prompt and determine which adult video position/action or camera effect it describes.
        Return ONLY a JSON response with this exact format:
        {{"effect": "effect_name", "confidence": 0.85}}
        
        Available effects: {', '.join(effects_list)}
        
        User prompt: "{prompt}"
        
        Rules:
        - If the prompt clearly describes one of the available effects, return that effect name
        - Handle typos and variations (e.g., "misionary" -> "missionary", "doggy" -> "doggystyle", "anal" -> "anal")
        - For camera effects: "bullet time" -> "matrix_shot", "spin" -> "rotation", "circle camera" -> "orbit"
        - If unsure or no match, return "effect": null
        - Confidence should be 0.0 to 1.0
        - Return ONLY the JSON, no other text
        """
        
        payload = {
            "messages": [{"role": "user", "content": analysis_prompt}],
            "model": "gpt-4",
            "temperature": 0.1,
            "max_tokens": 100
        }
        
        response = requests.post(chat_api_url, headers=headers, json=payload, timeout=10)
        
        if response.status_code == 200:
            result = response.json()
            content = result.get("choices", [{}])[0].get("message", {}).get("content", "")
            
            # Parse JSON response
            import json
            try:
                parsed = json.loads(content.strip())
                effect = parsed.get("effect")
                confidence = parsed.get("confidence", 0.0)
                
                # Validate effect exists and confidence is reasonable
                if effect in effects_list and confidence > 0.6:
                    return effect
                    
            except json.JSONDecodeError:
                pass
                
    except Exception as e:
        print(f"Error in trigger detection: {e}")
    
    # Enhanced fallback: comprehensive keyword matching
    prompt_lower = prompt.lower()
    
    # Comprehensive keyword mapping with variations and typos
    keyword_mapping = {
        "deepthroat": ["deepthroat", "deep throat", "dt", "d33pthr0at", "throating", "deep oral"],
        "missionary": ["missionary", "misionary", "mish", "m1ss10n4ry", "face to face", "on top of"],
        "cowgirl": ["cowgirl", "cow girl", "riding", "c0wg1rl", "woman on top", "girl on top"],
        "blowjob": ["blowjob", "blow job", "bj", "oral", "bl0wj0b", "sucking", "fellatio"],
        "doggystyle": ["doggystyle", "doggy", "doggie", "d0ggyst7le", "from behind", "rear entry"],
        "reverse_cowgirl": ["reverse cowgirl", "reverse", "r3v3rs3c0wg1rl", "backwards riding"],
        "anal": ["anal", "4n4l", "butt", "ass", "backdoor", "rear penetration"],
        "cumshot": ["cumshot", "cum shot", "cumsh0t", "climax", "finish", "orgasm"],
        "fingering": ["fingering", "finger", "f1ng3r1ng", "manual", "hand action"],
        "facials": ["facial", "facials", "f4c14ls", "face finish", "cum on face"],
        "tit_fuck": ["tit fuck", "titfuck", "t1tf0ck", "breast", "boob job", "titty fuck"],
        "foot_job": ["foot job", "footjob", "f00tj0b", "feet", "foot play"],
        "scissoring": ["scissoring", "scissor", "sc1ss0r1ng", "grinding", "tribbing"],
        "kiss": ["kiss", "kissing", "k1ss", "making out", "smooch"],
        "squirt": ["squirt", "squirting", "squ1rt", "female ejaculation", "gushing"],
        "matrix_shot": ["matrix", "bullet time", "b4ll3t t1m3", "slow motion", "time freeze"],
        "rotation": ["rotation", "rotate", "r0t4tion", "spin", "spinning", "360"],
        "orbit": ["orbit", "0rb4it", "circle", "circling", "around", "camera orbit"],
        "squish": ["squish", "squeeze", "sq41sh", "compress", "pressing"],
        "inflate": ["inflate", "expansion", "infl4t3", "blow up", "balloon"]
    }
    
    # Score-based matching for better accuracy
    effect_scores = {}
    
    for effect, keywords in keyword_mapping.items():
        score = 0
        for keyword in keywords:
            if keyword in prompt_lower:
                # Weight longer, more specific keywords higher
                weight = len(keyword.split()) * 2 + len(keyword)
                score += weight
        
        if score > 0:
            effect_scores[effect] = score
    
    # Return the effect with the highest score if above threshold
    if effect_scores:
        best_effect = max(effect_scores, key=effect_scores.get)
        best_score = effect_scores[best_effect]
        
        # Require minimum score to avoid false positives
        if best_score >= 5:  # Adjust threshold as needed
            return best_effect
                
    return None

async def generate_video(prompt, duration, video_effect, negative_prompt, image_url=None, character_data=None):
    """Generate video with LoRA effects and proper character integration"""
    # Lightly refine the user's prompt using the chat endpoint to fix grammar/spelling
    # without changing the meaning or adding extra content.
    try:
        refined = await refine_user_prompt_with_chat(prompt)
        if refined and isinstance(refined, str) and refined.strip():
            print(f"Prompt refined from: '{prompt}' to: '{refined}'")
            prompt = refined
    except Exception as e:
        print(f"Prompt refinement failed, proceeding with original prompt. Error: {e}")
    
    # Comprehensive LoRA effects mapping with proper trigger phrases from the guide
    LORA_EFFECTS = {
        # Sexual position LoRAs
        "deepthroat": {
            "trigger": "d33pthr0at",
            "description": "intense deepthroat action with dynamic movement",
            "template": "The video opens with {subject}. As the scene progresses, d33pthr0at deepthroat action begins with passionate intensity and rhythmic movement."
        },
        "missionary": {
            "trigger": "m1ss10n4ry",
            "description": "intimate missionary position with face-to-face connection",
            "template": "The video starts with {subject} in an intimate setting. The scene transitions to m1ss10n4ry missionary position with passionate face-to-face connection."
        },
        "cowgirl": {
            "trigger": "c0wg1rl",
            "description": "woman on top position with dynamic riding motion",
            "template": "The video begins with {subject} positioned intimately. The action shifts to c0wg1rl cowgirl position with rhythmic riding movements."
        },
        "blowjob": {
            "trigger": "bl0wj0b",
            "description": "oral pleasure scene with intimate focus",
            "template": "The video opens with {subject} in a seductive pose. The scene develops into bl0wj0b oral action with passionate technique."
        },
        "doggystyle": {
            "trigger": "d0ggyst7le",
            "description": "rear entry position with powerful movements",
            "template": "The video starts with {subject} positioned invitingly. The action transitions to d0ggyst7le doggystyle with passionate rear entry motion."
        },
        "reverse_cowgirl": {
            "trigger": "r3v3rs3c0wg1rl",
            "description": "reverse woman on top position with dynamic movement",
            "template": "The video begins with {subject} in position. The scene shifts to r3v3rs3c0wg1rl reverse cowgirl with rhythmic bouncing motion."
        },
        "anal": {
            "trigger": "4n4l",
            "description": "anal penetration with careful movements",
            "template": "The video opens with {subject} positioned for intimacy. The action progresses to 4n4l anal penetration with gentle yet passionate movements."
        },
        "cumshot": {
            "trigger": "cumsh0t",
            "description": "climactic finish with explosive release",
            "template": "The video builds with {subject} in passionate action. The scene culminates in cumsh0t explosive climax with intense release."
        },
        "fingering": {
            "trigger": "f1ng3r1ng",
            "description": "manual stimulation with skillful movements",
            "template": "The video starts with {subject} in a sensual pose. The action develops into f1ng3r1ng fingering with skillful manual technique."
        },
        "facials": {
            "trigger": "f4c14ls",
            "description": "facial finish with intense climax",
            "template": "The video progresses with {subject} in passionate action. The scene culminates in f4c14ls facial finish with explosive intensity."
        },
        # Camera/Effect LoRAs
        "matrix_shot": {
            "trigger": "b4ll3t t1m3",
            "description": "bullet time camera effect with dramatic slow motion",
            "template": "A high-action scene with {subject} is captured with b4ll3t t1m3 bullet time shot; action is dramatically slowed, freezing the moment while the camera circles around."
        },
        "rotation": {
            "trigger": "r0t4tion",
            "description": "360-degree rotation effect",
            "template": "The video shows {subject}. {subject} performs a r0t4tion 360 degrees rotation, spinning fully around with smooth motion."
        },
        "orbit": {
            "trigger": "0rb4it",
            "description": "360-degree camera orbit around subject",
            "template": "A camera performs an 0rb4it 360 degree orbit around {subject}, circling smoothly and showing the subject from all angles."
        },
        "squish": {
            "trigger": "sq41sh",
            "description": "squish effect with compression",
            "template": "In the video, {subject} is presented. External pressure causes a sq41sh squish effect, creating dynamic compression movements."
        },
        "inflate": {
            "trigger": "infl4t3",
            "description": "inflation effect with expansion",
            "template": "{subject} is shown, then infl4t3 inflates it, causing {subject} to expand like a balloon with realistic physics."
        },
        # Additional adult LoRAs
        "tit_fuck": {
            "trigger": "t1tf0ck",
            "description": "breast stimulation action",
            "template": "The video opens with {subject} positioned seductively. The action develops into t1tf0ck breast action with rhythmic movements."
        },
        "foot_job": {
            "trigger": "f00tj0b",
            "description": "foot stimulation technique",
            "template": "The video starts with {subject} in a playful pose. The scene transitions to f00tj0b foot action with skillful technique."
        },
        "scissoring": {
            "trigger": "sc1ss0r1ng",
            "description": "intimate female-female interaction",
            "template": "The video begins with {subject} in intimate positioning. The action develops into sc1ss0r1ng scissoring with passionate grinding motion."
        },
        "kiss": {
            "trigger": "k1ss",
            "description": "passionate kissing action",
            "template": "The video opens with {subject} in a romantic setting. The scene develops into k1ss passionate kissing with intimate connection."
        },
        "squirt": {
            "trigger": "squ1rt",
            "description": "female climax with fluid release",
            "template": "The video builds with {subject} in intense pleasure. The scene culminates in squ1rt explosive female climax with fluid release."
        }
    }
    
    # Smart trigger detection if no explicit video_effect provided
    if not video_effect and prompt:
        detected_effect = await detect_video_effect_from_prompt(prompt, LORA_EFFECTS)
        if detected_effect:
            video_effect = detected_effect
            print(f"Detected video effect from prompt: {video_effect}")
    
    # Build character-aware prompt with proper LoRA structure
    enhanced_prompt = await build_lora_prompt(prompt, video_effect, character_data, LORA_EFFECTS)
    
    # Ensure we have a character image for image-to-video generation
    if not image_url and character_data:
        # Try to get image from character data
        for key in ['image_url_s3', 'image_url', 'img', 'character_image']:
            if character_data.get(key):
                image_url = character_data[key]
                break
    
    if not image_url:
        raise ValueError("Character image is required for video generation")
    
    apiurl = await get_config_value_from_cache("VIDEO_GEN_URL")
    headers = await get_headers_api()
    username = await get_config_value_from_cache("PRIVATE_CLOUD_API_USERNAME")

    # Enhanced negative prompts for video generation
    enhanced_negative = await build_enhanced_negative_prompt(negative_prompt, video_effect)

    # Prepare API payload for lightspeedcloud.ai with mandatory image_url
    # Note: video_effect is omitted since it's optional and we handle effects via LoRA prompts
    data = {
        "prompt": enhanced_prompt,
        "duration": duration,
        "negative_prompt": enhanced_negative,
        "image_url": image_url,  # Always required for character video generation
        "username": username
    }
    
    print(f"Generating video with LoRA effect: {video_effect}, API payload (no video_effect), image_url: {image_url}")
    print(f"Enhanced prompt: {enhanced_prompt}")
    print(f"API URL: {apiurl}")
    print(f"Payload: {data}")
    
    try:
        response = requests.post(apiurl, headers=headers, json=data, timeout=300)
        print(f"✅ API Response Status: {response.status_code}")
        if response.status_code != 200:
            print(f"❌ API Error Response: {response.text}")
        else:
            print(f"✅ API Success Response: {response.text[:200]}...")
        return response
    except requests.exceptions.Timeout:
        print(f"❌ Timeout error when calling {apiurl} (300s timeout)")
        raise
    except requests.exceptions.RequestException as e:
        print(f"❌ Request error when calling {apiurl}: {e}")
        raise
    except Exception as e:
        print(f"❌ Unexpected error during video generation: {e}")
        raise

async def build_enhanced_negative_prompt(base_negative, video_effect):
    """Build enhanced negative prompts based on video effect type"""
    
    # Base negative prompts for video generation
    base_negatives = [
        "low quality", "blurry", "pixelated", "artifacts", "distorted", "deformed",
        "bad anatomy", "extra limbs", "missing limbs", "disfigured face", 
        "bad hands", "extra fingers", "missing fingers", "unnatural proportions",
        "inconsistent lighting", "choppy motion", "frame drops", "stuttering",
        "watermark", "text", "logo", "signature"
    ]
    
    # Effect-specific negative prompts
    effect_negatives = {
        "matrix_shot": ["motion blur", "camera shake", "unstable rotation"],
        "rotation": ["wobbly rotation", "uneven spinning", "axis drift"],
        "orbit": ["jerky camera movement", "uneven orbit", "focus loss"],
        "squish": ["unnatural deformation", "geometric distortion"],
        "inflate": ["unrealistic expansion", "texture stretching"],
        "deepthroat": ["unrealistic anatomy", "impossible positioning"],
        "missionary": ["floating bodies", "gravity defiance"],
        "cowgirl": ["unnatural bouncing", "physics violations"],
        "blowjob": ["anatomical impossibilities", "unrealistic scale"],
        "doggystyle": ["impossible angles", "floating limbs"],
        "anal": ["unrealistic anatomy", "impossible positioning"],
        "cumshot": ["unrealistic fluid physics", "floating elements"],
        "fingering": ["extra fingers", "impossible hand positions"],
        "facials": ["unrealistic fluid behavior", "gravity defiance"]
    }
    
    # Combine negatives
    combined_negatives = base_negatives.copy()
    
    # Add user's negative prompts
    if base_negative:
        user_negatives = [n.strip() for n in base_negative.split(",") if n.strip()]
        combined_negatives.extend(user_negatives)
    
    # Add effect-specific negatives
    if video_effect and video_effect in effect_negatives:
        combined_negatives.extend(effect_negatives[video_effect])
    
    # Remove duplicates and join
    unique_negatives = list(dict.fromkeys(combined_negatives))  # Preserves order
    return ", ".join(unique_negatives)

async def build_lora_prompt(base_prompt, video_effect, character_data, lora_effects):
    """Build simple LoRA prompt with trigger word and refined user prompt"""
    
    # Start with trigger word if effect exists
    if video_effect and video_effect in lora_effects:
        effect_data = lora_effects[video_effect]
        trigger = effect_data.get("trigger", "")
        
        if trigger:
            # Simple format: trigger word + refined user prompt
            if base_prompt and base_prompt.strip():
                return f"{trigger}, {base_prompt.strip()}"
            else:
                return trigger
    
    # Fallback: just user prompt
    if base_prompt and base_prompt.strip():
        return base_prompt.strip()
    
    return "beautiful woman"


# Enhanced negative prompt building
    
    if base_prompt and base_prompt.strip():
        context_parts.append(base_prompt.strip())
    
    context_parts.append("with cinematic quality and realistic movement")
    
    final_prompt = ", ".join(context_parts)
    return final_prompt

async def enhance_prompt(prompt):
    try :
        url = await get_config_value_from_cache("PROMPT_ENHANCE_URL")
        username = await get_config_value_from_cache("PRIVATE_CLOUD_API_USERNAME")
        payload = { "query" : prompt, "username": username}
        headers = await get_headers_api()
        response = requests.post(url=url, headers=headers, json=payload)
        json_resp = response.json()
        if json_resp["status"].lower() == "success" :
            enhanced_prompt = json_resp["data"]["prompt"]
        return enhanced_prompt
    except:
        return prompt


async def refine_user_prompt_with_chat(prompt: str) -> str:
    """Use the configured chat endpoint to perform a light, conservative rewrite of the
    user's prompt to fix spelling, grammar, punctuation and make it concise while
    preserving meaning and intent. Returns the refined prompt or the original on error.

    The chat API is expected to follow a ChatCompletion-style contract where
    POSTing {"messages": [...], "model": "gpt-4"} returns a JSON with
    choices[0].message.content containing the assistant reply.
    """
    if not prompt or not isinstance(prompt, str):
        return prompt

    try:
        chat_api_url = await get_config_value_from_cache("CHAT_API_URL")
        headers = await get_headers_api()

        instruction = (
            "Please rewrite the user prompt to correct grammar, spelling, and punctuation. "
            "Be concise and do not change the meaning, intent, or any specific keywords. "
            "Return only the rewritten prompt text, no commentary."
        )

        payload = {
            "messages": [
                {"role": "system", "content": "You are a helpful assistant that lightly edits user prompts."},
                {"role": "user", "content": instruction + "\n\nUser prompt: \"" + prompt + "\""}
            ],
            "model": "gpt-4",
            "temperature": 0.0,
            "max_tokens": 200
        }

        # Use a short timeout to avoid blocking video generation excessively
        response = requests.post(chat_api_url, headers=headers, json=payload, timeout=8)
        if response.status_code == 200:
            result = response.json()
            content = result.get("choices", [{}])[0].get("message", {}).get("content", "")
            refined = content.strip()
            # If the model returns JSON or wrapper text, try to extract the first line
            if "\n" in refined:
                # Prefer single-line concise prompt
                first_line = refined.splitlines()[0].strip()
                if first_line:
                    refined = first_line
            # Heuristic: don't return something much longer than original
            if refined and len(refined) <= max(len(prompt) * 3, 1000):
                return refined

    except Exception as e:
        print(f"Prompt refinement error: {e}")

    return prompt

async def enhance_prompt_video(prompt):
    try :
        url = await get_config_value_from_cache("VIDEO_GEN_PROMPT_ENHANCE")
        username = await get_config_value_from_cache("PRIVATE_CLOUD_API_USERNAME")
        payload = { "query" : prompt, "username": username}
        headers = await get_headers_api()
        response = requests.post(url=url, headers=headers, json=payload)
        json_resp = response.json()
        if json_resp["status"].lower() == "success" :
            enhanced_prompt = json_resp["data"]["prompt"]
        return enhanced_prompt
    except:
        return prompt

async def generate_image(prompt, num_images, initial_image, size_orientation, ai_model):
    apiurl = await get_config_value_from_cache("IMAGE_GEN_URL")
    #ai_model = await get_config_value_from_cache("IMAGE_GEN_MODEL")
    weight = await get_config_value_from_cache("IMAGE_GEN_WEIGHT")
    steps = await get_config_value_from_cache("IMAGE_GEN_STEPS")
    cfg_scale = await get_config_value_from_cache("IMAGE_GEN_CFG_SCALE")
    positive_prompt = await get_config_value_from_cache("IMAGE_GEN_POSITIVE_PROMPT")
    negative_prompt = await get_config_value_from_cache("IMAGE_GEN_NEGATIVE_PROMPT")
    username = await get_config_value_from_cache("PRIVATE_CLOUD_API_USERNAME")

    headers = await get_headers_api()
    print('Headers:', headers)
    data = {"query" : prompt,
            "num_images" : num_images,
            "ai_model" : ai_model,
            "size" : size_orientation,
            "initial_image" : initial_image,
            "weight" : weight,
            "pos_prompt" : positive_prompt,
            "neg_prompt" : negative_prompt,
            "steps" : steps,
            "cfg_scale" : cfg_scale,
            "username" : username 
            }
    #print('Image Generation Payload:', data)
    response = requests.post(apiurl, headers = headers, json=data)
    print('Image Generation Response:', response.status_code)
    return response

def save_image_to_local_storage(image_data_str, filepath):
    """
    Save base64 image data to a local file.

    Parameters
    ----------
    image_data : bytes
        The binary image data to save.
    file_path : str
        The path where the image will be saved.
    """
    image_data = base64.b64decode(image_data_str)
    image = Image.open(io.BytesIO(image_data))

    image.save(filepath)  # Save as
    print(f"Image saved to {filepath}")

async def generate_filename_timestamped(username: str) -> str:
    safe_username = username.replace(" ", "_").lower()
    # Use microseconds (%f), then truncate to milliseconds
    timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S_%f")[:-3]
    filename = f"{safe_username}_{timestamp}"
    return filename


async def build_character_prompt_and_json(
    name: str,
    bio: Optional[str],
    gender: str,
    style: Optional[str] = "Realistic",
    ethnicity: Optional[str] = "Caucasian",
    age: Optional[int] = 18,
    eye_colour: Optional[str] = "Black",
    hair_style: Optional[str] = "Curly",
    hair_colour: Optional[str] = "Black",
    body_type: Optional[str] = "Fit",
    breast_size: Optional[float] = "Medium",
    butt_size: Optional[float] = "Medium",
    dick_size: Optional[str] = "Average",
    personality: Optional[str] = "Caregiver",
    voice_type: Optional[str] = "Naughty",
    relationship_type: Optional[str] = "Friend",
    clothing: Optional[str] = "Hoodie",
    special_features: Optional[str] = "Tattoos",
    background: Optional[str] = "Cityscape",
    positive_prompt: Optional[str] = "--Ultra-detailed, 8K resolution, cinematic lighting",
    negative_prompt: Optional[str] = "--no blur,--no watermark,--no extra limbs,--no distortion."
) -> tuple[str, str]:
    """
    Generate both text prompt and JSON for character creation.
    Returns: (text_prompt, prompt_json)
    """
    print("=" * 80)
    print("BUILDING CHARACTER CREATION PROMPT (WITH JSON STORAGE)")
    print(f"name: '{name}', style: '{style}', age: {age}")
    print("=" * 80)
    
    # Create JSON structure for future use (this will be stored in database)
    prompt_json = create_prompt_json(
        character_name=name,
        character_age=age or 18,
        character_gender=gender,
        character_style=style or "realistic",
        character_bio=bio or "",
        character_ethnicity=ethnicity or "",
        character_body_type=body_type or "",
        character_eye_colour=eye_colour or "",
        character_hair_style=hair_style or "",
        character_hair_colour=hair_colour or "",
        character_personality=personality or "",
        character_voice_type=voice_type or "",
        character_relationship_type=relationship_type or "",
        character_clothing=clothing or "",
        character_special_features=special_features or "",
        character_background=background or "",
        character_breast_size=breast_size or "",
        character_butt_size=butt_size or "",
        character_dick_size=dick_size or "",
        positive_prompt=positive_prompt or "",
        negative_prompt=negative_prompt or ""
    )
    
    # Build the actual prompt from JSON (for character creation)
    text_prompt,identity_block, physique_block, clothing_block, background_block, camera_block, quality_block = build_prompt_from_json(prompt_json)
    
    print(f"CHARACTER CREATION - FINAL TEXT PROMPT: '{text_prompt}'")
    print("=" * 80)
    
    return text_prompt, prompt_json, identity_block, physique_block, clothing_block, background_block, camera_block, quality_block

async def build_character_prompt(
    name: str,
    bio: Optional[str],
    gender: str,
    style: Optional[str] = "Realistic",
    ethnicity: Optional[str] = "Caucasian",
    age: Optional[int] = 18,
    eye_colour: Optional[str] = "Black",
    hair_style: Optional[str] = "Curly",
    hair_colour: Optional[str] = "Black",
    body_type: Optional[str] = "Fit",
    breast_size: Optional[float] = "Medium",
    butt_size: Optional[float] = "Medium",
    dick_size: Optional[str] = "Average",
    personality: Optional[str] = "Caregiver",
    voice_type: Optional[str] = "Naughty",
    relationship_type: Optional[str] = "Friend",
    clothing: Optional[str] = "Hoodie",
    special_features: Optional[str] = "Tattoos",
    positive_prompt: Optional[str] = "--Ultra-detailed, 8K resolution, cinematic lighting",
    negative_prompt: Optional[str] = "--no blur,--no watermark,--no extra limbs,--no distortion."
) -> str:
    """
    Generate a high-quality character prompt for Flux-style image generation.
    This function maintains backward compatibility by returning just the text prompt.
    """
    text_prompt, _ = await build_character_prompt_and_json(
        name, bio, gender, style, ethnicity, age, eye_colour, hair_style, 
        hair_colour, body_type, breast_size, butt_size, dick_size, 
        personality, voice_type, relationship_type, clothing, special_features,
        positive_prompt, negative_prompt
    )
    return text_prompt


# map content types to preferred extensions
CT_TO_EXT = {
    "image/jpeg": ".jpeg",
    "image/jpg":  ".jpg",    # in case a sender uses this ctype
    "image/png":  ".png",
    "image/webp": ".webp",
    "image/gif":  ".gif",
}

def _sanitize_filename(name: str) -> str:
    # your existing sanitize_filename is fine; keep it if you prefer
    name = os.path.basename(name or "")
    # allow alnum . _ - only
    return "".join(ch if ch.isalnum() or ch in "._-" else "_" for ch in name) or "upload"

def _normalize_ext(filename: str, content_type: str | None) -> tuple[str, str]:
    """
    Returns (stem, ext) with a clean extension.
    Prefers content_type; falls back to filename suffix.
    """
    safe_name = _sanitize_filename(filename or "image")
    p = Path(safe_name)
    stem = p.stem or "image"
    # pick by content-type first
    ext = CT_TO_EXT.get((content_type or "").lower(), None)
    if not ext:
        # fallback to filename's suffix if present and plausible
        suffix = p.suffix.lower()
        if suffix in {".jpeg", ".jpg", ".png", ".webp", ".gif"}:
            ext = suffix
        else:
            # default if no usable hint
            ext = ".jpeg"
    return stem, ext

async def generate_video_ai_editor(prompt, duration, video_effect, negative_prompt, image_url=None, character_data=None):
    """Generate video with LoRA effects and proper character integration"""
    if video_effect:
        print("video effect selected by user : ", video_effect)
        prompt_pose = pose_prompt_mapping_video[video_effect]
        enhanced_prompt = prompt + '\\n\\n' + prompt_pose

    print('Final prompt : ', enhanced_prompt)

    # Enhanced negative prompts for video generation (character-aware)
    #enhanced_negative = await build_enhanced_negative_prompt(negative_prompt, video_effect)
    apiurl = await get_config_value_from_cache("VIDEO_GEN_URL")
    headers = await get_headers_api()
    username = await get_config_value_from_cache("PRIVATE_CLOUD_API_USERNAME")

    # Prepare API payload for lightspeedcloud.ai with mandatory image_url
    # Note: video_effect is omitted since it's optional and we handle effects via LoRA prompts
    data = {
        "prompt": enhanced_prompt,
        "duration": duration,
        "negative_prompt": negative_prompt or "",
        "username": username
    }
    # Include image_url only when present (image-to-video). For text-only flows
    # lightspeed's endpoint supports prompt-only generation if image_url is omitted.
    if image_url:
        data['image_url'] = image_url
    
    print(f"Enhanced prompt: {enhanced_prompt}")
    print(f"API URL: {apiurl}")
    print(f"Payload: {data}")
    
    try:
        response = requests.post(apiurl, headers=headers, json=data, timeout=300)
        print(f"✅ API Response Status: {response.status_code}")
        if response.status_code != 200:
            print(f"❌ API Error Response: {response.text}")
        else:
            print(f"✅ API Success Response: {response.text[:200]}...")
        return response
    except requests.exceptions.Timeout:
        print(f"❌ Timeout error when calling {apiurl} (300s timeout)")
        raise
    except requests.exceptions.RequestException as e:
        print(f"❌ Request error when calling {apiurl}: {e}")
        raise
    except Exception as e:
        print(f"❌ Unexpected error during video generation: {e}")
        raise