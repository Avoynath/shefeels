import os
import io
import base64
import httpx
import asyncio
import logging
import sys
from fastapi import HTTPException
from typing import Optional
from app.services.app_config import get_config_value_from_cache
from app.api.v1.deps import get_headers_api
from app.core.aws_s3 import get_s3_client, generate_presigned_url
from app.services.voice import store_voice_to_s3
from app.models.chat import ChatMessage
from app.models.character import Character
from app.services.chat import approximate_token_count
from app.core.database import AsyncSessionLocal


async def _download_url_as_bytes(url: str, headers: dict | None = None) -> bytes:
    async with httpx.AsyncClient(timeout=60) as client:
        resp = await client.get(url, headers=headers)
        resp.raise_for_status()
        return resp.content


async def transcribe_audio_bytes(audio_bytes: bytes) -> Optional[str]:
    """
    Call configured speech-to-text endpoint or fall back to local Google Speech Recognition.
    Returns transcript or None.
    """
    logger = logging.getLogger(__name__)
    api_url = await get_config_value_from_cache("VOICE_TRANSCRIBE_URL")
    
    # If VOICE_TRANSCRIBE_URL is configured, try remote STT endpoint
    if api_url and api_url.strip() and not api_url.startswith("https://example"):
        try:
            headers = await get_headers_api()
            files = {"file": ("audio.wav", audio_bytes, "audio/wav")}
            async with httpx.AsyncClient(timeout=60) as client:
                resp = await client.post(api_url, headers=headers, files=files)
                if resp.status_code != 200:
                    body_preview = resp.text[:1000] if hasattr(resp, 'text') else "<unreadable>"
                    logger.warning("transcribe_audio_bytes: STT endpoint returned status=%s body=%s", resp.status_code, body_preview)
                else:
                    try:
                        j = resp.json()
                        for k in ("transcript", "text", "result", "data"):
                            if isinstance(j, dict) and k in j:
                                v = j[k]
                                if isinstance(v, str) and v.strip():
                                    return v.strip()
                                if isinstance(v, dict) and v.get("text"):
                                    return str(v.get("text")).strip()
                        if isinstance(j, str) and j.strip():
                            return j.strip()
                    except Exception:
                        logger.exception("transcribe_audio_bytes: failed to parse JSON from STT response")
        except Exception:
            logger.exception("transcribe_audio_bytes: remote STT endpoint failed")
    
    # Fallback to local Google Speech Recognition (same as Kaggle notebook)
    try:
        logger.info("transcribe_audio_bytes: using local Google Speech Recognition fallback")
        import speech_recognition as sr
        from pydub import AudioSegment
        
        # Convert input bytes to mono 16kHz WAV for speech_recognition
        audio_stream = io.BytesIO(audio_bytes)
        try:
            segment = AudioSegment.from_file(audio_stream)
        except Exception:
            # Try common formats
            for fmt in ("webm", "mp3", "wav", "m4a", "ogg"):
                try:
                    audio_stream.seek(0)
                    segment = AudioSegment.from_file(audio_stream, format=fmt)
                    break
                except Exception:
                    continue
            else:
                logger.error("transcribe_audio_bytes: unsupported audio format for local STT")
                return None
        
        segment = segment.set_channels(1).set_frame_rate(16000)
        wav_io = io.BytesIO()
        segment.export(wav_io, format="wav")
        wav_io.seek(0)
        
        recognizer = sr.Recognizer()
        with sr.AudioFile(wav_io) as source:
            audio_data = recognizer.record(source)
        
        try:
            transcript = recognizer.recognize_google(audio_data)
            logger.info("transcribe_audio_bytes: local STT succeeded, transcript_len=%s", len(transcript or ""))
            return transcript.strip() if transcript else None
        except sr.UnknownValueError:
            logger.warning("transcribe_audio_bytes: Google SR could not understand audio")
            return None
        except sr.RequestError as e:
            logger.error("transcribe_audio_bytes: Google SR request error: %s", e)
            return None
    except ImportError:
        logger.error("transcribe_audio_bytes: speech_recognition or pydub not installed; cannot use local STT fallback")
        return None
    except Exception:
        logger.exception("transcribe_audio_bytes: local STT fallback failed")
        return None


async def synthesize_voice_clone(text: str, voice_id: str | None, username: str | None) -> Optional[bytes]:
    """Call configured voice-clone endpoint and return MP3 bytes (or None)."""
    try:
        api_url = await get_config_value_from_cache("VOICE_CLONE_URL")
        headers = await get_headers_api()
        if not api_url:
            logging.getLogger(__name__).error("synthesize_voice_clone: VOICE_CLONE_URL not configured in app_config")
            raise HTTPException(status_code=502, detail="tts_not_configured")

        payload = {
            "text": text,
            "voice_id": voice_id or "",
            "model_id": "eleven_turbo_v2",
            "stability": 1.0,
            "similarity": 0.85,
            "use_speaker_boost": True,
            "username": await get_config_value_from_cache("PRIVATE_CLOUD_API_USERNAME")
        }
        
        logging.getLogger(__name__).info("synthesize_voice_clone: calling TTS with voice_id=%s text_len=%s", voice_id, len(text or ""))

        async with httpx.AsyncClient(timeout=120) as client:
            resp = await client.post(api_url, headers=headers, json=payload)
            # Validate HTTP status
            if resp.status_code != 200:
                body_preview = None
                try:
                    body_preview = resp.text[:1000]
                except Exception:
                    body_preview = "<unreadable>"
                logging.getLogger(__name__).error("synthesize_voice_clone: TTS endpoint returned status=%s body=%s", resp.status_code, body_preview)
                raise HTTPException(status_code=502, detail="tts_upstream_error")

            # Parse JSON safely
            try:
                j = resp.json()
            except Exception:
                logging.getLogger(__name__).exception("synthesize_voice_clone: failed to parse JSON from TTS response")
                raise HTTPException(status_code=502, detail="tts_upstream_parse_error")

            # Common shapes: { data: { audio_url: 'https://...' } } or { data: { audio_base64: '...' } }
            audio_bytes = None
            if isinstance(j, dict):
                data = j.get("data") or j
                if isinstance(data, dict):
                    audio_url = data.get("audio_url") or data.get("url")
                    audio_b64 = data.get("audio_base64") or data.get("audio")
                    if audio_b64:
                        # base64 string
                        try:
                            audio_bytes = base64.b64decode(audio_b64)
                        except Exception:
                            audio_bytes = None
                    elif audio_url:
                        audio_bytes = await _download_url_as_bytes(audio_url, headers=headers)

            # Fallback: if response text looks like a URL
            if audio_bytes is None:
                txt = resp.text or ""
                if txt.strip().startswith("http"):
                    audio_bytes = await _download_url_as_bytes(txt.strip(), headers=headers)

            if not audio_bytes:
                logging.getLogger(__name__).error("synthesize_voice_clone: TTS response did not contain audio payload: %s", j)
                raise HTTPException(status_code=502, detail="tts_no_audio")

            return audio_bytes
    except Exception:
        logging.getLogger(__name__).exception("synthesize_voice_clone: failed to synthesize voice")
        # If the exception is already an HTTPException, re-raise it so outer layers can handle it
        if isinstance(sys.exc_info()[1], HTTPException):
            raise sys.exc_info()[1]
        raise HTTPException(status_code=502, detail="tts_failed")


async def process_voice_chat(user, audio_bytes: bytes, character_id: str | int | None, session_id: str | None):
    """Orchestrate: transcribe -> chat -> synthesize voice -> store -> persist ChatMessage. 
    Returns dict with voice URLs only (input_url, output_url) for voice-to-voice communication."""
    logger = logging.getLogger(__name__)
    # 1) Store input audio to S3
    input_s3_url = None
    input_s3_key = None
    try:
        bucket = await get_config_value_from_cache("AWS_BUCKET_NAME")
        import uuid, datetime
        input_name = str(uuid.uuid4())
        folder_date = datetime.date.today().isoformat()
        user_id = str(getattr(user, 'id', 'anon'))
        # Store to S3 and extract the key from the returned URL
        direct_url = await store_voice_to_s3("voice", input_name, audio_bytes, user_id, folder_date, "input", bucket)
        # Extract S3 key from URL (format: https://bucket.s3.amazonaws.com/key)
        if direct_url:
            input_s3_key = direct_url.split(".amazonaws.com/", 1)[-1] if ".amazonaws.com/" in direct_url else None
            if input_s3_key:
                # Generate pre-signed URL for secure access
                input_s3_url = await generate_presigned_url(input_s3_key, expires_in=7200)
    except Exception:
        logger.exception("process_voice_chat: failed to store input audio to S3")
    else:
        logger.info("process_voice_chat: input_s3_url=%s", input_s3_url)
    
    # 2) transcribe
    transcript = await transcribe_audio_bytes(audio_bytes)
    logger.info("process_voice_chat: transcription=%s", transcript)

    # If transcription failed, synthesize a helpful user query for the LLM so the model can
    # apologize/ask for clarification instead of receiving a blank user turn.
    if not transcript or not str(transcript).strip():
        logger.warning("process_voice_chat: STT produced no text; using fallback user_query for LLM")
        # Helpful fallback prompt so the assistant can respond meaningfully
        transcript = None

    # 3) build chat payload using existing chat generation URL
    headers = await get_headers_api()
    chat_url = await get_config_value_from_cache("CHAT_GEN_URL")
    api_username = await get_config_value_from_cache("PRIVATE_CLOUD_API_USERNAME")

    # Retrieve recent conversation from DB
    async with AsyncSessionLocal() as db:
        # fetch character voice id if available
        voice_id = None
        character = None
        if character_id:
            try:
                res = await db.execute("SELECT * FROM characters WHERE id = :id", {"id": str(character_id)})
            except Exception:
                res = None
            try:
                # fallback to ORM query
                from sqlalchemy import select
                from app.models.character import Character as CharModel
                r = await db.execute(select(CharModel).where(CharModel.id == str(character_id)))
                character = r.scalar_one_or_none()
                if character:
                    voice_id = getattr(character, 'voice_type', None)
            except Exception:
                pass

        # Build minimal messages history
        messages = []
        # system prompt from app config
        from app.services.app_config import get_config_value_from_cache as _g
        is_sfw = False
        base_system_prompt = await _g("CHAT_GEN_PROMPT_NSFW") if not is_sfw else await _g("CHAT_GEN_PROMPT_SFW")
        system_prompt = base_system_prompt or "You are a helpful assistant."
        messages.append({"role": "system", "content": system_prompt})

        # last N messages
        try:
            from sqlalchemy import select, desc
            from app.models.chat import ChatMessage as ChatModel
            limit = int(await _g("CHAT_HISTORY_LIMIT") or 10)
            q = await db.execute(select(ChatModel).where(ChatModel.session_id == (session_id or "")).order_by(desc(ChatModel.id)).limit(limit))
            last = q.scalars().all()
            last = list(reversed(last))
            for msg in last:
                messages.append({"role": "user", "content": msg.user_query})
                messages.append({"role": "assistant", "content": msg.ai_message or ""})
        except Exception:
            pass

        # user's transcript (or a helpful fallback prompt when STT failed)
        if transcript:
            user_query = transcript
        else:
            user_query = (
                "I attempted to send a voice message but transcription failed. "
                "Please ask me to repeat or ask a short clarifying question so I can respond."
            )
        messages.append({"role": "user", "content": user_query})

        # call chat backend (bubble up errors as 502 so client sees upstream failures)
        try:
            payload = {"messages": messages, "stream": False, "username": api_username}
            async with httpx.AsyncClient(timeout=60) as client:
                resp = await client.post(chat_url, headers=headers, json=payload)
                try:
                    resp.raise_for_status()
                except Exception:
                    body_preview = None
                    try:
                        body_preview = resp.text[:1000]
                    except Exception:
                        body_preview = "<unreadable>"
                    logger.error("process_voice_chat: chat backend returned non-200 status=%s body=%s", resp.status_code, body_preview)
                    raise HTTPException(status_code=502, detail="chat_backend_error")

                try:
                    j = resp.json()
                except Exception:
                    logger.exception("process_voice_chat: failed to parse JSON from chat backend")
                    raise HTTPException(status_code=502, detail="chat_backend_parse_error")

                # extract common shapes
                chat_response_text = None
                if isinstance(j, dict):
                    msg = j.get('message') or j.get('data') or j
                    if isinstance(msg, dict):
                        chat_response_text = msg.get('content') or msg.get('text') or msg.get('message') or None
                    else:
                        if isinstance(msg, str):
                            chat_response_text = msg
                else:
                    chat_response_text = None

                logger.info("process_voice_chat: chat backend response shape: %s", type(j))

        except HTTPException:
            # Re-raise HTTPExceptions so endpoint can surface an appropriate status
            raise
        except Exception:
            logger.exception("process_voice_chat: unexpected error calling chat backend")
            raise HTTPException(status_code=502, detail="chat_backend_error")

        # If chat produced no text, provide a friendly fallback reply so TTS has non-empty text
        if not chat_response_text or not str(chat_response_text).strip():
            logger.warning("process_voice_chat: chat produced empty response; using fallback assistant text for TTS")
            chat_response_text = "Sorry, I didn't catch that. Could you say it again?"

        # Ensure we have a valid voice id (use the same default from Kaggle notebook to avoid TTS silent failures)
        DEFAULT_VOICE_ID = "LEnmbrrxYsUYS7vsRRwD"  # ElevenLabs voice from working Kaggle setup
        # Validate voice_id: ElevenLabs IDs are alphanumeric strings ~20 chars long
        if not voice_id or not str(voice_id).isalnum() or len(str(voice_id)) < 10:
            logger.warning("process_voice_chat: invalid or missing voice_id=%s, using default=%s", voice_id, DEFAULT_VOICE_ID)
            voice_id = DEFAULT_VOICE_ID

        # synthesize voice clone (only call if we have non-empty assistant text)
        mp3_bytes = await synthesize_voice_clone(chat_response_text, voice_id, api_username)
        logger.info("process_voice_chat: synthesized mp3_bytes present=%s size=%s", bool(mp3_bytes), len(mp3_bytes) if mp3_bytes else 0)

        if mp3_bytes is None:
            logger.error("process_voice_chat: TTS failed or returned no audio")
            raise HTTPException(status_code=502, detail="tts_failed")

        # store output mp3 to S3
        output_s3_url = None
        output_s3_key = None
        try:
            if mp3_bytes:
                bucket = await get_config_value_from_cache("AWS_BUCKET_NAME")
                # create a filename
                import uuid, datetime
                output_name = str(uuid.uuid4())
                folder_date = datetime.date.today().isoformat()
                user_id = str(getattr(user, 'id', 'anon'))
                # Store to S3 and extract the key from the returned URL
                direct_url = await store_voice_to_s3("voice", output_name, mp3_bytes, user_id, folder_date, "output", bucket)
                # Extract S3 key from URL
                if direct_url:
                    output_s3_key = direct_url.split(".amazonaws.com/", 1)[-1] if ".amazonaws.com/" in direct_url else None
                    if output_s3_key:
                        # Generate pre-signed URL for secure access
                        output_s3_url = await generate_presigned_url(output_s3_key, expires_in=7200)
        except Exception:
            logger.exception("process_voice_chat: failed to store output mp3 to S3")
        else:
            logger.info("process_voice_chat: output_s3_url=%s", output_s3_url)

        # Create JSON structure for s3_url_media
        # Store S3 KEYS (not pre-signed URLs) so we can re-generate fresh URLs when loading chat history
        media_keys = None
        if input_s3_key or output_s3_key:
            media_keys = {
                "input_key": input_s3_key,
                "output_key": output_s3_key
            }

        # persist ChatMessage
        try:
            # For voice turns we intentionally suppress visible AI text so the frontend
            # will render voice bubbles only. Persist LLM debug text in a dedicated
            # DB column `debug_ai_message` (added via migration) rather than embedding
            # it inside the media JSON.
            cm = ChatMessage(
                session_id=session_id or f"session-{int(asyncio.get_event_loop().time())}",
                user_id=str(getattr(user, 'id', '')),
                character_id=str(character_id) if character_id is not None else None,
                user_query=user_query,
                ai_message=chat_response_text or "",  # persist assistant text for voice replies (UI can hide it)
                debug_ai_message=chat_response_text or None,
                is_media_available=bool(media_keys),
                media_type="voice" if media_keys else None,
                s3_url_media=media_keys,  # Store S3 keys, not pre-signed URLs
            )
            logger.info("process_voice_chat: saving ChatMessage (user=%s session=%s) media=%s", getattr(user, 'id', ''), session_id, media_keys)
            db.add(cm)
            await db.commit()
            logger.info("process_voice_chat: saved ChatMessage id=%s", getattr(cm, 'id', None))
        except Exception:
            logger.exception("process_voice_chat: failed to persist ChatMessage")

        # Structured summary log for observability
        try:
            logger.info(
                "voice-turn: session=%s user=%s char=%s has_transcript=%s input_len=%s output_len=%s",
                session_id, getattr(user, 'id', None), character_id,
                bool(transcript), len(audio_bytes) if audio_bytes else 0,
                len(mp3_bytes) if mp3_bytes else 0,
            )
        except Exception:
            # non-fatal logging failure
            logger.exception("process_voice_chat: failed while logging summary")

        # Return only voice URLs for voice-to-voice communication (no text). Keep transcript for debugging.
        return {
            "input_url": input_s3_url,
            "output_url": output_s3_url,
            "transcript": transcript,
        }
