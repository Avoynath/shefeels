from io import BytesIO
from fastapi import APIRouter, Depends, HTTPException, status, WebSocket, Request
from fastapi.responses import StreamingResponse
import httpx
from app.schemas.chat import ChatCreate, MessageCreate, MessageRead
from app.models.chat import ChatMessage
from app.models.subscription import UserWallet, CoinTransaction
from app.models.character import Character
from app.models.character_media import CharacterMedia
from app.models.user import User, RoleEnum
from app.api.v1.deps import get_headers_api
from app.services.chat import get_compliance_check
from app.services.character_media import generate_image, build_image_prompt, fetch_image_as_base64, generate_filename_timestamped, face_swap, generate_video, detect_video_effect_from_prompt
from app.core.aws_s3 import upload_to_s3_file, generate_presigned_url
from app.services.chat import approximate_token_count                 
from app.api.v1.deps import get_current_user
from app.core.database import get_db
from app.core.config import settings
from app.services.app_config import get_config_value_from_cache
from app.services.subscription import check_user_wallet, deduct_user_coins
from typing import List
import asyncio
import json
import requests
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import Column, select, desc
from fastapi.responses import JSONResponse
import os
import re
router = APIRouter()


def clean_model_output(text: str) -> str:
    """
    Keep only the content after the *last* assistant marker
    and strip junk like analysis, commentary, etc.
    """
    # Always find the last "assistantfinal"
    match = list(re.finditer(r"assistantfinal", text, re.IGNORECASE))
    if match:
        cut = match[-1].end()
        text = text[cut:]
    
    # Remove obvious junk tokens
    text = re.sub(r"(?is)(analysis|reasoning|commentary).*", "", text).strip()
    
    # Clean leftover quotes/braces
    text = text.strip()
    text = text.strip("{}[]\"'")
    
    return text.strip()


def _looks_like_image_request_keyword_detector(text: str) -> bool:
    """Simple keyword/phrase detector with word boundaries and some heuristics.

    This complements the LLM-based intent classifier and is used as a fallback or
    override when explicit user text clearly requests an image (including NSFW).
    """
    if not text:
        return False
    txt = text.lower()

    # Strong explicit requests (explicit sexual phrases kept intentionally)
    explicit_triggers = [
        r"\bshow me your nude\b",
        r"\bshow me nude\b",
        r"\bshow me your boobs\b",
        r"\bshow me your tits\b",
        r"\bshow me ur boobs\b",
        r"\bshow me ur tits\b",
        r"\bsend me your picture\b",
        r"\bsend me a picture\b",
        r"\bsend me your photo\b",
        r"\bsend a picture\b",
        r"\bshow me a picture\b",
        r"\bshow me your picture\b",
        r"\bavatar\b",
        r"\bphoto\b",
        r"\bpicture\b",
        r"\bimage\b",
        r"\bnude\b",
        r"\bboobs\b",
        r"\btits\b",
        r"\bnipples\b",
        r"\bbreasts\b",
    ]

    import re as _re
    for pat in explicit_triggers:
        if _re.search(pat, txt):
            return True

    # General creative/image generation verbs combined with object words
    # e.g. "draw me a cat", "generate image of a castle"
    verbs = [r"\bdraw\b", r"\bgenerate\b", r"\bcreate\b", r"\bmake\b", r"\bpaint\b", r"\bcreate an image\b"]
    nouns = [r"\bimage\b", r"\bpicture\b", r"\bavatar\b", r"\bphoto\b", r"\bportrait\b"]
    for v in verbs:
        if _re.search(v, txt):
            # If a verb appears near an image-word or there is 'draw me' style phrase
            if _re.search(r"draw me", txt) or any(_re.search(n, txt) for n in nouns):
                return True

    return False

def looks_like_video_request(text):
    """
    Check if a user message requests a video.
    This complements the LLM-based intent classifier for video generation requests.
    """
    if not text:
        return False
    txt = text.lower()

    # Video-specific explicit requests
    video_triggers = [
        r"\bsend me a video\b",
        r"\bshow me a video\b",
        r"\bmake a video\b",
        r"\bgenerate a video\b",
        r"\bcreate a video\b",
        r"\brecord a video\b",
        r"\bfilm\b",
        r"\bmovie\b",
        r"\bvideo of yourself\b",
        r"\bshow me in action\b",
        r"\bperform\b",
        r"\bact out\b",
        r"\bdo a\b.*\b(missionary|cowgirl|doggy|blowjob|deepthroat)\b",
        r"\blet's do\b.*\b(missionary|cowgirl|doggy|blowjob|deepthroat)\b",
    ]

    import re as _re
    for pat in video_triggers:
        if _re.search(pat, txt):
            return True

    # Check for specific position/action requests that imply video
    position_words = ["missionary", "cowgirl", "doggystyle", "doggy", "blowjob", "deepthroat", "69", "spooning", "standing"]
    action_words = ["fuck", "sex", "make love", "pleasure", "ride", "suck", "oral"]

    for pos in position_words:
        if pos in txt:
            return True

    for action in action_words:
        if action in txt and any(verb in txt for verb in ["show", "do", "perform", "let's", "want to"]):
            return True

    return False

def _normalize_choice_field(value: str | None) -> str | None:
    if not value:
        return value
    try:
        base = os.path.basename(value)
        name, _ext = os.path.splitext(base)
        name = name.strip().replace('_', ' ').replace('-', ' ')
        return name
    except Exception:
        return value

@router.get("/all", response_model=List[MessageRead])
async def get_all_chats(user=Depends(get_current_user), user_id: str = None, db: AsyncSession = Depends(get_db)):
    """Get all previous chats for a user (admin) or current user in descending order of creation."""
    query_user_id = user_id if user_id is not None else user.id
    result = await db.execute(
        select(ChatMessage)
        .where(ChatMessage.user_id == query_user_id)
        .order_by(desc(ChatMessage.created_at))
    )
    messages = result.scalars().all()
    def truncate(text, length=2000):
        if text and len(text) > length:
            return text[:length] + "..."
        return text

    # Resolve presigned URLs concurrently for all messages that have an S3 key.
    async def _maybe_presign(s3_key):
        if not s3_key:
            return None
        try:
            return await generate_presigned_url(s3_key)
        except Exception:
            # If presign fails for a specific item, return None and continue.
            return None

    # Process media: for voice messages (media_type='voice'), s3_url_media contains input_key/output_key
    # For other media types, s3_url_media might be a single S3 key string
    async def _process_media(msg):
        # Normalize stored s3_url_media which may be a dict, JSON string, or simple S3 key string.
        raw = msg.s3_url_media
        media_obj = None
        try:
            if raw is None:
                media_obj = None
            elif isinstance(raw, dict):
                media_obj = raw
            elif isinstance(raw, str):
                s = raw.strip()
                # Attempt to parse JSON text
                if s.startswith('{') or s.startswith('['):
                    try:
                        media_obj = json.loads(s)
                    except Exception:
                        media_obj = s
                else:
                    media_obj = s
            else:
                media_obj = raw
        except Exception:
            media_obj = raw

        # Voice messages: media_obj should be a dict with input_key/output_key or input_url/output_url
        if msg.media_type == 'voice' and isinstance(media_obj, dict):
            input_key = media_obj.get('input_key') or media_obj.get('input_url')
            output_key = media_obj.get('output_key') or media_obj.get('output_url')

            # If stored values are full URLs, extract the key part
            if input_key and isinstance(input_key, str) and '.amazonaws.com/' in input_key:
                input_key = input_key.split('.amazonaws.com/', 1)[-1]
            if output_key and isinstance(output_key, str) and '.amazonaws.com/' in output_key:
                output_key = output_key.split('.amazonaws.com/', 1)[-1]

            input_url = await _maybe_presign(input_key) if input_key else None
            output_url = await _maybe_presign(output_key) if output_key else None

            return {"input_url": input_url, "output_url": output_url}

        # Non-voice media: if media_obj is a dict, try common keys; if string assume it's an s3 key
        if media_obj:
            if isinstance(media_obj, dict):
                # prefer output_url, input_url, url, image, etc.
                candidate = media_obj.get('output_url') or media_obj.get('input_url') or media_obj.get('url') or media_obj.get('image')
                if candidate and isinstance(candidate, str) and '.amazonaws.com/' in candidate:
                    candidate = candidate.split('.amazonaws.com/', 1)[-1]
                return await _maybe_presign(candidate)
            if isinstance(media_obj, str):
                # plain string might be an s3 key or full URL
                key = media_obj
                if '.amazonaws.com/' in key:
                    key = key.split('.amazonaws.com/', 1)[-1]
                return await _maybe_presign(key)

        return None

    presigned_media = await asyncio.gather(*(_process_media(msg) for msg in messages))

    results: list[MessageRead] = []
    for msg, presigned in zip(messages, presigned_media):
        results.append(
            MessageRead(
                id=msg.id,
                session_id=msg.session_id,
                character_id=msg.character_id,
                user_query=truncate(msg.user_query or "", 2000),
                ai_message=truncate(msg.ai_message or "", 2000),
                is_media_available=msg.is_media_available,
                media_type=msg.media_type,
                s3_url_media=presigned,
                created_at=str(getattr(msg, "created_at", "")),
            )
        )

    return results

@router.post("/" )
async def start_chat(chat: ChatCreate, user=Depends(get_current_user),
                     db: AsyncSession = Depends(get_db)):
    #await check_user_wallet(db, user.id, "chat")
    headers = await get_headers_api()
    # Fetch last n messages for the session_id, ordered by your timestamp or id
    chat_limit = await get_config_value_from_cache("CHAT_HISTORY_LIMIT")
    username = await get_config_value_from_cache("PRIVATE_CLOUD_API_USERNAME")
    chat_url = await get_config_value_from_cache("CHAT_GEN_URL")
    is_sfw = False
    # Ensure `character` is always defined in the function scope so later
    # references (e.g., getattr(character, ...)) don't raise UnboundLocalError
    # when `character_id` is falsy and the conditional block below isn't executed.
    character = None
    character_id = chat.character_id
    if character_id:
        result = await db.execute(select(Character).where(Character.id == character_id))
        character = result.scalar_one_or_none()
        # Enforce access rules: allow chatting if the current user owns the character
        # or if the character was created by an admin (public admin characters).
        if character:
            try:
                # If the character belongs to someone else and that owner is not an admin,
                # prevent chatting to avoid leaking or allowing access to private characters.
                if character.user_id != user.id:
                    # Fetch the owner to check role
                    
                    owner_res = await db.execute(select(User).where(User.id == character.user_id))
                    owner = owner_res.scalars().first()
                    owner_is_admin = False
                    if owner and getattr(owner, 'role', None):
                        try:
                            owner_is_admin = (str(owner.role).upper() == 'ADMIN' or owner.role == RoleEnum.ADMIN)
                        except Exception:
                            owner_is_admin = (str(owner.role).upper() == 'ADMIN')
                    if not owner_is_admin:
                        # Not allowed to chat with another user's private character
                        print(f"Forbidden: user {user.id} attempted to chat with character {character.id} owned by user {character.user_id}")
                        raise HTTPException(status_code=403, detail="Forbidden: you don't have access to this character")
            except HTTPException:
                raise
            except Exception as e:
                # If anything went wrong while checking ownership, log and deny access conservatively
                print(f"Error checking character ownership: {e}")
                raise HTTPException(status_code=403, detail="Forbidden: unable to verify character access")
        # Build a safe JSON string with a few important character fields.
        # The Character model doesn't provide a to_dict() helper, so serialize manually.
            
        if character:
            char_dict = {
                "style": character.style or "",
                "ethnicity": _normalize_choice_field(character.ethnicity) or "",
                "age": character.age or 0,
                "eye_colour": character.eye_colour or "",
                "hair_style": character.hair_style or "",
                "hair_colour": character.hair_colour or "",
                "body_type": character.body_type or "",
                "breast_size": character.breast_size or "",
                "butt_size": character.butt_size or "",
                "dick_size": character.dick_size or "",
                "personality": character.personality or "",
                "voice_type": character.voice_type or "",
                "relationship_type": character.relationship_type or "",
                "clothing": character.clothing or "",
                "special_features": _normalize_choice_field(character.special_features) or "",
            }
            json_character_details = json.dumps(char_dict)
            name = character.name or "Unknown"
            bio = character.bio or ""
            gender = character.gender or ""
        else:
            json_character_details = ""
            name = "Unknown"
            bio = ""
            gender = ""
    ################# DELETE THIS LATER. SHOULD COME FROM UI
    is_sfw = False
    #####################
    if is_sfw :
        base_system_prompt = await get_config_value_from_cache("CHAT_GEN_PROMPT_SFW")
    else:
        base_system_prompt = await get_config_value_from_cache("CHAT_GEN_PROMPT_NSFW")

    # Build a richer system prompt that includes both the configured template and a structured
    # character profile + original creation prompt to make the model "aware" of the character.
    try:
        template_prompt = (base_system_prompt or "").replace("replace_character_name", name).replace("replace_character_bio", bio).replace("replace_character_gender", gender).replace("replace_character_details", json_character_details)
    except Exception:
        template_prompt = base_system_prompt or ""

    # Include original creation prompt if available (may be a JSON string or text)
    orig_creation_prompt = getattr(character, 'prompt', None) if character else None

    persona_injection_lines = []
    persona_injection_lines.append("Character Profile (JSON):")
    persona_injection_lines.append(json_character_details or "{}")
    if orig_creation_prompt:
        persona_injection_lines.append("")
        persona_injection_lines.append("Original Creation Prompt (keep persona & visual cues consistent):")
        # Truncate if overly long
        try:
            persona_injection_lines.append(orig_creation_prompt if len(str(orig_creation_prompt)) < 4000 else str(orig_creation_prompt)[:4000])
        except Exception:
            persona_injection_lines.append(str(orig_creation_prompt))

    persona_injection_lines.append("")
    persona_injection_lines.append("Instructions: Stay in character at all times. Use the character profile above for facts about the character (age, gender, personality, appearance). When responding, speak as the character in first person. Use conversation history for context and do not contradict the profile.")

    system_prompt = template_prompt + "\n\n" + "\n".join(persona_injection_lines)
    result = await db.execute(
        select(ChatMessage)
        .where((ChatMessage.user_id == user.id) & (ChatMessage.character_id == character_id) )
        .order_by(desc(ChatMessage.created_at))  # or .created_at if you have a timestamp
        .limit(chat_limit)  # Limit to last n messages
    )
    last_messages = result.scalars().all()
    last_messages = list(reversed(last_messages))
    messages = []
    messages.append({"role": "system", "content": system_prompt})
    for msg in last_messages:
        messages.append({"role": "user", "content": msg.user_query})
        messages.append({"role": "assistant", "content": msg.ai_message})
    messages.append({"role": "user", "content": chat.user_query})
    token_count = await approximate_token_count(messages)
    data = {
        "messages": messages,
        "stream": False,
        "username" : username
    }
    print('Sending request to chat API with payload : ', data)
    # Ensure chat_url looks valid
    if not chat_url:
        print('CHAT_GEN_URL not configured in app config cache')
        raise HTTPException(status_code=502, detail='Chat backend not configured')

    try:
        # Use a reasonable timeout so the request doesn't hang and surface clearer errors
        response = requests.post(chat_url, headers=headers, json=data, timeout=30)
    except requests.exceptions.Timeout as te:
        print('Chat API request timed out:', te)
        raise HTTPException(status_code=504, detail='Chat backend timed out')
    except requests.exceptions.RequestException as rexc:
        # Network-level errors (DNS, connection refused, etc.)
        print('Chat API request failed with network error:', rexc)
        raise HTTPException(status_code=502, detail=f'Chat backend network error: {str(rexc)}')

    # Log status and a truncated body for diagnostics
    try:
        body_preview = (response.text[:1000] + '...') if response.text and len(response.text) > 1000 else (response.text or '')
        print('Chat API responded', response.status_code, 'preview:', body_preview)
    except Exception:
        pass

    if response.status_code != 200:
        # Surface a helpful error including status code and a short excerpt when available
        detail_msg = f'Chat API returned {response.status_code}'
        try:
            # try to extract an error message from JSON body
            j = response.json()
            if isinstance(j, dict) and j.get('error'):
                detail_msg += f": {str(j.get('error'))[:300]}"
        except Exception:
            # ignore JSON parse errors
            pass
        raise HTTPException(status_code=502, detail=detail_msg)

    # Expected shape: { message: { content: "..." } }
    try:
        chat_output = response.json().get('message', {}).get('content')
    except Exception:
        raise HTTPException(status_code=502, detail='Invalid response from chat backend')

    # Sanitize model output to remove leftover analysis/commentary before intent detection
    try:
        chat_output = clean_model_output(chat_output)
    except Exception:
        pass

    # Debug: show what the user asked and what the model returned
    try:
        print('Chat request user_query:', repr(chat.user_query))
        print('Chat API returned assistant text (preview):', (chat_output[:300] + '...') if chat_output and len(chat_output) > 300 else chat_output)
    except Exception:
        pass

    # Simple intent classifier: look for common image request verbs/nouns.
    # This is intentionally lightweight — it just looks for explicit user requests
    # like "send me your picture", "draw a cat", "show me a castle", "generate image".
    image_urls = []


    # Use the LLM itself to detect intent and optionally produce an image prompt.
    # We'll ask the same chat model to respond with a small JSON object indicating whether
    # to generate an image and the prompt to use. If that fails, fall back to keyword detection.
    def ask_llm_for_intent(chat_url, headers, username, user_query, assistant_text):
        try:
            # Enhanced intent classifier that extracts scene details from user requests
            intent_system = (
    "You are an intent classifier for image generation. Respond ONLY with a single JSON object and nothing else.\n"
    "\n"
    "Your goal: Decide whether the user's message explicitly requests an image, picture, photo, drawing, illustration, or visual depiction.\n"
    "\n"
    "Important rules:\n"
    "- Return a JSON object with keys: 'generate_image' (true/false), 'prompt' (string), 'pose' (string), 'background' (string), and 'outfit' (string) ONLY when generate_image is true.\n"
    "- Set generate_image: true **only if** the user’s message asks for an image (e.g., includes words like 'show me', 'draw', 'create an image', 'generate picture', 'make a photo', 'render', 'visualize', etc.).\n"
    "- If the user merely describes a scene, character, or concept in text form without explicitly asking for an image, return generate_image: false.\n"
    "- If the request is for text, stories, chat, or any non-visual content, return generate_image: false.\n"
    "- When generate_image is true, extract clear scene details: \n"
    "  - 'prompt': A concise visual description of what to generate.\n"
    "  - 'pose': Character’s physical position or action.\n"
    "  - 'background': Setting or environment.\n"
    "  - 'outfit': Clothing or style.\n"
    "- Always use lowercase true/false (no quotes).\n"
    "\n"
    "Examples:\n"
    "User: 'show me your picture at the beach' -> {generate_image: true, prompt: 'character portrait at the beach with ocean waves', pose: 'standing naturally, facing camera', background: 'beach with ocean waves and sand', outfit: 'beach outfit or bikini'}\n"
    "User: 'draw yourself in a red dress' -> {generate_image: true, prompt: 'character in red dress smiling', pose: 'standing confidently', background: 'neutral or studio setting', outfit: 'red dress'}\n"
    "User: 'create an image of you sitting in a cafe' -> {generate_image: true, prompt: 'character sitting in cafe with warm lighting', pose: 'sitting relaxed at table', background: 'cozy cafe interior', outfit: 'casual outfit'}\n"
    "User: 'describe yourself on a beach' -> {generate_image: false}\n"
    "User: 'what do you look like?' -> {generate_image: false}\n"
    "User: 'Tell me a story about you at a restaurant' -> {generate_image: false}\n"
    "User: 'show me your nude selfie' -> {generate_image: true, prompt: 'character nude selfie in intimate bedroom setting', pose: 'selfie pose looking at camera', background: 'bedroom with soft lighting', outfit: 'naked'}\n"
    "\n"
    "Be strict: only output generate_image: true for explicit image-generation requests. Return only the JSON object."
)

            # Add character details as an additional system message to help intent classification be
            # aware of the character's attributes (so it can decide when to generate images of that character).
            messages_for_intent = [
                {"role": "system", "content": intent_system},
            ]
            # print(f"Character details for intent detection: {json_character_details}")
            # if json_character_details:
            #     messages_for_intent.append({"role": "system", "content": f"Character details: {json_character_details}"})
            
            
            #messages_for_intent.append({"role": "user", "content": f"user: {user_query}\nassistant: {assistant_text}"})
            messages_for_intent.append({"role": "user", "content": f"user: {user_query}"})

            payload = {
                "messages": messages_for_intent,
                "stream": False,
                "username": username
            }
            print('Sending intent classification request to chat API with payload:', payload)
            # Use a short timeout to avoid hanging - we prefer keyword fallback if this fails.
            # Request deterministic output
            payload["temperature"] = 0
            resp2 = requests.post(chat_url, headers=headers, json=payload, timeout=30)
            if resp2.status_code != 200:
                return None
            content = resp2.json().get('message', {}).get('content', '')
            print('Intent classification model output (preview):', (content[:300] + '...') if content and len(content) > 300 else content)
            # Sanitize model output to remove analysis/junk and ensure we extract the JSON robustly
            content = clean_model_output(content)
            # Log raw intent content for debugging (avoid logging secrets)
            try:
                #print('Raw intent model output (truncated):', (content[:300] + '...') if content and len(content) > 300 else content)
                print('Raw intent model output (FULL):', content)  # Add full content logging
            except Exception:
                pass
            # extract JSON object from content
            import re as _re, json as _json
            
            # Try to find the last JSON object in the model output
            m = _re.search(r"\{[\s\S]*\}\s*$", content)
            if not m:
                # fallback: find any JSON-looking substring
                m = _re.search(r"\{[\s\S]*?\}", content)
            
            # If no proper JSON found, try to repair and parse malformed JSON
            if not m:
                print(f"No proper JSON braces found, attempting repair...")
                try:
                    # Look for JSON-like content that's missing braces or is truncated
                    # Match patterns like: generate_image": true, "prompt": "..." 
                    json_like = _re.search(r'generate_image["\s]*:\s*(true|false)', content, _re.IGNORECASE)
                    if json_like:
                        print(f"Found generate_image pattern, attempting repair...")
                        # Try to extract a JSON-like substring and repair it
                        # Find content that looks like JSON key-value pairs
                        json_content = content
                        
                        # Add missing opening brace if needed
                        if not json_content.strip().startswith('{'):
                            # Find where JSON-like content starts
                            start_match = _re.search(r'generate_image', json_content)
                            if start_match:
                                json_content = '{' + json_content[start_match.start():]
                                print(f"Added opening brace: {json_content[:100]}...")
                        
                        # Add missing closing brace if needed
                        if not json_content.rstrip().endswith('}'):
                            json_content = json_content.rstrip() + '}'
                            print(f"Added closing brace: ...{json_content[-100:]}")
                        
                        print(f"Attempting to parse repaired JSON: {json_content}")
                        
                        # Try to parse the repaired JSON
                        try:
                            j = _json.loads(json_content)
                            print(f"Successfully repaired and parsed JSON: {j}")
                            return j
                        except Exception as e:
                            print(f"JSON parsing failed: {e}")
                        
                        # If that fails, fall back to manual parsing
                        print(f"JSON repair failed, falling back to manual parsing")
                        
                except Exception as e:
                    print(f"Error in JSON repair attempt: {e}")
                
                # Final fallback: manual key-value extraction
                try:
                    # Look for generate_image: true/false pattern
                    generate_match = _re.search(r"generate_image[\"'\s]*:\s*(true|false)", content, _re.IGNORECASE)
                    if generate_match:
                        generate_value = generate_match.group(1).lower() == 'true'
                        
                        # Extract other fields if generate_image is true
                        result = {"generate_image": generate_value}
                        if generate_value:
                            # Try to extract prompt, pose, background, outfit with more flexible patterns
                            prompt_match = _re.search(r"prompt[\"'\s]*:\s*[\"']([^\"']*)[\"']", content)
                            pose_match = _re.search(r"pose[\"'\s]*:\s*[\"']([^\"']*)[\"']", content)
                            background_match = _re.search(r"background[\"'\s]*:\s*[\"']([^\"']*)[\"']", content)
                            outfit_match = _re.search(r"outfit[\"'\s]*:\s*[\"']([^\"']*)[\"']", content)
                            
                            if prompt_match:
                                result["prompt"] = prompt_match.group(1)
                            if pose_match:
                                result["pose"] = pose_match.group(1)
                            if background_match:
                                result["background"] = background_match.group(1)
                            if outfit_match:
                                result["outfit"] = outfit_match.group(1)
                        
                        print(f"Parsed intent from key-value pairs: {result}")
                        return result
                except Exception as e:
                    print(f"Error parsing key-value pairs: {e}")
                return None
            
            try:
                j = _json.loads(m.group(0))
                return j
            except Exception:
                # If the JSON isn't strict (e.g., uses unquoted true/false), try a relaxed parser
                try:
                    # Replace unquoted true/false with quoted then convert
                    s = m.group(0)
                    s2 = s.replace('true', '"true"').replace('false', '"false"')
                    j = _json.loads(s2)
                    # Convert back
                    if isinstance(j, dict) and 'generate_image' in j and isinstance(j['generate_image'], str):
                        j['generate_image'] = True if j['generate_image'].lower() == 'true' else False
                    return j
                except Exception:
                    return None
        except Exception:
            return None

    try:
        intent = ask_llm_for_intent(chat_url, headers, username, chat.user_query, chat_output)
        user_trigger = False
        output_trigger = False
        try:
            user_trigger = bool(chat.user_query and len(chat.user_query.strip()) > 0 and intent is not None and intent.get('generate_image') is True and intent.get('prompt'))
            output_trigger = bool(intent is not None and intent.get('generate_image') is True and intent.get('prompt'))
            print('Image intent from LLM:', intent)
            print('User trigger:', user_trigger, 'Output trigger:', output_trigger)
        except Exception:
            intent = None

        if user_trigger or output_trigger:
            try:
                print('Character avatar key present?:', bool(character and getattr(character, 'image_url_s3', None)))
            except Exception:
                pass

            # Build enhanced prompt using character's original creation prompt + chat prompt
            enhanced_prompt = None
            pose = ""
            background = ""
            outfit = ""
            
            try:
                if intent and intent.get('prompt'):
                    chat_specific_prompt = intent.get('prompt')
                    # Extract scene components if provided by enhanced LLM intent
                    pose = intent.get('pose', '')
                    background = intent.get('background', '')
                    outfit = intent.get('outfit', '')
                else:
                    _name = name if 'name' in locals() else ''
                    bio_short = (bio[:240] + '...') if (bio and len(bio) > 240) else (bio or '')
                    chat_specific_prompt = f"{_name} {bio_short} — {chat.user_query}".strip()
                
                # print("=" * 80)
                # print("CHAT IMAGE GENERATION")
                # print(f"Chat specific prompt: '{chat_specific_prompt}'")
                # print(f"Extracted pose: '{pose}'")
                # print(f"Extracted background: '{background}'")
                # print(f"Extracted outfit: '{outfit}'")
                
                # Prefer to reuse the character's original creation prompt (if available) when building
                # the image prompt for visual consistency. Otherwise, build prompt from attributes.

                if character:
                    # print("Building enhanced prompt using character attributes...")
                    # print(f"Character name: {character.name}")
                    # print(f"Character age: {getattr(character, 'age', 25)}")
                    # print(f"Character gender: {getattr(character, 'gender', 'female')}")
                    # print(f"Character style: {getattr(character, 'style', '')}")
                    # print(f"Character bio: {getattr(character, 'bio', '')}")
                    # print(f"Character ethnicity: {getattr(character, 'ethnicity', '')}")
                    # print(f"Character body_type: {getattr(character, 'body_type', '')}")
                    # print(f"Character eye_colour: {getattr(character, 'eye_colour', '')}")
                    # print(f"Character hair_style: {getattr(character, 'hair_style', '')}")
                    # print(f"Character hair_colour: {getattr(character, 'hair_colour', '')}")
                    
                    # Use LLM-extracted structured data for better image generation
                    final_pose = pose if pose else chat_specific_prompt
                    final_background = background if background else ""
                    final_outfit = outfit if outfit else ""
                    
                    # Use LLM-extracted prompt if available, otherwise use chat_specific_prompt
                    llm_extracted_prompt = intent.get('prompt', '') if intent else ''
                    final_positive_prompt = llm_extracted_prompt if llm_extracted_prompt else chat_specific_prompt
                    
                    # print(f"Final pose: '{final_pose}'")
                    # print(f"Final background: '{final_background}'")
                    # print(f"Final outfit: '{final_outfit}'")
                    # print(f"Final positive_prompt (LLM-extracted): '{final_positive_prompt}'")
                    
                    # Build character-aware prompt with scene details
                    enhanced_prompt = await build_image_prompt(
                        character_name=character.name,
                        character_age=getattr(character, 'age', 25),
                        character_gender=getattr(character, 'gender', 'female'),
                        character_style=getattr(character, 'style', ''),
                        character_bio=getattr(character, 'bio', ''),
                        character_ethnicity=getattr(character, 'ethnicity', ''),
                        character_body_type=getattr(character, 'body_type', ''),
                        character_eye_colour=getattr(character, 'eye_colour', ''),
                        character_hair_style=getattr(character, 'hair_style', ''),
                        character_hair_colour=getattr(character, 'hair_colour', ''),
                        character_breast_size=getattr(character, 'breast_size', ''),
                        character_butt_size=getattr(character, 'butt_size', ''),
                        character_special_features=getattr(character, 'special_features', ''),
                        character_clothing=getattr(character, 'clothing', ''),
                        pose=final_pose,
                        background=final_background,
                        outfit=final_outfit,
                        positive_prompt=final_positive_prompt,
                        negative_prompt="",
                    )
                    # print("ENHANCED PROMPT FOR CHAT IMAGE:")
                    # print(f"'{enhanced_prompt}'")
                else:
                    enhanced_prompt = chat_specific_prompt
                    print("No character found, using chat prompt only:")
                    
                # print("=" * 80)
                    
            except Exception as e:
                print(f"Error building enhanced prompt: {e}")
                enhanced_prompt = chat.user_query or chat_output

            # Get character avatar for face swapping
            character_avatar_b64 = None
            try:
                if character and getattr(character, 'image_url_s3', None):
                    try:
                        presigned_src = await generate_presigned_url(character.image_url_s3)
                        character_avatar_b64 = await fetch_image_as_base64(presigned_src)
                    except Exception as e:
                        print(f"Error fetching character avatar: {e}")
                        character_avatar_b64 = None
            except Exception as e:
                print(f"Error in character avatar processing: {e}")
                character_avatar_b64 = None

            # Step 1: Generate image using text-to-image (the correct approach for character consistency)
            try:
                print("\n--- CHAT IMAGE GENERATION PROCESS ---")
                # print(f"STEP 1: Generating image using text-to-image")
                # print(f"Enhanced prompt: '{enhanced_prompt}'")
                # print("Parameters:")
                # print(f"  - num_images: 1")
                # print(f"  - initial_image: None (text-to-image for character consistency)")
                # print(f"  - size_orientation: portrait")
                

                #status, result = await get_compliance_check(chat.user_query)
                # status, result = await get_compliance_check(enhanced_prompt)
                
                # if status is False:
                #     raise HTTPException(status_code=400, detail=f"Image generation is not compliant: {result}")

                # resp = await generate_image(
                #     enhanced_prompt, 
                #     num_images=1, 
                #     initial_image=None,  # Always use text-to-image for character consistency
                #     size_orientation="portrait"
                # )
                
                # print(f"Image generation response status: {resp.status_code}")
                
                ########### USING IMAGE EDITING SERVICE (LIGHTSPEED) #############
                images_value = [presigned_src] 
                llm_prompt_pose = final_positive_prompt + f", pose: {pose}" if pose else final_positive_prompt

                llm_prompt_background = f", background: {background}" if background else ""

                enhanced_prompt = llm_prompt_pose or (chat.user_query + "\n" + chat_output)
                print(f"Using Lightspeed image editing service for chat image generation with prompt: '{enhanced_prompt}'")
                api_url = await get_config_value_from_cache("IMAGE_EDIT_URL")
                username = await get_config_value_from_cache("PRIVATE_CLOUD_API_USERNAME")
                headers = await get_headers_api()
                output_format = "jpeg"  # or png, etc.
                payload = {
                            "images": images_value,
                            "prompt": enhanced_prompt,
                            "output_format": output_format,
                            "username": username}
                print(f"Lightspeed payload for chat image:", payload)
                try:
                    async with httpx.AsyncClient(timeout=60) as client:
                        resp = await client.post(api_url, json=payload, headers=headers)
                        print("Lightspeed response status:", resp.text)
                    resp.raise_for_status()
                except httpx.HTTPStatusError as e:
                    print("Lightspeed status:", e.response.status_code)
                    print("Lightspeed headers:", e.response.headers)
                    raise HTTPException(status_code=502, detail=str(e))
                # Parse Lightspeed response and download the result image
                try:
                    upstream_json = resp.json()
                except Exception:
                    upstream_json = {"result": resp.text}

                # Extract the edited image URL from Lightspeed response
                result_image_url = None
                if upstream_json.get("results") and upstream_json["results"].get("outputs"):
                    result_image_url = upstream_json["results"]["outputs"][0]
                elif upstream_json.get("outputs"):
                    result_image_url = upstream_json["outputs"][0]

                if result_image_url:
                    # Download the edited image from Lightspeed and upload to our S3
                    async with httpx.AsyncClient(timeout=60) as client:
                        img_resp = await client.get(result_image_url)
                        img_resp.raise_for_status()
                        result_bytes = img_resp.content
                        result_stream = BytesIO(result_bytes)

                    # Upload result to S3
                    user_role = (user.role if user else "USER").lower()
                    user_id = str(user.id)
                    current_name = f"{character.name}_chat"
                    filename = await generate_filename_timestamped(current_name)
                    s3_key = f"chat_image/{user_role}/{user_id}/{filename}.{output_format}"

                    bucket_name = await get_config_value_from_cache("AWS_BUCKET_NAME")
                    s3_key, presigned_s3_url = await upload_to_s3_file(
                        file_obj=result_stream,
                        s3_key=s3_key,
                        content_type="image/png",
                        bucket_name=bucket_name,
                    )
                # Save to CharacterMedia table for persistence (like gallery images)
                # Mark chat-generated assets with a distinct media_type so
                # chat-specific queries (and the gallery) can find them reliably.
                db_character_media = CharacterMedia(
                    user_id=user.id,
                    character_id=character.id if character else None,
                    media_type="chat_image",
                    s3_path=s3_key,
                )
                db.add(db_character_media)
                await db.commit()
                await db.refresh(db_character_media)
                print('Uploaded chat image to S3, s3_key:', s3_key)
                print('Saved to CharacterMedia table, id:', db_character_media.id)
                # Store S3 key instead of presigned URL for non-expiring access
                image_urls = []
                image_urls.append({"s3_key": s3_key, "presigned_s3_url": presigned_s3_url})
                ##return {"s3_key": s3_key, "url": presigned_s3_url}

            except Exception as e:
                print(f"Error in image generation: {e}")
                resp = None

            # if resp and getattr(resp, 'status_code', None) == 200:
            #     j = resp.json()
            #     images_data = j.get('data', {}).get('images_data') or j.get('data', {}).get('images') or j.get('images_data') or j.get('images')
            #     if not images_data:
            #         images_data = j.get('data') or j.get('images') or []

            #     if images_data:
            #         generated_image_b64 = images_data[0]
            #         print(f"Generated image base64 length: {len(generated_image_b64)}")
                    
            #         # Step 2: Apply face swap for character consistency (the correct approach)
            #         final_image_b64 = generated_image_b64
            #         if character_avatar_b64:
            #             try:
            #                 print(f'STEP 2: Performing face swap for character consistency')
            #                 print("Face swap parameters:")
            #                 print(f"  - source_image (character): {len(character_avatar_b64)} chars")
            #                 print(f"  - target_image (generated): {len(generated_image_b64)} chars")
                            
            #                 face_swap_response = await face_swap(
            #                     source_image_base64=character_avatar_b64,  # Original character face
            #                     target_image_base64=generated_image_b64   # Generated chat image
            #                 )
                            
            #                 print(f"Face swap response status: {face_swap_response.status_code}")
                            
            #                 if face_swap_response.status_code == 200:
            #                     face_swap_json = face_swap_response.json()
            #                     final_image_b64 = face_swap_json.get("data", {}).get("image_data", generated_image_b64)
            #                     print(f'Face swap successful for chat image, final length: {len(final_image_b64)}')
            #                 else:
            #                     print('Face swap failed for chat image, using original generated image')
            #             except Exception as e:
            #                 print(f'Face swap error for chat image: {e}')
            #         else:
            #             print("No character avatar available for face swap, using generated image as-is")
                    
            #         print("--- CHAT IMAGE GENERATION COMPLETED ---\n")
                    
            #         try:
            #             import io, base64
            #             image_bytes = base64.b64decode(final_image_b64)
            #             image_file = io.BytesIO(image_bytes)
                        
            #             user_role = (user.role if user else "USER").lower()
            #             user_id = str(user.id)
            #             filename = await generate_filename_timestamped((name or 'ai'))
            #             file_ext = 'png'
            #             s3_key = f"chat_image/{user_role}/{user_id}/{filename}.{file_ext}"
            #             bucket = await get_config_value_from_cache("AWS_BUCKET_NAME")
            #             s3_key, presigned_s3_url = await upload_to_s3_file(file_obj=image_file, s3_key=s3_key, content_type='image/png', bucket_name=bucket)
                        
            #             # Save to CharacterMedia table for persistence (like gallery images)
            #             db_character_media = CharacterMedia(
            #                 user_id=user.id,
            #                 character_id=character.id if character else None,
            #                 media_type="image",
            #                 s3_path=s3_key,
            #             )
            #             db.add(db_character_media)
            #             await db.commit()
            #             await db.refresh(db_character_media)
            #             print('Uploaded chat image to S3, s3_key:', s3_key)
            #             print('Saved to CharacterMedia table, id:', db_character_media.id)
            #             # Store S3 key instead of presigned URL for non-expiring access
            #             image_urls.append({"s3_key": s3_key, "presigned_s3_url": presigned_s3_url})
            #         except Exception:
            #             pass
    
    except Exception:
        # Do not fail the chat endpoint if image generation errors occur; just log optionally
        try:
            print('Image generation hook error', flush=True)
        except Exception:
            pass

    if image_urls:
        is_media_available = True
        # For chat-generated media we use the 'chat_image' media_type to
        # differentiate gallery/chat assets from regular user-uploaded images.
        media_type = "chat_image"
        dict_s3_url_media = image_urls[0] if len(image_urls) == 1 else None
        s3_url_media = dict_s3_url_media.get('s3_key') if dict_s3_url_media else None
        presigned_s3_url_media = dict_s3_url_media.get('presigned_s3_url') if dict_s3_url_media else None
        await deduct_user_coins(db, user.id, character_id, "chat_image")
    else:
        is_media_available = False
        media_type = None
        dict_s3_url_media = None
        s3_url_media = None
        presigned_s3_url_media = None

    new_message = ChatMessage(
        session_id=chat.session_id,
        user_id=user.id,
        character_id=chat.character_id,
        user_query=chat.user_query,
        ai_message=chat_output,
        context_window=token_count,
        is_media_available=is_media_available,
        media_type=media_type,
        s3_url_media=s3_url_media,
    )
    db.add(new_message)
    await db.commit()
    await deduct_user_coins(db, user.id, character_id=character_id, media_type="chat")
    payload = {"chat_response": chat_output,
               "is_media_available": is_media_available,
               "media_type": media_type,
               "s3_url_media": presigned_s3_url_media}
    
    # Include character id and username in payload so clients can build a pretty slug
    try:
        if character:
            payload["character"] = {"id": getattr(character, 'id', None), "username": getattr(character, 'username', None)}
    except Exception:
        pass

    return JSONResponse(content=payload, status_code=200)

@router.get("/get-messages", response_model=List[MessageRead])
def get_chat_messages(chat_id: int, user=Depends(get_current_user)):
    """Get paginated chat history."""
    # TODO: Implement message retrieval
    raise NotImplementedError

@router.post("/{chat_id}/messages", response_model=MessageRead)
def send_message(chat_id: int, message: MessageCreate, user=Depends(get_current_user)):
    """Send a message and get AI response (non-streaming)."""
    # TODO: Implement non-streaming AI reply
    raise NotImplementedError

@router.get("/{chat_id}/messages/stream")
async def stream_message(chat_id: int, content: str, user=Depends(get_current_user)):
    """
    Stream AI response for a user message using OpenAI (chunked JSON).
    This is a fully implemented example endpoint.
    """
    async def event_stream():
        # TODO: Replace with real ChatService and OpenAI streaming
        for chunk in ["Hello, ", "this is ", "a streamed ", "AI reply."]:
            await asyncio.sleep(0.3)
            yield f'{json.dumps({"content": chunk})}\n'
        yield '[DONE]\n'
    return StreamingResponse(event_stream(), media_type="text/event-stream")

