"""
Character endpoints for AI Friend Chatbot.
"""
import json
from fastapi import APIRouter, Depends, HTTPException, status
import os
import re
from fastapi.responses import JSONResponse
from sqlalchemy import select, delete, insert, func, Integer, cast
from app.schemas.character import CharacterCreate, CharacterRead, CharacterIdIn, CharacterEdit
from app.api.v1.deps import get_current_user
from app.core.database import get_db
from app.models.character import Character, CharacterStats
from app.models.chat import ChatMessage
from app.models.user import User
from app.models.subscription import CoinTransaction
from app.core.config import settings
from app.core.aws_s3 import upload_to_s3_file, get_file_from_s3_url
from app.core.aws_s3 import generate_presigned_url, delete_s3_object
from app.services.character_media import generate_image, build_character_prompt, build_character_prompt_and_json, \
                    enhance_prompt, generate_filename_timestamped
from app.api.v1.deps import get_headers_api
from app.core.aws_s3 import generate_presigned_url
from app.services.app_config import get_config_value_from_cache
from sqlalchemy.ext.asyncio import AsyncSession
from typing import List, Union
import base64
from io import BytesIO
import datetime
from app.services.subscription import check_user_wallet, deduct_user_coins
from app.models.character_media import CharacterMedia
import requests
from app.services.redis_cache import del_cached


router = APIRouter()


def _normalize_choice_field(value: str | None) -> str | None:
    """
    Normalize fields that may accidentally contain asset paths or filenames
    (e.g. "../../assets/.../Indian.png"). Return the basename without extension
    and trimmed whitespace. If input is empty/None, return as-is.
    """
    if not value:
        return value
    try:
        # If it looks like a path, extract the basename
        base = os.path.basename(value)
        # Remove extension if present
        name, _ext = os.path.splitext(base)
        name = name.strip()
        # Replace underscores/hyphens with spaces for nicer display
        name = name.replace('_', ' ').replace('-', ' ').strip()
        return name
    except Exception:
        return value

@router.post("/create")
async def create_character(
    character: CharacterCreate,
    user=Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """Create a new AI friend character and generate its image."""
    #await check_user_wallet(db, user.id, "character")
    positive_prompt = await get_config_value_from_cache("IMAGE_POSITIVE_PROMPT")
    negative_prompt = await get_config_value_from_cache("IMAGE_NEGATIVE_PROMPT")
    
    # Get both text prompt and JSON for storage
    text_prompt, prompt_json, identity_block, physique_block, clothing_block, background_block, camera_block, quality_block = await build_character_prompt_and_json(
                    name=character.name,
                    bio=character.bio,
                    gender=character.gender,
                    style=character.style,
                    ethnicity=character.ethnicity,
                    age=character.age,
                    eye_colour=character.eye_colour,
                    hair_style=character.hair_style,
                    hair_colour=character.hair_colour,
                    body_type=character.body_type,
                    breast_size=character.breast_size,
                    butt_size= "",  # character.butt_size
                    dick_size=character.dick_size,
                    personality=character.personality,
                    voice_type=character.voice_type,
                    relationship_type=character.relationship_type,
                    clothing=character.clothing,
                    special_features=character.special_features,
                    background=character.background,
                    positive_prompt=positive_prompt,
                    negative_prompt=negative_prompt
                )
    print('Prompt Generated:', text_prompt)
    guardrails = """
    This is a character creation prompt. Ensure that the generated character adheres to the following guidelines strictly:
    - The character should be dressed appropriately and should not be nude.
    - Boobs should always be covered with proper outfit. Apply random outfit/clothing if not provided by user.
    - Avoid any explicit or inappropriate content.
    """
    text_prompt = text_prompt + "\n" + guardrails
    #print(f'JSON Prompt to Store (length: {len(prompt_json)}): {prompt_json[:200]}...')


    username = await get_config_value_from_cache("PRIVATE_CLOUD_API_USERNAME")
    personality = character.personality or "friendly and engaging"
    personality += ',' + character.voice_type or ""
    personality += ',' + character.relationship_type or ""
    url_character_prompt = "https://api.lightspeedcloud.ai/api/v1/character/create"
    #identity = character.name + ',' + character.style
    json_data = {"name": character.name,
                 "age": character.age,
                 "gender": character.gender,
                 "physical_characteristics": physique_block,
                 "clothing": character.clothing,
                 "personality": character.personality,
                 "interests_hobbies": character.bio,
                 "setting": character.background,
                 "username": username}
    headers = await get_headers_api()
    response = requests.post(url_character_prompt,headers=headers, json=json_data, timeout=60)
    prompt_enhanced = ''
    if response.status_code == 200:
        prompt_enhanced = response.json().get('data')
    print('Character Prompt API Response:', response.status_code, prompt_enhanced)
    if prompt_enhanced:
        final_prompt = json.dumps(prompt_enhanced)
    else:
        final_prompt = text_prompt
    print(f'Final Text Prompt : {final_prompt}')
    #cinematic photo, highly realistic, highly detailed, High Quality 8k
    if character.style.lower() == "realistic":
        ai_model = "xl_pornai"
    elif character.style.lower() == "anime" :
        ai_model = "xl_anime"
    else:
        ai_model = "xl_pornai"
    response = await generate_image(final_prompt, num_images = 1, initial_image = None, size_orientation = "portrait", ai_model=ai_model)
    print('Image Generation Response:', response)
    if response.status_code == 200:
        json_resp = response.json()
        image_data = json_resp["data"]["images_data"]
        base64_data = image_data[0]
        image_data_bs4 = base64.b64decode(base64_data)
        image_file = BytesIO(image_data_bs4)

        is_image_generated = True

    if not is_image_generated:
        raise HTTPException(status_code=504, detail="Image generation timed out")

    file_extension = "png"
    file_type = "character_image"
    # 3. Save image to S3 storage
    user_role = (user.role if user else "USER").lower()
    user_id = str(user.id)
    filename = await generate_filename_timestamped(character.name)
    s3_key = f"{file_type}/{user_role}/{user_id}/{filename}.{file_extension}"
    bucket_name = await get_config_value_from_cache("AWS_BUCKET_NAME")
    s3_key, presigned_s3_url = await upload_to_s3_file(file_obj = image_file,
                    s3_key = s3_key,
                    content_type = "image/png", 
                    bucket_name = bucket_name)
 
    # Generate clean username for chat URLs (not timestamped)
    clean_username = character.name.lower().replace(" ", "-")
    clean_username = re.sub(r'[^a-z0-9-]+', '', clean_username)
    clean_username = re.sub(r'-+', '-', clean_username).strip('-')
    
    # Ensure username is not empty and add user ID for uniqueness
    if not clean_username:
        clean_username = f"character-{user.id}"
    else:
        clean_username = f"{clean_username}-{user.id}"
    
    # # 4. Save character to DB (example, adjust fields as needed)

    db_character = Character(
                        username=clean_username,
                        bio = character.bio,
                        user_id=user.id,
                        name=character.name,
                        gender=character.gender,
                        age=character.age,
                        ethnicity=_normalize_choice_field(character.ethnicity),
                        style=character.style,
                        body_type=character.body_type,
                        hair_colour=character.hair_colour,
                        hair_style=character.hair_style,
                        clothing=character.clothing,
                        eye_colour=character.eye_colour,
                        breast_size=character.breast_size,
                        butt_size=character.butt_size,
                        dick_size=character.dick_size,
                        personality=character.personality,
                        voice_type=character.voice_type,
                        relationship_type=character.relationship_type,
                        special_features=_normalize_choice_field(character.special_features),
                        prompt=prompt_json,  # Store JSON instead of text prompt
                        image_url_s3=s3_key,
                        privacy=character.privacy,
                        onlyfans_url=character.onlyfans_url,
                        fanvue_url=character.fanvue_url,
                        tiktok_url=character.tiktok_url,
                        instagram_url=character.instagram_url,
                    )

    db.add(db_character)
    await db.commit()
    await db.refresh(db_character)
    await deduct_user_coins(db, user.id, db_character.id, "character")
    return JSONResponse(content={"message": "Character created successfully",
                                     "image_path" : presigned_s3_url}, status_code=200)
    

@router.post("/edit-by-id")
async def edit_character(
    character: CharacterEdit,
    user=Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    
    """Edit an existing character by its ID."""

    result = await db.execute(
        select(Character).where(Character.id == character.character_id, Character.user_id == user.id)
    )
    db_character = result.scalars().first()
    if not db_character:
        raise HTTPException(status_code=404, detail="Character not found")

    # Update fields
    db_character.name = character.name
    db_character.username = character.username
    db_character.bio = character.bio
    db_character.privacy = character.privacy
    db_character.onlyfans_url = character.onlyfans_url
    db_character.fanvue_url = character.fanvue_url
    db_character.tiktok_url = character.tiktok_url
    db_character.instagram_url = character.instagram_url

    await db.commit()
    await db.refresh(db_character)
    # Invalidate cached default characters in case admin edited a default
    try:
        await del_cached("characters:fetch-default")
    except Exception:
        pass
    return JSONResponse(content={"message": "Character updated successfully"},
                        status_code=200)


@router.post("/fetch-loggedin-user", response_model=List[CharacterRead])
async def list_characters(
    user=Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """List all characters for the logged-in user."""
    result = await db.execute(
        select(Character)
        .where(Character.user_id == user.id)
        .order_by(Character.id.desc())
    )
    characters = result.scalars().all()
    updated_characters = []
    for character in characters:
        char_dict = CharacterRead.model_validate(character).model_dump()
        s3_value = char_dict.get("image_url_s3")
        if s3_value:
            presigned = await generate_presigned_url(s3_key=s3_value)
            char_dict["image_url_s3"] = presigned
        updated_characters.append(CharacterRead(**char_dict))
    return updated_characters


@router.get("/fetch-default", response_model=List[CharacterRead])
async def list_characters(
    db: AsyncSession = Depends(get_db)
):
    """List all default characters created by admin (accessible without authentication)."""
    admin_user_ids_result = await db.execute(
        select(User.id).where(User.role == "ADMIN")
    )
    admin_user_ids = [row[0] for row in admin_user_ids_result.fetchall()]

    result = await db.execute(
        select(Character)
        .where(Character.user_id.in_(admin_user_ids))
        .order_by(Character.id.desc())
    )
    characters = result.scalars().all()
    # Replace image_url_s3 with presigned URL
    updated_characters = []
    for character in characters:
        char_dict = CharacterRead.model_validate(character).model_dump()
        s3_value = char_dict.get("image_url_s3")
        if s3_value:
            presigned = await generate_presigned_url(s3_key=s3_value)
            char_dict["image_url_s3"] = presigned
        updated_characters.append(CharacterRead(**char_dict))
    return updated_characters

@router.get("/fetch-by-id/{character_id}")
async def get_character(
    character_id: str,
    user=Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """Get character details."""
    # character ids are stored as strings in the DB models; coerce incoming
    # path param to string to avoid SQL type mismatch errors
    character_id = str(character_id)
    print(f"Fetching character with ID: {character_id} for user ID: {user.id}")
    result = await db.execute(
        select(Character)
        .where(Character.id == character_id, Character.user_id == user.id)
    )
    character = result.scalars().first()
    if not character:
        raise HTTPException(status_code=404, detail="Character not found")
    
    character_dict = CharacterRead.model_validate(character).model_dump()
    # Convert datetime fields to ISO format
    if "created_at" in character_dict and isinstance(character_dict["created_at"], datetime.datetime):
        character_dict["created_at"] = character_dict["created_at"].isoformat()

    return JSONResponse(content={"character": character_dict},
                        status_code=200)

@router.get("/by-slug/{slug}")
async def get_character_by_slug(
    slug: str,
    db: AsyncSession = Depends(get_db)
):
    """
    Get character by slug (e.g., 'luna-guide-9f3b12a4').
    Extracts the short ID from the slug and finds matching character.
    Public endpoint - no auth required.
    """
    # Extract short ID from slug (last segment after hyphens)
    parts = slug.split('-')
    if not parts:
        raise HTTPException(status_code=400, detail="Invalid slug format")
    
    short_id = parts[-1]
    
    # Validate short ID format (alphanumeric, 8+ chars)
    if not short_id or not re.match(r'^[a-z0-9]{8,}$', short_id, re.IGNORECASE):
        raise HTTPException(status_code=400, detail="Invalid slug format")
    
    # Find character where ID starts with short_id
    # Using LIKE with pattern matching for efficient DB query
    result = await db.execute(
        select(Character).where(
            Character.id.like(f"{short_id}%")
        )
    )
    character = result.scalars().first()
    
    if not character:
        raise HTTPException(status_code=404, detail="Character not found")
    
    character_dict = CharacterRead.model_validate(character).model_dump()
    
    # Generate presigned URL if image exists
    if character_dict.get("image_url_s3"):
        character_dict["image_url_s3"] = await generate_presigned_url(
            s3_key=character_dict["image_url_s3"]
        )
    
    # Convert datetime fields to ISO format
    if "created_at" in character_dict and isinstance(character_dict["created_at"], datetime.datetime):
        character_dict["created_at"] = character_dict["created_at"].isoformat()
    if "updated_at" in character_dict and isinstance(character_dict["updated_at"], datetime.datetime):
        character_dict["updated_at"] = character_dict["updated_at"].isoformat()
    
    return JSONResponse(content={"character": character_dict}, status_code=200)

@router.get("/fetch-by-user-id/{user_id}")
async def get_characters_by_user_id(
    user_id: str,
    user=Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """Get all characters for a given user_id (admin or public use)."""
    # user ids are string-based in our models; coerce to string
    user_id = str(user_id)
    print(f"Fetching characters for user ID: {user_id}")
    result = await db.execute(
        select(Character)
        .where(Character.user_id == user_id)
    )
    characters = result.scalars().all()
    output = []
    for character in characters:
        character_dict = CharacterRead.model_validate(character).model_dump()
        if character_dict["image_url_s3"]:
            character_dict["image_url_s3"] = await generate_presigned_url(s3_key = character_dict["image_url_s3"])
        if "created_at" in character_dict and isinstance(character_dict["created_at"], datetime.datetime):
            character_dict["created_at"] = character_dict["created_at"].isoformat()
        if "updated_at" in character_dict and isinstance(character_dict["updated_at"], datetime.datetime):
            character_dict["updated_at"] = character_dict["updated_at"].isoformat()

        output.append({"character": character_dict})
    return JSONResponse(content={"characters": output}, status_code=200)

@router.post("/delete/{character_id}")
async def delete_character_by_user(
    character_id: str,
    user=Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """Allow a logged-in user to delete one of their own characters."""
    # Ensure character exists and belongs to the current user
    # if admin role, allow deletion of any character
    # ensure we compare string IDs to string columns in the DB
    character_id = str(character_id)
    if user.role.lower() == "admin":
        result = await db.execute(
            select(Character).where(Character.id == character_id)
        )
    else:
        result = await db.execute(
            select(Character).where(Character.id == character_id, Character.user_id == user.id)
        )
    character = result.scalars().first()
    if not character:
        # If not found, return 404 to avoid leaking whether the id exists for other users
        raise HTTPException(status_code=404, detail="Character not found")

    # Attempt to delete main character image from S3 (best-effort)
    try:
        s3_key = getattr(character, 'image_url_s3', None)
        if s3_key:
            await delete_s3_object(s3_key)
    except Exception:
        pass

    # Delete any CharacterMedia objects and their S3 files
    try:
        media_rows = await db.execute(select(CharacterMedia).where(CharacterMedia.character_id == character.id))
        media_items = media_rows.scalars().all()
        for m in media_items:
            try:
                if getattr(m, 's3_path', None):
                    await delete_s3_object(m.s3_path)
            except Exception:
                pass
    except Exception:
        pass
    
    # Remove CharacterMedia records
    try:
        await db.execute(delete(CharacterMedia).where(CharacterMedia.character_id == character.id))
        await db.commit()
    except Exception as e:
        # best-effort: if media records cannot be removed, log the error
        raise HTTPException(status_code=500, detail=f"Failed to delete character media for character {character_id} {e}")
    
    # Remove dependent chat messages referencing this character to satisfy foreign key
    try:
        # Use a single DELETE statement for efficiency
        await db.execute(delete(ChatMessage).where(ChatMessage.character_id == character.id))
        await db.commit()
    except Exception as e:
        # best-effort: if chat messages cannot be removed, raise a clear error so admin can inspect
        raise HTTPException(status_code=500, detail=f"Failed to delete chat messages referencing character {character_id}: {e}")
    
    # Remove coin transactions referencing this character
    try:
        await db.execute(delete(CoinTransaction).where(CoinTransaction.character_id == character.id))
        await db.commit()
    except Exception as e:
        # best-effort: if coin transactions cannot be removed, raise a clear error so admin can inspect
        raise HTTPException(status_code=500, detail=f"Failed to delete coin transactions referencing character {character_id}: {e}")
    
    # Remove CharacterStats records referencing this character
    try:
        await db.execute(delete(CharacterStats).where(CharacterStats.character_id == character.id))
        await db.commit()
    except Exception as e:
        # best-effort: if character stats cannot be removed, raise a clear error so admin can inspect
        raise HTTPException(status_code=500, detail=f"Failed to delete character stats referencing character {character_id}: {e}")

    # Finally delete the character record
    await db.delete(character)
    await db.commit()

    return {"detail": f"Character {character_id} and related chat messages, media have been deleted"}

@router.get("/message-count")
async def get_character_message_count(
    db: AsyncSession = Depends(get_db)
):
    """Return message counts for all characters as a JSON list of
    {"character_id": <id>, "count_message": <count>}.
    Includes characters with zero messages.
    """
    # Left join characters with chat messages so characters with zero
    # messages are included with count 0.
    result = await db.execute(
        select(Character.id, func.count(ChatMessage.id).label("count"))
        .outerjoin(ChatMessage, ChatMessage.character_id == Character.id)
        .group_by(Character.id)
    )

    rows = result.fetchall()
    counts = []
    for row in rows:
        char_id = row[0]
        cnt = int(row[1]) if row[1] is not None else 0
        counts.append({"character_id": char_id, "count_message": cnt})

    return JSONResponse(content=counts, status_code=200)


@router.post("/likes-message-count")
async def get_characters_stats(
    character_ids: List[Union[int, str]],
    db: AsyncSession = Depends(get_db)
):
    """Return message counts and likes for the provided character IDs.

    Request body: JSON array of character IDs, e.g. [1,2,4]
    Response: list of {"character_id": id, "message_count": n, "likes_count": m}
    """
    if not character_ids:
        return JSONResponse(content=[], status_code=200)

    # Normalize incoming IDs to strings because character IDs are stored
    # as strings (VARCHAR) in the database. Accept numeric or string input
    # from clients but always use string binds so SQL types match.
    normalized_ids: List[str] = []
    for cid in character_ids:
        try:
            # Keep original if already a string; otherwise coerce to string
            normalized_ids.append(str(cid))
        except Exception:
            # skip invalid ids
            continue

    if not normalized_ids:
        # Nothing valid to query
        return JSONResponse(content=[], status_code=200)

    # Get message counts per character (including zero)
    # ChatMessage.character_id is a string column; use string binds.
    msg_stmt = (
        select(ChatMessage.character_id, func.count(ChatMessage.id).label("count"))
        .where(ChatMessage.character_id.in_(normalized_ids))
        .group_by(ChatMessage.character_id)
    )
    msg_result = await db.execute(msg_stmt)
    msg_rows = {row[0]: int(row[1]) for row in msg_result.fetchall()}

    # Aggregate likes from CharacterStats table grouped by character_id
    stats_stmt = (
        select(
            CharacterStats.character_id,
            func.coalesce(func.sum(cast(CharacterStats.liked, Integer)), 0).label("likes_sum"),
        )
        # character_id in CharacterStats is stored as string; use string binds
        .where(CharacterStats.character_id.in_(normalized_ids))
        .group_by(CharacterStats.character_id)
    )
    stats_result = await db.execute(stats_stmt)
    stats_rows = {row[0]: {"likes": int(row[1])} for row in stats_result.fetchall()}

    output = []
    for cid in normalized_ids:
        stats_for_c = stats_rows.get(cid, {"likes": 0})
        output.append({
            "character_id": cid,
            "message_count": msg_rows.get(cid, 0),
            "likes_count": stats_for_c.get("likes", 0),
        })

    return JSONResponse(content=output, status_code=200)

@router.post("/like-status-by-user")
async def get_character_like_status(
    payload: CharacterIdIn,
    user=Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """Return whether the logged-in user has liked a specific character."""
    # Coerce incoming id to string to match DB column type
    character_id = str(payload.character_id)
    result = await db.execute(
        select(CharacterStats).where((CharacterStats.user_id == user.id) & (CharacterStats.character_id == character_id))
    )
    stats = result.scalars().first()
    liked = bool(stats.liked) if stats else False
    return JSONResponse(content={"is_liked": liked}, status_code=200)

@router.post("/like")
async def like_character(
    payload: CharacterIdIn,
    user=Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """Allow a logged-in user to 'like' a character."""
    # Coerce incoming id to string to match DB column type
    character_id = str(payload.character_id)
    # Check if character exists and can be accessed by the user
    result = await db.execute(
        select(Character).where((Character.id == character_id) & ((Character.user_id == user.id) | (Character.privacy == 'public')))
    )
    character = result.scalars().first()
    if not character:
        raise HTTPException(status_code=404, detail="Character not found or inaccessible")

    # Check if the user has already liked this character
    existing_like_result = await db.execute(
        select(CharacterStats).where((CharacterStats.user_id == user.id) & (CharacterStats.character_id == character_id))
    )
    existing_like = existing_like_result.scalars().first()
    if existing_like:
        raise HTTPException(status_code=400, detail="Character already liked by user")
    # Record the like in CharacterStats table
    new_like = CharacterStats(user_id=user.id, character_id=character_id, liked=True)
    db.add(new_like)
    await db.commit()

    return JSONResponse(content={"detail": f"Character {character_id} liked"}, status_code=200)

@router.post("/my-character-ids")
async def get_my_character_ids(user=Depends(get_current_user), user_id: str = None, db: AsyncSession = Depends(get_db)):
    """Get all previous chats for a user (admin) or current user in descending order of creation."""
    query_user_id = user_id if user_id is not None else user.id
    # Only return chats that are associated with characters created by the query user.
    # This lets a user see chats for their own characters (even if the chat messages were
    # sent by other users).
    q_chars = await db.execute(select(Character.id).where(Character.user_id == query_user_id))
    char_ids = q_chars.scalars().all()

    return {"character_ids": char_ids}
