from __future__ import annotations
from typing import Optional
import logging
import re

from fastapi import APIRouter, Depends, HTTPException, Request, status
from fastapi.responses import JSONResponse
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func

from app.models.private_content import MediaPack, MediaPackMedia, UserMediaPackAccess, CharacterMediaLike
from app.models.character_media import CharacterMedia
from app.core.aws_s3 import generate_presigned_url
from app.core.config import settings
from app.core.database import get_db
from app.api.v1.deps import get_current_user
from app.models.user import User
from app.schemas.private_content import PrivateContentRequest, MediaPackRequest, MediaIdLike, ListMediaIdLike
router = APIRouter()
logger = logging.getLogger(__name__)


@router.post("/get-pack")
async def get_private_content_pack(
    request: PrivateContentRequest,
    user=Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    character_id = request.character_id
    if not user:
        raise HTTPException(status_code=404, detail="User not found")

    # Retrieve all private content packs for the given character and include whether
    # the current user has access to each pack. We left-join UserMediaPackAccess
    # using both media_pack_id and the current user's id so that if there's no row
    # the joined value will be None (access == False).

    stmt = (
        select(MediaPack, UserMediaPackAccess)
        .outerjoin(
            UserMediaPackAccess,
            (UserMediaPackAccess.media_pack_id == MediaPack.id) & (UserMediaPackAccess.user_id == user.id),
        )
        .where(MediaPack.character_id == character_id)
    )

    result = await db.execute(stmt)
    rows = result.all()

    packs: list[MediaPack] = []
    for pack, access_row in rows:
        # attach a boolean attribute `access` to the ORM object so callers can
        # see whether the current user has access (True) or not (False).
        if user.role.lower() == "admin":
            setattr(pack, "access", True)
        else:
            setattr(pack, "access", bool(access_row))
        presigned = await generate_presigned_url(getattr(pack, "thumbnail_s3_path", None))
        setattr(pack, "presigned_thumbnail_s3_path", presigned)
        # total_likes = sum of likes for all media items in this pack
        count_stmt = (
            select(func.count(CharacterMediaLike.id))
            .select_from(CharacterMediaLike)
            .join(MediaPackMedia, MediaPackMedia.character_media_id == CharacterMediaLike.character_media_id)
            .where(MediaPackMedia.media_pack_id == pack.id)
        )
        count_res = await db.execute(count_stmt)
        total_likes = count_res.scalar() or 0
        setattr(pack, "total_likes", int(total_likes))
        packs.append(pack)

    return packs

@router.get("/pack-by-slug/{slug}")
async def get_pack_by_slug(
    slug: str,
    user=Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """
    Get media pack by slug (e.g., 'vacation-photos-5a2b9c3d').
    Extracts the short ID from the slug and finds matching pack.
    Requires authentication.
    """
    if not user:
        raise HTTPException(status_code=401, detail="Authentication required")
    
    # Extract short ID from slug (last segment after hyphens)
    parts = slug.split('-')
    if not parts:
        raise HTTPException(status_code=400, detail="Invalid slug format")
    
    short_id = parts[-1]
    
    # Validate short ID format (alphanumeric, 8+ chars)
    if not short_id or not re.match(r'^[a-z0-9]{8,}$', short_id, re.IGNORECASE):
        raise HTTPException(status_code=400, detail="Invalid slug format")
    
    # Find pack where ID starts with short_id
    stmt = (
        select(MediaPack, UserMediaPackAccess)
        .outerjoin(
            UserMediaPackAccess,
            (UserMediaPackAccess.media_pack_id == MediaPack.id) & (UserMediaPackAccess.user_id == user.id),
        )
        .where(MediaPack.id.like(f"{short_id}%"))
    )
    
    result = await db.execute(stmt)
    row = result.first()
    
    if not row:
        raise HTTPException(status_code=404, detail="Pack not found")
    
    pack, access_row = row
    
    # Attach access info
    if user.role.lower() == "admin":
        setattr(pack, "access", True)
    else:
        setattr(pack, "access", bool(access_row))
    
    presigned = await generate_presigned_url(getattr(pack, "thumbnail_s3_path", None))
    setattr(pack, "presigned_thumbnail_s3_path", presigned)
    
    # Calculate total likes
    count_stmt = (
        select(func.count(CharacterMediaLike.id))
        .select_from(CharacterMediaLike)
        .join(MediaPackMedia, MediaPackMedia.character_media_id == CharacterMediaLike.character_media_id)
        .where(MediaPackMedia.media_pack_id == pack.id)
    )
    count_res = await db.execute(count_stmt)
    total_likes = count_res.scalar() or 0
    setattr(pack, "total_likes", int(total_likes))
    
    return pack

@router.post("/get-media-in-pack")
async def get_media_in_pack(
    payload: MediaPackRequest,
    user=Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    pack_id = payload.pack_id
    if not user:
        raise HTTPException(status_code=404, detail="User not found")

    # Retrieve all media for the given pack id and the associated character media
    stmt = (
        select(MediaPackMedia, CharacterMediaLike, CharacterMedia)
        .join(MediaPack, MediaPack.id == MediaPackMedia.media_pack_id)
        .join(CharacterMedia, CharacterMedia.id == MediaPackMedia.character_media_id)
        .outerjoin(
            CharacterMediaLike,
            (CharacterMediaLike.character_media_id == MediaPackMedia.character_media_id) & (CharacterMediaLike.user_id == user.id),
        )
        .where(MediaPackMedia.media_pack_id == pack_id)
    )

    result = await db.execute(stmt)
    rows = result.all()

    packs: list[MediaPackMedia] = []
    for media_pack_media, like_row, char_media in rows:
        # attach a boolean attribute `liked` to indicate if the user liked this media
        setattr(media_pack_media, "liked", bool(like_row))
        # source s3 path comes from the CharacterMedia row
        s3_path = getattr(char_media, "s3_path", None)
        setattr(media_pack_media, "s3_path", s3_path)
        # also attach mime_type if available
        setattr(media_pack_media, "mime_type", getattr(char_media, "mime_type", None))
        presigned = await generate_presigned_url(s3_path)
        setattr(media_pack_media, "presigned_s3_path", presigned)
        packs.append(media_pack_media)

    return packs

@router.post("/unlock-pack")
async def unlock_media_pack(
    payload: MediaPackRequest,
    user=Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    pack_id = payload.pack_id
    if not user:
        raise HTTPException(status_code=404, detail="User not found")

    # Check if the user already has access
    q = await db.execute(
        select(UserMediaPackAccess).where(
            (UserMediaPackAccess.user_id == user.id) &
            (UserMediaPackAccess.media_pack_id == pack_id)
        )
    )
    access = q.scalars().first()
    if access:
        raise HTTPException(status_code=400, detail="Pack already unlocked")

    # Create access record
    access_record = UserMediaPackAccess(
        user_id=user.id,
        media_pack_id=pack_id
    )
    db.add(access_record)
    await db.commit()
    ######## ADD COIN DEDUCTION LOGIC HERE ########

    #################################################
    return {"is_pack_access":True,"detail": "Pack unlocked successfully"}

@router.post("/like-media")
async def like_media(
    payload: MediaIdLike,
    user=Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    media_id = payload.id
    if not user:
        raise HTTPException(status_code=404, detail="User not found")

    # Check if the user has already liked this media
    q = await db.execute(
        select(CharacterMediaLike).where(
            (CharacterMediaLike.user_id == user.id) &
            (CharacterMediaLike.character_media_id == media_id)
        )
    )
    like = q.scalars().first()
    if like:
        raise HTTPException(status_code=400, detail="Media already liked")

    # Create like record
    like_record = CharacterMediaLike(
        user_id=user.id,
        character_media_id=media_id
    )
    db.add(like_record)
    await db.commit()

    return {"detail": "Media liked successfully"}

@router.post("/check-media-liked")
async def check_media_liked(
    payload: ListMediaIdLike,
    user=Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    list_media_id = payload.media_ids or []

    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    # If empty list provided, return empty results
    if not list_media_id:
        return {"likes": []}

    # Fetch all likes for this user for the provided media ids in one query
    q = await db.execute(
        select(CharacterMediaLike.character_media_id).where(
            (CharacterMediaLike.user_id == user.id) &
            (CharacterMediaLike.character_media_id.in_(list_media_id))
        )
    )
    liked_ids = set(q.scalars().all())

    # Return list of objects mapping id -> liked status
    results = [{"id": m_id, "is_liked": (m_id in liked_ids)} for m_id in list_media_id]
    return {"likes": results}
