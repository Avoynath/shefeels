from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select
from sqlalchemy.exc import IntegrityError
from sqlalchemy import text
from app.models.user import User
from app.models.user import UserActivation
from app.models.subscription import Order
from app.schemas.user import UserRead, AdminUserCreateRequest
from app.api.v1.deps import get_db
from app.api.v1.deps import require_admin
from app.models.character import Character
from app.models.chat import ChatMessage as Chat
from app.schemas.character import CharacterRead
from app.schemas.chat import MessageRead
from app.schemas.user import UserEditRequest
from app.core.templates import templates
from app.services.app_config import get_config_value_from_cache
from app.services.email import send_email
from passlib.context import CryptContext
from passlib.hash import bcrypt
from secrets import token_urlsafe
import datetime
import uuid
from app.core.security import (
    verify_password,
    create_access_token,
    create_refresh_token, hash_password
)
import secrets
import string
from app.schemas.engagement_stats import EngagementStats
from sqlalchemy import func, distinct
from datetime import timedelta

router = APIRouter()
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

@router.get("/", response_model=list[UserRead], dependencies=[Depends(require_admin)])
async def get_all_users(db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(User))
    users = result.scalars().all()
    # Attach telegram_username if available via Order (or Subscription -> Order)
    user_ids = [str(u.id) for u in users if getattr(u, 'id', None) is not None]
    telegram_map: dict[str, str | None] = {}
    # if user_ids:
    #     # Fetch telegram_username from orders for these users (prefer most recent order)
    #     orders_stmt = select(Order.user_id, Order.telegram_username, Order.created_at).where(Order.user_id.in_(user_ids)).order_by(Order.created_at.desc())
    #     orders_rows = await db.execute(orders_stmt)
    #     for uid, tusername, _created in orders_rows.fetchall():
    #         uid_str = str(uid) if uid is not None else None
    #         if uid_str and uid_str not in telegram_map and tusername:
    #             telegram_map[uid_str] = tusername

    # Precompute total_revenue per user (sum of successful orders: subtotal_at_apply)
    # This mirrors the calculation used by the dashboard top-spenders endpoint.
    totals_map: dict[str, float] = {}
    if user_ids:
        totals_stmt = select(Order.user_id, func.coalesce(func.sum(Order.subtotal_at_apply), 0.0)).where(
            Order.user_id.in_(user_ids), Order.status == 'success'
        ).group_by(Order.user_id)
        totals_rows = await db.execute(totals_stmt)
        for uid, s in totals_rows.fetchall():
            try:
                totals_map[str(uid)] = float(s) if s is not None else 0.0
            except Exception:
                totals_map[str(uid)] = 0.0
    # Precompute which users have at least one successful payment (order.status == 'success')
    paid_set: set[str] = set()
    if user_ids:
        paid_stmt = select(distinct(Order.user_id)).where(Order.user_id.in_(user_ids), Order.status == 'success')
        paid_rows = await db.execute(paid_stmt)
        for (uid,) in paid_rows.fetchall():
            if uid is not None:
                paid_set.add(str(uid))

    out = []
    for user in users:
        # Normalize base user dict via Pydantic to ensure fields like dates are typed
        base = UserRead.model_validate(user).model_dump()
        #base['telegram_username'] = telegram_map.get(str(user.id)) if str(user.id) in telegram_map else None
        # Expose total_revenue for the frontend (aligned with top-spenders calculation)
        base['total_revenue'] = totals_map.get(str(user.id), 0.0)
        base['has_paid'] = str(user.id) in paid_set or (base.get('total_revenue', 0.0) > 0)
        out.append(base)

    return out

@router.post("/create", dependencies=[Depends(require_admin)])
async def create_user_by_admin(user_data: AdminUserCreateRequest, db: AsyncSession = Depends(get_db)):
    """
    Create a new user by admin. User receives an email with activation link.
    """
    try:
        company_address = await get_config_value_from_cache("ADDRESS")
        support_email = await get_config_value_from_cache("SUPPORT_EMAIL")
        app_name = await get_config_value_from_cache("APP_NAME")
        # Check if user already exists

        existing_user_query = select(User).where(User.email == user_data.email.lower())
        existing_user = (await db.execute(existing_user_query)).scalar_one_or_none()
        
        user_email = user_data.email.lower()
        # if user with same email exists, delete the unverified one first from User
        stmt_existing = select(User).where(User.email == user_email)
        existing_user: User | None = (await db.execute(stmt_existing)).scalar_one_or_none()
        if existing_user and not existing_user.is_email_verified:
            print("[DEBUG] Deleting existing unverified user from User")
            await db.delete(existing_user)
            await db.commit()
        if existing_user and existing_user.is_email_verified:
            print("[DEBUG] User with email already exists and is verified. Reset your password instead.")
            raise HTTPException(status_code=400, detail="Email already registered")
        
        # generate a strong random password (alphanumeric + symbols)
        def _generate_strong_password(length: int = 10) -> str:
            alphabet = string.ascii_letters + string.digits + "!@#$%^&*()-_=+"
            while True:
                pwd = ''.join(secrets.choice(alphabet) for _ in range(length))
                if (
                    any(c.islower() for c in pwd)
                    and any(c.isupper() for c in pwd)
                    and any(c.isdigit() for c in pwd)
                    and any(c in "!@#$%^&*()-_=+" for c in pwd)
                ):
                    return pwd

        new_password = _generate_strong_password(10)

        # update user's password in DB before sending the email
        hashed_password = hash_password(new_password)
        await db.commit()

        db_user = User(
            email=user_data.email.lower(),
            hashed_password=hashed_password,
            full_name=user_data.full_name,
            role=user_data.role,
            is_active=True,
            is_email_verified=True,
        )
        db.add(db_user)
        await db.commit()
        await db.refresh(db_user)
        
        html = templates.get_template("create_user.html").render(
            full_name=db_user.full_name or "Explorer",
            support_email=support_email,
            app_name=app_name,
            company_address=company_address,
            password=new_password,
            year=datetime.datetime.now(datetime.timezone.utc).year,
        )
        await send_email(
        subject="Honey Love AI Character password",
        to=[db_user.email],
        html=html,
    )
        return {"message": "If the e-mail exists, password was sent to email."}
    except Exception as e:
        await db.rollback()
        print(f"[ERROR] Failed to create user: {e}")
        raise HTTPException(status_code=500, detail="Failed to create user")

@router.post("/deactivate/{user_id}", dependencies=[Depends(require_admin)])
async def deactivate_user(user_id: str, db: AsyncSession = Depends(get_db)):
    user_id = str(user_id)
    result = await db.execute(select(User).where(User.id == user_id))
    user = result.scalar_one_or_none()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    user.is_active = False
    await db.commit()
    await db.refresh(user)
    return {"detail": f"User {user_id} has been deactivated"}

@router.post("/activate/{user_id}", dependencies=[Depends(require_admin)])
async def activate_user(user_id: str, db: AsyncSession = Depends(get_db)):
    user_id = str(user_id)
    result = await db.execute(select(User).where(User.id == user_id))
    user = result.scalar_one_or_none()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    user.is_active = True
    await db.commit()
    await db.refresh(user)
    return {"detail": f"User {user_id} has been activated"}

@router.put("/edit/{user_id}", dependencies=[Depends(require_admin)])
async def edit_user(user_id: str, payload: UserEditRequest, db: AsyncSession = Depends(get_db)):
    user_id = str(user_id)
    result = await db.execute(select(User).where(User.id == user_id))
    user = result.scalar_one_or_none()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    if payload.full_name is not None:
        user.full_name = payload.full_name
    if payload.role is not None:
        user.role = payload.role
    await db.commit()
    await db.refresh(user)
    
    return {"detail": f"User {user_id} updated", "user": {"id": user.id, "full_name": user.full_name, "role": user.role}}
@router.post("/delete/{user_id}", dependencies=[Depends(require_admin)])
async def delete_user(user_id: str, db: AsyncSession = Depends(get_db)):
    user_id = str(user_id)
    # Delete related records first
    await db.execute(
        text("DELETE FROM email_verifications WHERE user_id = :user_id"),
        {"user_id": user_id}
    )
    await db.execute(
        text("DELETE FROM password_resets WHERE user_id = :user_id"),
        {"user_id": user_id}
    )
    await db.execute(
        text("DELETE FROM refresh_tokens WHERE user_id = :user_id"),
        {"user_id": user_id}
    )

    # Remove chat messages referencing this user to avoid FK constraint errors
    try:
        await db.execute(
            text("DELETE FROM chat_messages WHERE user_id = :user_id"),
            {"user_id": user_id}
        )
    except Exception as e:
        # If the table doesn't exist or another error occurs, log and continue
        print(f"[INFO] Failed to delete chat_messages for user {user_id} (may not exist): {e}")
    
    # Try to delete user_activations if table exists
    try:
        await db.execute(
            text("DELETE FROM user_activations WHERE user_id = :user_id"),
            {"user_id": user_id}
        )
    except Exception as e:
        # Table doesn't exist yet, skip this deletion
        print(f"[INFO] user_activations table not found, skipping: {e}")
    
    await db.execute(
        text("DELETE FROM users WHERE id = :user_id"),
        {"user_id": user_id}
    )
    await db.commit()
    return {"detail": f"User {user_id} and related records deleted"}

@router.get("/engagement-stats/{user_id}", response_model=EngagementStats, dependencies=[Depends(require_admin)])
async def get_user_engagement_stats(user_id: str, db: AsyncSession = Depends(get_db)):
    user_id = str(user_id)
    # Total messages
    total_messages = await db.scalar(select(func.count(Chat.id)).where(Chat.user_id == user_id))

    # Total sessions
    session_count = await db.scalar(select(func.count(distinct(Chat.session_id))).where(Chat.user_id == user_id))

    # Avg messages per session
    avg_per_session = total_messages / session_count if session_count else 0

    # Messages per character
    char_counts = await db.execute(
        select(Chat.character_id, func.count(Chat.id))
        .where(Chat.user_id == user_id)
        .group_by(Chat.character_id)
    )
    messages_per_character = {str(cid): count for cid, count in char_counts.fetchall()}

    # Media type breakdown: 'image' or NULL (chat)
    mt_counts = await db.execute(
        select(Chat.media_type, func.count(Chat.id))
        .where(Chat.user_id == user_id)
        .group_by(Chat.media_type)
    )
    # Normalize keys: keep 'image' as string, represent NULL as 'null'
    media_type_breakdown = {('null' if mt is None else str(mt)): count for mt, count in mt_counts.fetchall()}

    # Role breakdown: derive from message columns since Chat has no 'role' column
    # Count messages sent by the user (user_query present) and by the assistant (ai_message present)
    user_msg_count = await db.scalar(
        select(func.count(Chat.id)).where(Chat.user_id == user_id).where(Chat.user_query != None)
    )
    assistant_msg_count = await db.scalar(
        select(func.count(Chat.id)).where(Chat.user_id == user_id).where(Chat.ai_message != None)
    )
    role_breakdown = {
        "user": int(user_msg_count or 0),
        "assistant": int(assistant_msg_count or 0),
    }

    # Messages over time (last 30 days)
    date_30_days_ago = datetime.datetime.now(datetime.timezone.utc) - timedelta(days=30)
    daily_counts = await db.execute(
        select(func.date(Chat.created_at), func.count(Chat.id))
        .where(Chat.user_id == user_id)
        .where(Chat.created_at >= date_30_days_ago)
        .group_by(func.date(Chat.created_at))
        .order_by(func.date(Chat.created_at))
    )
    messages_over_time = [{"date": str(date), "count": count} for date, count in daily_counts.fetchall()]

    # Total characters
    total_characters = await db.scalar(select(func.count(Character.id)).where(Character.user_id == user_id))

    # Most used character
    most_used_character = max(messages_per_character.items(), key=lambda x: x[1])[0] if messages_per_character else ""

    # Prompt usage diversity
    prompt_counts = await db.execute(
        select(Character.prompt)
        .where(Character.user_id == user_id)
    )
    prompt_usage_count = len(set(row[0] for row in prompt_counts.fetchall()))

    # Common traits
    trait_counts = {"gender": {}, "style": {}}
    traits = await db.execute(
        select(Character.gender, Character.style)
        .where(Character.user_id == user_id)
    )
    for gender, style in traits.fetchall():
        trait_counts["gender"][gender] = trait_counts["gender"].get(gender, 0) + 1
        trait_counts["style"][style] = trait_counts["style"].get(style, 0) + 1

    return EngagementStats(
        total_messages=total_messages,
        total_sessions=session_count,
        avg_messages_per_session=round(avg_per_session, 2),
        messages_per_character=messages_per_character,
    media_type_breakdown=media_type_breakdown,
        role_breakdown=role_breakdown,
        messages_over_time=messages_over_time,
        total_characters=total_characters,
        most_used_character=most_used_character,
        prompt_usage_count=prompt_usage_count,
        common_traits=trait_counts
    )