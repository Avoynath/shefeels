from fastapi import APIRouter, Depends, HTTPException
import asyncio
from app.schemas.character import CharacterCreate
from app.api.v1.deps import get_db
from app.api.v1.deps import require_admin
from app.models.character import Character, CharacterStats
from app.models.subscription import CoinTransaction
from app.models.user import User
from app.schemas.character import CharacterCreate, CharacterRead
from app.api.v1.deps import get_current_user
from sqlalchemy.future import select
from sqlalchemy.ext.asyncio import AsyncSession
from app.services.character_media import generate_image
from app.core.aws_s3 import generate_presigned_url, delete_s3_object
from app.models.character_media import CharacterMedia
from app.services.app_config import get_config_value_from_cache
from typing import List, Dict, Optional, Any
from sqlalchemy import func, and_, or_
from app.models.chat import ChatMessage
from sqlalchemy import delete as sql_delete
import urllib.parse
router = APIRouter()


@router.get("/get-all", dependencies=[Depends(require_admin)])
async def list_characters(
    db: AsyncSession = Depends(get_db),
    page: int = 1,
    per_page: int = 100,
    search: Optional[str] = None,
    created_by: Optional[str] = None,
    user_id: Optional[str] = None,
    start_date: Optional[str] = None,
    end_date: Optional[str] = None,
):
    """List characters with optional server-side filtering and pagination.

    Returns a JSON object: { items: [...], total: <int>, page: <int>, per_page: <int> }
    """
    # sanitize pagination params
    page = max(int(page or 1), 1)
    per_page = max(1, min(int(per_page or 100), 500))
    # Select explicit character columns and the user's role as creator_role.
    # Returning Pydantic models from the row._mapping avoids a manual Python loop that
    # re-attaches the role to each Character instance.
    base_select = (
        select(
            Character.id,
            Character.user_id,
            Character.username,
            Character.bio,
            Character.name,
            Character.gender,
            Character.style,
            Character.ethnicity,
            Character.age,
            Character.eye_colour,
            Character.hair_style,
            Character.hair_colour,
            Character.body_type,
            Character.breast_size,
            Character.butt_size,
            Character.dick_size,
            Character.personality,
            Character.voice_type,
            Character.relationship_type,
            Character.clothing,
            Character.special_features,
            Character.privacy,
            Character.image_url_s3,
            Character.updated_at,
            Character.created_at,
            User.role.label("creator_role"),
        )
        .join(User, Character.user_id == User.id)
    )

    # Build WHERE clauses from filters
    where_clauses = []
    if search:
        s = f"%{search}%"
        where_clauses.append(or_(
            Character.name.ilike(s),
            Character.style.ilike(s),
            Character.ethnicity.ilike(s),
            Character.username.ilike(s),
        ))
    if created_by:
        where_clauses.append(User.role == created_by)
    if user_id:
        where_clauses.append(Character.user_id == user_id)
    if start_date:
        try:
            where_clauses.append(Character.updated_at >= start_date)
        except Exception:
            pass
    if end_date:
        try:
            where_clauses.append(Character.updated_at <= end_date)
        except Exception:
            pass

    if where_clauses:
        base_select = base_select.where(and_(*where_clauses))

    # total count
    count_stmt = select(func.count()).select_from(Character).join(User, Character.user_id == User.id)
    if where_clauses:
        count_stmt = count_stmt.where(and_(*where_clauses))
    total_result = await db.execute(count_stmt)
    total = int(total_result.scalar() or 0)

    stmt = base_select.order_by(Character.created_at.desc()).limit(per_page).offset((page - 1) * per_page)
    result = await db.execute(stmt)
    rows = result.all()
    items = []
    for row in rows:
        # row._mapping may contain numeric ids coming from DB - coerce to strings for stability
        mapping = dict(row._mapping)
        for _k in ("id", "user_id"):
            if _k in mapping and not isinstance(mapping[_k], str):
                mapping[_k] = str(mapping[_k])
        # Validate using the mapping/dict to avoid Pydantic string-type errors
        items.append(CharacterRead.model_validate(mapping))

    return {"items": items, "total": total, "page": page, "per_page": per_page}

@router.put("/{character_id}/edit", dependencies=[Depends(require_admin)])
async def edit_character(character_id: str, character_data: CharacterCreate, db: AsyncSession = Depends(get_db)):
    # Normalize path parameter to string to avoid integer/VARCHAR mismatches
    character_id = str(character_id)
    from sqlalchemy import bindparam, String
    stmt = select(Character).where(Character.id == bindparam("cid", type_=String))
    result = await db.execute(stmt, {"cid": character_id})
    character = result.scalar_one_or_none()
    if not character:
        raise HTTPException(status_code=404, detail="Character not found")

    # Image generation/polling removed in this admin endpoint (functionality handled elsewhere).

    # Update all fields from character_data
    for field, value in character_data.model_dump().items():
        setattr(character, field, value)
    await db.commit()
    await db.refresh(character)
    return {"detail": f"Character {character_id} has been updated"}


@router.post("/{character_id}/delete", dependencies=[Depends(require_admin)])
async def delete_character(character_id: str, db: AsyncSession = Depends(get_db)):
    # Normalize path parameter to string to avoid integer/VARCHAR mismatches
    character_id = str(character_id)
    from sqlalchemy import bindparam, String
    stmt = select(Character).where(Character.id == bindparam("cid", type_=String))
    result = await db.execute(stmt, {"cid": character_id})
    character = result.scalar_one_or_none()
    if not character:
        raise HTTPException(status_code=404, detail="Character not found")
    # Attempt to delete main character image from S3 (best-effort)
    try:
        s3_key = getattr(character, 'image_url_s3', None)
        if s3_key:
            await delete_s3_object(s3_key)
    except Exception:
        pass

    # Delete any CharacterMedia objects and their S3 files
    try:
        media_rows = await db.execute(select(CharacterMedia).where(CharacterMedia.character_id == character.id))
        media_items = media_rows.scalars().all()
        for m in media_items:
            try:
                if getattr(m, 's3_path', None):
                    await delete_s3_object(m.s3_path)
            except Exception:
                pass
    except Exception:
        pass
    
    # Remove CharacterMedia records
    try:
        await db.execute(sql_delete(CharacterMedia).where(CharacterMedia.character_id == character.id))
        await db.commit()
    except Exception as e:
        # best-effort: if media records cannot be removed, log the error
        raise HTTPException(status_code=500, detail=f"Failed to delete character media for character {character_id}: {e}")
    
    # Remove dependent chat messages referencing this character to satisfy foreign key
    try:
        # Use a single DELETE statement for efficiency
        await db.execute(sql_delete(ChatMessage).where(ChatMessage.character_id == character.id))
        await db.commit()
    except Exception as e:
        # best-effort: if chat messages cannot be removed, raise a clear error so admin can inspect
        raise HTTPException(status_code=500, detail=f"Failed to delete chat messages referencing character {character_id}: {e}")
    
    # Remove coin transactions referencing this character
    try:
        await db.execute(sql_delete(CoinTransaction).where(CoinTransaction.character_id == character.id))
        await db.commit()
    except Exception as e:
        # best-effort: if coin transactions cannot be removed, raise a clear error so admin can inspect
        raise HTTPException(status_code=500, detail=f"Failed to delete coin transactions referencing character {character_id}: {e}")
    
    # Remove CharacterStats records referencing this character
    try:
        await db.execute(sql_delete(CharacterStats).where(CharacterStats.character_id == character.id))
        await db.commit()
    except Exception as e:
        # best-effort: if character stats cannot be removed, raise a clear error so admin can inspect
        raise HTTPException(status_code=500, detail=f"Failed to delete character stats referencing character {character_id}: {e}")

    # Finally delete the character record
    await db.delete(character)
    await db.commit()

    return {"detail": f"Character {character_id} and related chat messages have been deleted"}


@router.post("/presigned-urls-by-ids", dependencies=[Depends(require_admin)])
async def get_presigned_urls_by_ids(payload: Dict[str, str]):
    """
    Accepts a JSON object mapping ids to S3 values (either full S3 URLs or S3 keys).
    Returns a mapping of the same ids to generated pre-signed GET URLs.
    Example request body: {"1": "s3://bucket/path/to/object", "2": "https://bucket.s3.amazonaws.com/path/to/obj"}
    """
    if not payload:
        raise HTTPException(status_code=400, detail="Payload cannot be empty")

    # Resolve bucket name once to help parse URLs that include the bucket in the path
    # bucket_name = await get_config_value_from_cache("AWS_BUCKET_NAME")

    result = {}
    for id_key, s3_value in payload.items():
        try:
            # # If value looks like a URL, extract the S3 key portion
            # s3_key = None
            # if isinstance(s3_value, str) and (s3_value.startswith("http://") or s3_value.startswith("https://")):
            #     parsed = urllib.parse.urlparse(s3_value)
            #     # Handle virtual-hosted style: bucket.s3.amazonaws.com/key
            #     if parsed.netloc.endswith("s3.amazonaws.com"):
            #         host_bucket = parsed.netloc.split('.')[0]
            #         if host_bucket == bucket_name:
            #             s3_key = parsed.path.lstrip('/')
            #         else:
            #             # path may be /bucket/key
            #             path_parts = parsed.path.lstrip('/').split('/', 1)
            #             if len(path_parts) > 1 and path_parts[0] == bucket_name:
            #                 s3_key = path_parts[1]
            #             else:
            #                 # fallback to path as key
            #                 s3_key = parsed.path.lstrip('/')
            #     else:
            #         # Not an S3-hosted domain (could be CloudFront or custom domain) - use path portion
            #         s3_key = parsed.path.lstrip('/')
            # else:
            #     # Treat value as a raw S3 key
            #     s3_key = s3_value

            # if not s3_key:
            #     raise ValueError(f"Unable to determine S3 key from value: {s3_value}")

            # presigned = await generate_presigned_url(s3_key)
            presigned = await generate_presigned_url(s3_key = s3_value)
            # Ensure returned key is JSON-serializable as the same key type as input (coerce to int when possible)
            try:
                result[int(id_key)] = presigned
            except Exception:
                result[id_key] = presigned
        except Exception as e:
            raise HTTPException(status_code=500, detail=f"Failed to generate presigned url for id {id_key}: {e}")

    return result


