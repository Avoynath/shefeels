from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select
from app.schemas.private_content import PrivateContentPackCreateRequest
from app.api.v1.deps import get_db
from app.api.v1.deps import require_admin
from app.models.character import Character
from app.services.app_config import get_config_value_from_cache
from app.models.private_content import MediaPack, MediaPackMedia
from app.models.character_media import CharacterMedia
from app.schemas.private_content import PrivateContentRequest
from app.models.user import User
from passlib.context import CryptContext
from app.api.v1.deps import get_current_user
from app.core.aws_s3 import generate_presigned_url
from fastapi.responses import JSONResponse

router = APIRouter()
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

@router.post("/create-pack", dependencies=[Depends(require_admin)])
async def create_media_pack(
    payload: PrivateContentPackCreateRequest,
    current_user: User = Depends(require_admin),
    db: AsyncSession = Depends(get_db),
):

    # validate character exists
    q = await db.execute(select(Character).where(Character.id == payload.character_id))
    character = q.scalars().first()
    if not character:
        raise HTTPException(status_code=404, detail="Character not found")

    # resolve thumbnail s3 path if thumbnail_image_id provided
    thumbnail_s3_path = None
    if payload.thumbnail_image_id:
        thumb_q = await db.execute(select(CharacterMedia).where(CharacterMedia.id == payload.thumbnail_image_id))
        thumb = thumb_q.scalars().first()
        if not thumb:
            raise HTTPException(status_code=404, detail="Thumbnail image not found")
        thumbnail_s3_path = getattr(thumb, "s3_path", None)

    # validate media ids in bulk and compute counts
    num_images = 0
    num_videos = 0
    if payload.list_media_ids:
        q_med = await db.execute(select(CharacterMedia).where(CharacterMedia.id.in_(payload.list_media_ids)))
        fetched_medias = q_med.scalars().all()
        fetched_ids = {m.id for m in fetched_medias}
        # check for any missing ids
        missing = [m_id for m_id in payload.list_media_ids if m_id not in fetched_ids]
        if missing:
            raise HTTPException(status_code=404, detail=f"Media id not found: {missing[0]}")

        for m in fetched_medias:
            mtype = (getattr(m, "media_type", "") or "").lower()
            if mtype == "image":
                num_images += 1
            elif mtype == "video":
                num_videos += 1

    # create media pack with accurate counts
    pack = MediaPack(
        character_id=payload.character_id,
        created_by=current_user.id if current_user else None,
        name=payload.pack_name,
        description=payload.pack_description,
        price_tokens=payload.tokens,
        is_active=payload.is_active if payload.is_active is not None else True,
        thumbnail_s3_path=thumbnail_s3_path,
        num_images=num_images,
        num_videos=num_videos,
    )

    db.add(pack)
    # flush so pack.id is available for related rows
    await db.flush()

    # create media mapping rows (preserve order/duplicates from payload)
    if payload.list_media_ids:
        for media_id in payload.list_media_ids:
            mapping = MediaPackMedia(media_pack_id=pack.id, character_media_id=media_id)
            db.add(mapping)

    await db.commit()
    # refresh pack to ensure any defaults/relationships are loaded
    await db.refresh(pack)

    return pack

@router.post("/get-character-media", status_code=200, dependencies=[Depends(require_admin)])
async def get_character_media(
    payload: PrivateContentRequest,
    user=Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    character_id = payload.character_id
    # Fetch media for the current user with character information
    stmt = (
        select(CharacterMedia, Character)
        .outerjoin(Character, CharacterMedia.character_id == Character.id)
    .where((CharacterMedia.user_id == user.id) & (CharacterMedia.character_id == character_id))
        # Primary ordering: newest created_at first. Secondary ordering by id ensures
        # deterministic results when created_at values are identical.
        .order_by(CharacterMedia.created_at.desc(), CharacterMedia.id.desc())
    )
    result = await db.execute(stmt)
    media_with_characters = result.all()
    
    if not media_with_characters:
        raise HTTPException(status_code=404, detail="No media found")
    
    # Convert ORM objects to JSON-serializable dicts
    media_serialized = []
    for media_obj, character_obj in media_with_characters:
        media_data = {
            "id": media_obj.id,
            "character_id": media_obj.character_id,
            "user_id": media_obj.user_id,
            "media_type": media_obj.media_type,
            "s3_path_gallery": await generate_presigned_url(media_obj.s3_path),
            "mime_type": media_obj.mime_type,
            "created_at": media_obj.created_at.isoformat() if media_obj.created_at is not None else None,
        }
        
        # Add character data for video thumbnails
        if character_obj:
            character_image_url = None
            # Try to get character image URL
            if hasattr(character_obj, 'image_url_s3') and character_obj.image_url_s3:
                character_image_url = await generate_presigned_url(character_obj.image_url_s3)
            elif hasattr(character_obj, 'image_url') and character_obj.image_url:
                character_image_url = character_obj.image_url
            elif hasattr(character_obj, 'img') and character_obj.img:
                character_image_url = character_obj.img
                
            media_data["character"] = {
                "id": character_obj.id,
                "name": character_obj.name,
                "image_url_s3": character_image_url,
                "image_url": character_image_url,
                "img": character_image_url
            }

        media_serialized.append(media_data)

    # Provide backward-compatible keys so older frontend bundles that expect
    # `images` or `data` or `videos` still work.
    images_list = [m for m in media_serialized if m.get('media_type') == 'image']
    videos_list = [m for m in media_serialized if m.get('media_type') == 'video']
    # Backwards-compatibility: older frontends prefer `images`. If there are
    # image items, return `images` as a combined list of images followed by
    # videos so the gallery will display both. If there are no image items,
    # return `images: None` so very old bundles will fall back to `data`.
    if len(images_list) > 0:
        # Preserve original ordering relative to media_serialized where
        # possible: include media items from media_serialized that are
        # images or videos, preserving their original sort order.
        images_and_videos = [m for m in media_serialized if m.get('media_type') in ('image', 'video')]
        images_key = images_and_videos
    else:
        # No image items — return videos as `images` so older frontends that
        # only read `images` will still display recent videos.
        images_key = videos_list or []
    return JSONResponse(
        content={
            "message": "Media retrieved successfully",
            "media": media_serialized,
            "images": images_key,
            "videos": videos_list,
            "data": media_serialized,
        },
        status_code=200,
    )

