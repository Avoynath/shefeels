"""
Character endpoints for AI Friend Chatbot.
"""
from fastapi import APIRouter, Request, Depends, HTTPException, UploadFile, File, Form
from fastapi.responses import JSONResponse
from sqlalchemy import func, select, delete, insert, cast, String
from app.schemas.character_media import ImageCreate, VideoCreate
from app.api.v1.deps import get_current_user, get_headers_api
from app.core.database import get_db
from app.models.character_media import CharacterMedia
from app.models.character import Character
from app.models.user import User
from app.services.chat import get_compliance_check
from app.schemas.character import CharacterIdIn
from app.core.config import settings
from app.core.aws_s3 import upload_to_s3_file, get_file_from_s3_url
from app.services.character_media import build_image_prompt, fetch_image_as_base64,\
                generate_image, generate_filename_timestamped, generate_video, face_swap,\
                 modify_character_prompt_for_image_generation, build_prompt_from_json, _normalize_ext
from app.core.aws_s3 import generate_presigned_url
from app.services.app_config import get_config_value_from_cache
from sqlalchemy.ext.asyncio import AsyncSession
import base64
from io import BytesIO
import asyncio
import requests
import httpx
import uuid
#from starlette.responses import JSONResponse
from typing import Any, Dict, List
#from starlette.datastructures import UploadFile
from starlette.datastructures import UploadFile as StarletteUploadFile
import os, re
import tempfile
from fastapi.responses import StreamingResponse
from app.services.subscription import check_user_wallet, deduct_user_coins
from app.services.sse_broadcast import get_broadcaster

router = APIRouter()

# @router.post("/create-image")
# async def create_image(
#     image: ImageCreate,
#     user=Depends(get_current_user),
#     db: AsyncSession = Depends(get_db)
# ):
#     await check_user_wallet(db, user.id, "image")
#     positive_prompt = await get_config_value_from_cache("IMAGE_POSITIVE_PROMPT")
#     negative_prompt = await get_config_value_from_cache("IMAGE_NEGATIVE_PROMPT")
    
#     print("=" * 80)
#     print("CHARACTER IMAGE GENERATION - USING STORED JSON PROMPT OR TEXT-ONLY PROMPT")
#     print(f"character_id: {image.character_id}")
#     print("=" * 80)
    
#     final_prompt = None
#     db_character = None

#     # If a character_id is provided, fetch stored prompt and build final prompt
#     if getattr(image, 'character_id', None):
#         stmt = select(Character).where(Character.id == image.character_id)
#         result = await db.execute(stmt)
#         db_character = result.scalar_one_or_none()

#         if not db_character:
#             raise HTTPException(status_code=404, detail="Character not found")

#         # Get the stored prompt (could be JSON or old text format)
#         stored_prompt = db_character.prompt or ""
#         print(f"STORED PROMPT TYPE: {type(stored_prompt)}")
#         print(f"STORED PROMPT LENGTH: {len(stored_prompt)} characters")
#         print(f"STORED PROMPT PREVIEW: {stored_prompt[:200]}...")

#         # Try to build prompt from JSON format
#         try:
#             if stored_prompt.strip().startswith('{'):
#                 # New JSON format
#                 print("✅ USING JSON PROMPT FORMAT")
#                 final_prompt = build_prompt_from_json(
#                     prompt_json=stored_prompt,
#                     new_pose=image.pose,
#                     new_background=image.background,
#                     new_outfit=image.outfit
#                 )
#             else:
#                 # Old text format - use modification approach
#                 print("⚠️ USING OLD TEXT PROMPT FORMAT - FALLBACK")
#                 final_prompt = await modify_character_prompt_for_image_generation(
#                     original_prompt=stored_prompt,
#                     new_pose=image.pose,
#                     new_background=image.background,
#                     new_outfit=image.outfit
#                 )
#         except Exception as e:
#             print(f"❌ ERROR: Failed to process stored prompt: {e}")
#             # Ultimate fallback - rebuild from character attributes
#             print("🔄 ULTIMATE FALLBACK: Rebuilding from character attributes")
#             print(f"🎨 Style from request: '{image.character_style}'")
#             print(f"🎨 Style from database: '{db_character.style}'")
#             final_style = (image.character_style and image.character_style.strip()) or (db_character.style and db_character.style.strip()) or "realistic"
#             print(f"🎯 Final style to use: '{final_style}'")

#             final_prompt = await build_image_prompt(
#                 character_name=db_character.name,
#                 character_age=db_character.age or 25,
#                 character_gender=db_character.gender,
#                 character_style=final_style,
#                 character_bio=db_character.bio or "",
#                 character_ethnicity=db_character.ethnicity or "",
#                 character_body_type=db_character.body_type or "",
#                 character_eye_colour=db_character.eye_colour or "",
#                 character_hair_style=db_character.hair_style or "",
#                 character_hair_colour=db_character.hair_colour or "",
#                 pose=image.pose,
#                 background=image.background,
#                 outfit=image.outfit,
#                 positive_prompt=positive_prompt or "",
#                 negative_prompt=negative_prompt or "",
#             )
#     else:
#         # No character: use custom prompt directly (positive_prompt contains the user's text prompt)
#         print("TEXT-ONLY IMAGE GENERATION: No character provided, using custom prompt as-is")
#         final_prompt = (getattr(image, 'positive_prompt', '') or '').strip()
#         status, result = await get_compliance_check(final_prompt)
#         if status is False:
#             raise HTTPException(status_code=400, detail=f"Image generation is not compliant: {result}")
                
#         if not final_prompt:
#             # If user didn't provide a prompt, return error
#             raise HTTPException(status_code=400, detail="No prompt provided for text-only image generation")
    
#     print(f"🎯 FINAL PROMPT: {final_prompt[:200]}...")
    
#     # Append positive_prompt from request if provided (only if it wasn't the sole prompt in text-only mode)
#     request_positive_prompt = getattr(image, 'positive_prompt', None)

#     if request_positive_prompt:
#         print(f"REQUEST POSITIVE_PROMPT PROVIDED: '{request_positive_prompt}'")
#         status, result = await get_compliance_check(request_positive_prompt)
#         if status is False:
#             raise HTTPException(status_code=400, detail=f"Image generation is not compliant: {result}")
                    
#     if db_character and request_positive_prompt and request_positive_prompt.strip():
#         final_prompt = f"{final_prompt}, {request_positive_prompt.strip()}"
#         print(f"✨ APPENDED REQUEST POSITIVE_PROMPT: '{request_positive_prompt}'")
    
#     # Use the final_prompt for image generation
    
#     print(f"MODIFIED PROMPT FOR IMAGE GENERATION: '{final_prompt}'")
#     print("=" * 80)

#     # For character-based flows we may perform face-swap later; fetch original character image if available
#     original_character_base64 = None
#     if db_character and getattr(image, 'image_s3_url', None):
#         try:
#             original_character_base64 = await fetch_image_as_base64(image.image_s3_url)
#             print(f"Original character image fetched for face swap, base64 length: {len(original_character_base64) if original_character_base64 else 0}")
#         except Exception as e:
#             print(f"Warning: failed to fetch original character image: {e}")

#     # ========== INITIAL IMAGE FEATURE (TOGGLE POINT) ==========
#     # Handle optional initial_image parameter for image-to-image generation
#     initial_image_base64 = getattr(image, 'initial_image', None)
#     use_initial_image = False
    
#     if use_initial_image:
#         print(f"🖼️ INITIAL IMAGE PROVIDED: Using image-to-image generation")
#         print(f"Initial image base64 length: {len(initial_image_base64)}")
#         generation_mode = "image-to-image"
#     else:
#         print(f"📝 NO INITIAL IMAGE: Using text-to-image generation")
#         initial_image_base64 = None
#         generation_mode = "text-to-image"
    
#     print(f"Generation mode: {generation_mode}")
#     # ========== END INITIAL IMAGE FEATURE ==========

#     # number of parallel images to request
#     num_images = image.num_images if hasattr(image, "num_images") else 1
#     print(f"Generating {num_images} image(s)")

#     async def generate_and_face_swap(idx: int):
#         """
#         2-Step process: 
#         1. Generate image using modified character prompt (no initial image)
#         2. Face swap original character face onto generated image
#         """
#         print(f"\n--- PROCESSING IMAGE {idx} ---")
#         print(f"STEP 1: Generating image using {generation_mode}")
#         print(f"Prompt: '{final_prompt}'")
#         print("Parameters:")
#         print(f"  - num_images: 1")
#         print(f"  - initial_image: {'PROVIDED' if initial_image_base64 else 'None'}")
        
#         # Step 1: Generate image using either text-to-image or image-to-image
#         # Pass ai_model from request (or default to backend config). For text-only flow we expect 'fluxnsfw' from frontend.
#         ai_model_to_use = getattr(image, 'ai_model', None)
#         response = await generate_image(
#             final_prompt,  # Use the final character prompt
#             num_images=1,
#             initial_image=initial_image_base64,  # Use initial image if provided, None for text-to-image
#             ai_model='xl_pornai',
#         )
        
#         print(f"Image generation response status: {response.status_code}")
        
#         if response.status_code != 200:
#             print(f"ERROR: Image generation failed at index {idx}")
#             raise HTTPException(status_code=500, detail=f"Image generation failed at index {idx}")

#         json_resp = response.json()
#         generated_image_base64 = json_resp["data"]["images_data"][0]
#         print(f"Generated image base64 length: {len(generated_image_base64)}")
        
#         # Step 2: If we have an original character image, attempt face-swap; otherwise use generated image directly
#         if original_character_base64:
#             try:
#                 print(f"STEP 2: Performing face swap for image {idx}")
#                 face_swap_response = await face_swap(
#                     source_image_base64=original_character_base64,
#                     target_image_base64=generated_image_base64
#                 )
#                 print(f"Face swap response status: {face_swap_response.status_code}")
#                 if face_swap_response.status_code == 200:
#                     face_swap_json = face_swap_response.json()
#                     final_image_base64 = face_swap_json.get("data", {}).get("image_data", generated_image_base64)
#                     print(f"Face swap successful for image {idx}, final image length: {len(final_image_base64)}")
#                 else:
#                     print(f"Face swap failed for image {idx}, using original generated image")
#                     final_image_base64 = generated_image_base64
#             except Exception as e:
#                 print(f"Face swap error: {e}, using generated image")
#                 final_image_base64 = generated_image_base64
#         else:
#             final_image_base64 = generated_image_base64
        
#         print(f"--- COMPLETED IMAGE {idx} ---\n")
        
#         # Convert final image to bytes and upload to S3
#         img_bytes = base64.b64decode(final_image_base64)
#         image_file = BytesIO(img_bytes)

#         user_role = (user.role if user else "USER").lower()
#         user_id = str(user.id)
#         current_name = f"{image.name}_image_{idx}"
#         filename = await generate_filename_timestamped(current_name)
#         s3_key = f"image/{user_role}/{user_id}/{filename}.png"
#         bucket_name = await get_config_value_from_cache("AWS_BUCKET_NAME")
#         s3_key, presigned_s3_url = await upload_to_s3_file(
#             file_obj=image_file,
#             s3_key=s3_key,
#             content_type="image/png",
#             bucket_name=bucket_name,
#         )

#         return {"s3_key": s3_key, "url": presigned_s3_url}

#     # run generation + face swap + s3 upload concurrently
#     tasks = [generate_and_face_swap(i) for i in range(num_images)]
#     results = await asyncio.gather(*tasks)

#     # now save DB records sequentially (safe)
#     list_presigned_images = []
#     media_items = []
#     for r in results:
#         db_character_media = CharacterMedia(
#             user_id=user.id,
#             character_id=image.character_id,
#             media_type="image",
#             s3_path=r["s3_key"],
#         )
#         db.add(db_character_media)
#         await db.commit()
#         await db.refresh(db_character_media)
#         list_presigned_images.append(r["url"])
#         try:
#             presigned = await generate_presigned_url(db_character_media.s3_path)
#         except Exception:
#             presigned = r.get("url")

#         media_obj = {
#             "id": db_character_media.id,
#             "character_id": db_character_media.character_id,
#             "user_id": db_character_media.user_id,
#             "media_type": db_character_media.media_type,
#             "s3_path_gallery": presigned,
#             "mime_type": db_character_media.mime_type,
#             "created_at": db_character_media.created_at.isoformat() if db_character_media.created_at is not None else None,
#         }
#         # attach character thumbnail info if possible
#         if db_character:
#             character_image_url = None
#             if hasattr(db_character, 'image_url_s3') and db_character.image_url_s3:
#                 character_image_url = await generate_presigned_url(db_character.image_url_s3)
#             elif hasattr(db_character, 'image_url') and db_character.image_url:
#                 character_image_url = db_character.image_url
#             elif hasattr(db_character, 'img') and db_character.img:
#                 character_image_url = db_character.img
#             media_obj["character"] = {
#                 "id": db_character.id,
#                 "name": db_character.name,
#                 "image_url_s3": character_image_url,
#                 "image_url": character_image_url,
#                 "img": character_image_url,
#             }

#         media_items.append(media_obj)

#     await deduct_user_coins(db, user.id, image.character_id, "image")
#     # Backwards-compatible response, plus canonical `media` list with metadata
#     resp = {
#         "message": "Images created successfully",
#         "image_paths": list_presigned_images,
#         "media": media_items,
#         "images": media_items,
#         "data": media_items,
#     }

#     # Publish via SSE broadcaster (fire-and-forget)
#     try:
#         broadcaster = get_broadcaster()
#         # publish each media item as an event
#         for m in media_items:
#             # event name 'media.created'
#             await broadcaster.publish('media.created', m)
#     except Exception:
#         # Don't fail the API if broadcasting fails
#         pass

#     return JSONResponse(content=resp, status_code=200)

# @router.post("/create-image")
# async def create_image(
#     image: ImageCreate,
#     user=Depends(get_current_user),
#     db: AsyncSession = Depends(get_db)
# ):
#     await check_user_wallet(db, user.id, "image")
#     positive_prompt = await get_config_value_from_cache("IMAGE_POSITIVE_PROMPT")
#     negative_prompt = await get_config_value_from_cache("IMAGE_NEGATIVE_PROMPT")
    
#     print("=" * 80)
#     print("CHARACTER IMAGE GENERATION - USING STORED JSON PROMPT")
#     print(f"character_id: {image.character_id}")
#     print("=" * 80)
    
#     stmt = select(Character).where(Character.id == image.character_id)
#     result = await db.execute(stmt)
#     db_character = result.scalar_one_or_none()
    
#     if not db_character:
#         raise HTTPException(status_code=404, detail="Character not found")
    
#     # Get the stored prompt (could be JSON or old text format)
#     stored_prompt = db_character.prompt or ""
#     print(f"STORED PROMPT TYPE: {type(stored_prompt)}")
#     print(f"STORED PROMPT LENGTH: {len(stored_prompt)} characters")
#     print(f"STORED PROMPT PREVIEW: {stored_prompt[:200]}...")
    
#     # Try to build prompt from JSON format
#     try:
#         if stored_prompt.strip().startswith('{'):
#             # New JSON format
#             print("✅ USING JSON PROMPT FORMAT")
#             final_prompt = build_prompt_from_json(
#                 prompt_json=stored_prompt,
#                 new_outfit=image.outfit,
#                 new_pose=image.pose,
#                 new_action=image.action,
#                 new_accessories=image.accessories
                
#             )
#         else:
#             # Old text format - use modification approach
#             print("⚠️ USING OLD TEXT PROMPT FORMAT - FALLBACK")
#             final_prompt = await modify_character_prompt_for_image_generation(
#                 original_prompt=stored_prompt,
#                 new_outfit=image.outfit,
#                 new_pose=image.pose,
#                 new_action=image.action,
#                 new_accessories=image.accessories
#             )
#     except Exception as e:
#         print(f"❌ ERROR: Failed to process stored prompt: {e}")
#         # Ultimate fallback - rebuild from character attributes
#         final_style = (db_character.style and db_character.style.strip()) or "realistic"
#         print(f"🎯 Final style to use: '{final_style}'")
        
#         final_prompt = await build_image_prompt(
#             character_name=db_character.name,
#             character_age=db_character.age or 25,
#             character_gender=db_character.gender,
#             character_style=final_style,
#             character_bio=db_character.bio or "",
#             character_ethnicity=db_character.ethnicity or "",
#             character_body_type=db_character.body_type or "",
#             character_eye_colour=db_character.eye_colour or "",
#             character_hair_style=db_character.hair_style or "",
#             character_hair_colour=db_character.hair_colour or "",
#             outfit=image.outfit,
#             pose=image.pose,
#             action=image.action,
#             accessories=image.accessories,
#             positive_prompt=positive_prompt or "",
#             negative_prompt=negative_prompt or "",
#         )
    
#     print(f"🎯 FINAL PROMPT: {final_prompt[:200]}...")
    
#     # Append positive_prompt from request if provided
#     request_positive_prompt = getattr(image, 'positive_prompt', None)
#     if request_positive_prompt and request_positive_prompt.strip():
#         final_prompt = f"{final_prompt}, {request_positive_prompt.strip()}"
#         print(f"✨ APPENDED REQUEST POSITIVE_PROMPT: '{request_positive_prompt}'")
    
#     # Use the final_prompt for image generation
    
#     print(f"MODIFIED PROMPT FOR IMAGE GENERATION: '{final_prompt}'")
#     print("=" * 80)

#     # Get original character image for face swapping
#     original_character_base64 = await fetch_image_as_base64(image.image_s3_url)
#     print(f"Original character image fetched for face swap, base64 length: {len(original_character_base64) if original_character_base64 else 0}")

#     # number of parallel images to request
#     num_images = image.num_images if hasattr(image, "num_images") else 1
#     print(f"Generating {num_images} image(s)")

#     async def generate_and_face_swap(idx: int):
#         """
#         2-Step process: 
#         1. Generate image using modified character prompt (no initial image)
#         2. Face swap original character face onto generated image
#         """
#         print(f"\n--- PROCESSING IMAGE {idx} ---")
#         print(f"STEP 1: Generating image using text-to-image with modified prompt:")
#         print(f"'{final_prompt}'")
#         print("Parameters:")
#         print(f"  - num_images: 1")
#         print(f"  - initial_image: None (text-to-image)")
#         orientation = "portrait"
#         print(f"  - size_orientation: {orientation}")

#         # Step 1: Generate image using modified prompt (text-to-image, not image-to-image)
#         response = await generate_image(
#             final_prompt,  # Use the final character prompt
#             num_images=1,
#             initial_image=None,  # No initial image - pure text-to-image generation
#             size_orientation=orientation,
#         )
        
#         print(f"Image generation response status: {response.status_code}")
        
#         if response.status_code != 200:
#             print(f"ERROR: Image generation failed at index {idx}")
#             raise HTTPException(status_code=500, detail=f"Image generation failed at index {idx}")

#         json_resp = response.json()
#         generated_image_base64 = json_resp["data"]["images_data"][0]
#         print(f"Generated image base64 length: {len(generated_image_base64)}")
        
#         # Step 2: Face swap original character face onto generated image
#         print(f"STEP 2: Performing face swap for image {idx}")
#         print("Face swap parameters:")
#         print(f"  - source_image (character): {len(original_character_base64)} chars")
#         print(f"  - target_image (generated): {len(generated_image_base64)} chars")
        
#         face_swap_response = await face_swap(
#             source_image_base64=original_character_base64,  # Original character face
#             target_image_base64=generated_image_base64      # Newly generated image
#         )
        
#         print(f"Face swap response status: {face_swap_response.status_code}")
        
#         if face_swap_response.status_code != 200:
#             print(f"Face swap failed for image {idx}, using original generated image")
#             # Fallback to original generated image if face swap fails
#             final_image_base64 = generated_image_base64
#         else:
#             face_swap_json = face_swap_response.json()
#             # Extract the face-swapped image
#             final_image_base64 = face_swap_json.get("data", {}).get("image_data", generated_image_base64)
#             print(f"Face swap successful for image {idx}, final image length: {len(final_image_base64)}")
        
#         print(f"--- COMPLETED IMAGE {idx} ---\n")
        
#         # Convert final image to bytes and upload to S3
#         img_bytes = base64.b64decode(final_image_base64)
#         image_file = BytesIO(img_bytes)

#         user_role = (user.role if user else "USER").lower()
#         user_id = str(user.id)
#         current_name = f"{image.name}_image_{idx}"
#         filename = await generate_filename_timestamped(current_name)
#         s3_key = f"image/{user_role}/{user_id}/{filename}.png"
#         bucket_name = await get_config_value_from_cache("AWS_BUCKET_NAME")
#         s3_key, presigned_s3_url = await upload_to_s3_file(
#             file_obj=image_file,
#             s3_key=s3_key,
#             content_type="image/png",
#             bucket_name=bucket_name,
#         )

#         return {"s3_key": s3_key, "url": presigned_s3_url}

#     # run generation + face swap + s3 upload concurrently
#     tasks = [generate_and_face_swap(i) for i in range(num_images)]
#     results = await asyncio.gather(*tasks)

#     # now save DB records sequentially (safe)
#     list_presigned_images = []
#     for r in results:
#         db_character_media = CharacterMedia(
#             user_id=user.id,
#             character_id=image.character_id,
#             media_type="image",
#             s3_path=r["s3_key"],
#         )
#         db.add(db_character_media)
#         await db.commit()
#         await db.refresh(db_character_media)
#         list_presigned_images.append(r["url"])
        
#         await deduct_user_coins(db, user.id, image.character_id, "image")
#     return JSONResponse(
#         content={
#             "message": "Images created successfully",
#             "image_paths": list_presigned_images,
#         },
#         status_code=200,
#     )


@router.post("/create-image")
async def create_image(
    image: ImageCreate,
    user=Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """
    Proxy endpoint to forward an image edit request to Lightspeed's image/edit API.
    - Uploads the provided image to S3 so we have a stored source copy.
    - Calls the external API with the presigned URL (or S3 key) as 'images'.
    - Returns the upstream JSON response to the client.
    """
    await check_user_wallet(db, user.id, "image")
    positive_prompt = await get_config_value_from_cache("IMAGE_POSITIVE_PROMPT")
    negative_prompt = await get_config_value_from_cache("IMAGE_NEGATIVE_PROMPT")
    
    print("=" * 80)
    print("CHARACTER IMAGE GENERATION - USING STORED JSON PROMPT")
    print(f"character_id: {image.character_id}")
    print("=" * 80)
    
    stmt = select(Character).where(Character.id == image.character_id)
    result = await db.execute(stmt)
    db_character = result.scalar_one_or_none()
    
    if not db_character:
        raise HTTPException(status_code=404, detail="Character not found")
    
    # Get the stored prompt (could be JSON or old text format)
    stored_prompt = db_character.prompt or ""
    print(f"STORED PROMPT TYPE: {type(stored_prompt)}")
    print(f"STORED PROMPT LENGTH: {len(stored_prompt)} characters")
    print(f"STORED PROMPT PREVIEW: {stored_prompt[:200]}...")
    
    # Build payload for Lightspeed: API expects an array of image URLs.

    images_value = [image.image_s3_url] 
    
    api_url = await get_config_value_from_cache("IMAGE_EDIT_URL")
    username = await get_config_value_from_cache("PRIVATE_CLOUD_API_USERNAME")
    headers = await get_headers_api()
    output_format = "jpeg"  # or png, etc.

    async def generate_num_images(idx: int):
        payload = {
        "images": images_value,
        "prompt": image.prompt,
        "output_format": output_format,
        "username": username}
        print(f"Lightspeed payload for image {idx}:", payload)
        try:
            async with httpx.AsyncClient(timeout=60) as client:
                resp = await client.post(api_url, json=payload, headers=headers)
                print("Lightspeed response status:", resp.text)
            resp.raise_for_status()
        except httpx.HTTPStatusError as e:
            print("Lightspeed status:", e.response.status_code)
            print("Lightspeed headers:", e.response.headers)
            raise HTTPException(status_code=502, detail=str(e))

        # Parse Lightspeed response and download the result image
        try:
            upstream_json = resp.json()
        except Exception:
            upstream_json = {"result": resp.text}

        # Extract the edited image URL from Lightspeed response
        result_image_url = None
        if upstream_json.get("results") and upstream_json["results"].get("outputs"):
            result_image_url = upstream_json["results"]["outputs"][0]
        elif upstream_json.get("outputs"):
            result_image_url = upstream_json["outputs"][0]

        if result_image_url:
            # Download the edited image from Lightspeed and upload to our S3
            async with httpx.AsyncClient(timeout=60) as client:
                img_resp = await client.get(result_image_url)
                img_resp.raise_for_status()
                result_bytes = img_resp.content
                result_stream = BytesIO(result_bytes)

            # Upload result to S3
            user_role = (user.role if user else "USER").lower()
            user_id = str(user.id)
            current_name = f"{image.name}_image_{idx}"
            filename = await generate_filename_timestamped(current_name)
            s3_key = f"image/{user_role}/{user_id}/{filename}.{output_format}"

            bucket_name = await get_config_value_from_cache("AWS_BUCKET_NAME")
            s3_key, presigned_s3_url = await upload_to_s3_file(
                file_obj=result_stream,
                s3_key=s3_key,
                content_type="image/png",
                bucket_name=bucket_name,
            )

        return {"s3_key": s3_key, "url": presigned_s3_url}

    # run generation + face swap + s3 upload concurrently
    tasks = [generate_num_images(i) for i in range(int(image.num_images))]
    results = await asyncio.gather(*tasks)

    # now save DB records sequentially (safe)
    list_presigned_images = []
    for r in results:
        db_character_media = CharacterMedia(
            user_id=user.id,
            character_id=image.character_id,
            media_type="image",
            s3_path=r["s3_key"],
        )
        db.add(db_character_media)
        await db.commit()
        await db.refresh(db_character_media)
        list_presigned_images.append(r["url"])
        
        await deduct_user_coins(db, user.id, image.character_id, "image")
    return JSONResponse(
        content={
            "message": "Images created successfully",
            "image_paths": list_presigned_images,
        },
        status_code=200,
    )


@router.post("/create-video")
async def create_video(
    video: VideoCreate,
    user=Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    await check_user_wallet(db, user.id, "video", video_duration=int(video.duration))
    
    # Character is now optional for video generation. If a character_id is provided,
    # fetch and validate ownership; otherwise operate in text-only mode.
    character_obj = None
    character_data = {}
    character_image = getattr(video, 'image_url', None)

    if getattr(video, 'character_id', None):
        character = await db.execute(select(Character).where(Character.id == video.character_id))
        character_obj = character.scalar_one_or_none()
        if not character_obj:
            raise HTTPException(status_code=404, detail="Character not found")

        # Check if user owns the character or if it's a default character
        is_admin_character = character_obj.user_id is None
        is_user_character = character_obj.user_id == user.id
        if not (is_admin_character or is_user_character):
            raise HTTPException(status_code=403, detail=f"Access denied to this character. Character belongs to user {character_obj.user_id}, but current user is {user.id}")

        # Build character data for prompt enhancement
        character_data = {
            'character_name': video.character_name or character_obj.name,
            'character_age': video.character_age or character_obj.age,
            'character_gender': video.character_gender or character_obj.gender,
            'character_style': video.character_style or getattr(character_obj, 'style', None),
            'character_bio': video.character_bio or character_obj.bio,
            'character_ethnicity': video.character_ethnicity or getattr(character_obj, 'ethnicity', None),
            'character_body_type': video.character_body_type or getattr(character_obj, 'body_type', None),
            'character_eye_colour': video.character_eye_colour or getattr(character_obj, 'eye_colour', None),
            'character_hair_style': video.character_hair_style or getattr(character_obj, 'hair_style', None),
            'character_hair_colour': video.character_hair_colour or getattr(character_obj, 'hair_colour', None),
        }

        # If image_url not supplied in request, try to read from character object
        if not character_image:
            for img_field in ['image_url_s3', 'image_url', 'img', 'character_image']:
                if hasattr(character_obj, img_field) and getattr(character_obj, img_field):
                    character_image = getattr(character_obj, img_field)
                    break

    # Validate duration (frontend sends 5 or 10 seconds)
    try:
        dur = int(video.duration)
    except Exception:
        dur = 5
    if dur not in (5, 10):
        print(f"⚠️ Invalid duration received: {video.duration}, defaulting to 5")
        dur = 5
    
    # Use coerced duration
    duration_to_use = dur

    try:
        # If no character was provided, require a non-empty prompt
        if not character_obj and (not video.prompt or not video.prompt.strip()):
            raise HTTPException(status_code=400, detail="No prompt provided for text-only video generation")

        print(f"🎬 Starting video generation (character_id={video.character_id}) duration {duration_to_use}s")
        if video.prompt:
            status, result = await get_compliance_check(video.prompt)
            print("status, result:", status, result)
            if status is False:
                print(f"❌ Video prompt compliance failed: {result}")
                raise HTTPException(status_code=400, detail=f"Video generation is not compliant: {result}")
            
        response = await generate_video(
            prompt=video.prompt,
            duration=duration_to_use,
            pose_name=video.pose_name,
            background_name=video.background_name,
            outfit_name=video.outfit_name,
            negative_prompt=video.negative_prompt,
            image_url=character_image,
            character_data=character_data if character_data else None
        )
        
        print(f"📹 Video generation response status: {response.status_code}")
        
        if response.status_code != 200:
            print(f"❌ Video generation failed with status {response.status_code}")
            print(f"Response: {response.text}")
            raise HTTPException(status_code=500, detail=f"Video generation failed: {response.text}")
        
        try:
            json_resp = response.json()
            print(f"✅ Video generation response: {json_resp}")
        except Exception as json_error:
            print(f"❌ Failed to parse JSON response: {json_error}")
            print(f"Raw response: {response.text}")
            raise HTTPException(status_code=500, detail="Invalid JSON response from video generation API")
            
    except HTTPException:
        # Re-raise HTTPExceptions (preserve original status and detail)
        raise
    except Exception as e:
        print(f"❌ Exception during video generation: {str(e)}")
        print(f"Exception type: {type(e)}")
        import traceback
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=f"Video generation error: {str(e)}")
    print(json_resp["data"]["video_url"])
    
    url = json_resp["data"]["video_url"]
    # The video can take a while to be generated and downloaded; use a longer timeout.
    r = requests.get(url, stream=True, timeout=300)
    r.raise_for_status()

    user_role = (user.role if user else "USER").lower()
    user_id = str(user.id)

    # Prepare filenames and temp paths
    filename = await generate_filename_timestamped(video.name)
    video_s3_key = f"video/{user_role}/{user_id}/{filename}.mp4"
    bucket_name = await get_config_value_from_cache("AWS_BUCKET_NAME")

    # Save streamed video to a temporary file so we can both upload and extract a poster
    tmp_video = tempfile.NamedTemporaryFile(delete=False, suffix='.mp4')
    try:
        with tmp_video as f:
            for chunk in r.iter_content(chunk_size=8192):
                if chunk:
                    f.write(chunk)
        # upload video file to S3
        with open(tmp_video.name, 'rb') as vf:
            s3_key, presigned_s3_url = await upload_to_s3_file(
                file_obj=vf,
                s3_key=video_s3_key,
                content_type="video/mp4",
                bucket_name=bucket_name,
            )

        
        # Create the DB record for the video
        db_character_media = CharacterMedia(
            user_id=user.id,
            character_id=video.character_id,
            media_type="video",
            s3_path=s3_key,
            mime_type='video/mp4'
        )
        db.add(db_character_media)
        await db.commit()
        await db.refresh(db_character_media)

        # Clean up temp files
        try:
            if os.path.exists(tmp_video.name):
                os.remove(tmp_video.name)
        except Exception:
            pass

        await deduct_user_coins(db = db, user_id = user.id, character_id= video.character_id, media_type="video", video_duration=duration_to_use)

    except HTTPException:
        # Re-raise HTTPExceptions (preserve original status and detail)
        raise
    finally:
        # Ensure temp video removed on unexpected error paths
        try:
            if os.path.exists(tmp_video.name):
                os.remove(tmp_video.name)
        except Exception:
            pass

    resp = {
        "message": "Video created successfully",
        "video_path": presigned_s3_url,
        "video_id": db_character_media.id if db_character_media is not None else None,
    }

    return JSONResponse(content=resp, status_code=200)


@router.get('/events')
async def events(request: Request, user=Depends(get_current_user)):
    """SSE endpoint that streams media.created events.

    Requires authentication (re-uses get_current_user). Clients should use an
    EventSource connected to this endpoint. For production multi-instance
    deployments, replace the in-memory broadcaster with Redis pub/sub.
    """
    broadcaster = get_broadcaster()

    sid, queue = await broadcaster.subscribe()

    async def event_generator():
        try:
            # Send a simple welcome/comment
            yield 'event: connected\n'
            yield f'data: {{"message":"connected"}}\n\n'
            while True:
                if await request.is_disconnected():
                    break
                try:
                    item = await asyncio.wait_for(queue.get(), timeout=15.0)
                except asyncio.TimeoutError:
                    # send a ping comment to keep connection alive
                    yield ': ping\n\n'
                    continue
                # item is already a JSON string from broadcaster
                # We want to send standard SSE fields: id (optional), event, data
                try:
                    obj = item
                    # item is serialized JSON with event/data
                    parsed = obj
                    # write as a data line containing the serialized object
                    yield f'data: {parsed}\n\n'
                except Exception:
                    # on error, skip
                    continue
        finally:
            await broadcaster.unsubscribe(sid)

    return StreamingResponse(event_generator(), media_type='text/event-stream')


@router.get("/get-users-character-media", status_code=200)
async def get_users_character_images(
    user=Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    # Fetch media for the current user with character information
    stmt = (
        select(CharacterMedia, Character)
        .outerjoin(Character, CharacterMedia.character_id == Character.id)
        .where(CharacterMedia.user_id == user.id)
        # Primary ordering: newest created_at first. Secondary ordering by id ensures
        # deterministic results when created_at values are identical.
        .order_by(CharacterMedia.created_at.desc(), CharacterMedia.id.desc())
    )
    result = await db.execute(stmt)
    media_with_characters = result.all()
    # Helpful debug info to aid troubleshooting when clients report missing media
    try:
        uid = getattr(user, 'id', None)
    except Exception:
        uid = None
    #print(f"get-users-character-chat-media: user={uid} character_id={cid} result_count={len(media_with_characters)}")

    # Return an empty list instead of 404 to make the endpoint robust for clients
    # that expect an empty response when no media exists. This also avoids
    # surfacing a 404 for legitimate (but empty) results.
    if not media_with_characters:
        return JSONResponse(content={"message": "No media found", "media": []}, status_code=200)
    
    # Convert ORM objects to JSON-serializable dicts
    media_serialized = []
    for media_obj, character_obj in media_with_characters:
        media_data = {
            "id": media_obj.id,
            "character_id": media_obj.character_id,
            "user_id": media_obj.user_id,
            "media_type": media_obj.media_type,
            "s3_path_gallery": await generate_presigned_url(media_obj.s3_path),
            "mime_type": media_obj.mime_type,
            "created_at": media_obj.created_at.isoformat() if media_obj.created_at is not None else None,
        }
        
        # Add character data for video thumbnails
        if character_obj:
            character_image_url = None
            # Try to get character image URL
            if hasattr(character_obj, 'image_url_s3') and character_obj.image_url_s3:
                character_image_url = await generate_presigned_url(character_obj.image_url_s3)
            elif hasattr(character_obj, 'image_url') and character_obj.image_url:
                character_image_url = character_obj.image_url
            elif hasattr(character_obj, 'img') and character_obj.img:
                character_image_url = character_obj.img
                
            media_data["character"] = {
                "id": character_obj.id,
                "name": character_obj.name,
                "image_url_s3": character_image_url,
                "image_url": character_image_url,
                "img": character_image_url
            }

        media_serialized.append(media_data)

    # Provide backward-compatible keys so older frontend bundles that expect
    # `images` or `data` or `videos` still work.
    images_list = [m for m in media_serialized if m.get('media_type') == 'image']
    videos_list = [m for m in media_serialized if m.get('media_type') == 'video']
    # Backwards-compatibility: older frontends prefer `images`. If there are
    # image items, return `images` as a combined list of images followed by
    # videos so the gallery will display both. If there are no image items,
    # return `images: None` so very old bundles will fall back to `data`.
    if len(images_list) > 0:
        # Preserve original ordering relative to media_serialized where
        # possible: include media items from media_serialized that are
        # images or videos, preserving their original sort order.
        images_and_videos = [m for m in media_serialized if m.get('media_type') in ('image', 'video')]
        images_key = images_and_videos
    else:
        # No image items — return videos as `images` so older frontends that
        # only read `images` will still display recent videos.
        images_key = videos_list or []
    return JSONResponse(
        content={
            "message": "Media retrieved successfully",
            "media": media_serialized,
            "images": images_key,
            "videos": videos_list,
            "data": media_serialized,
        },
        status_code=200,
    )

@router.post("/get-users-character-chat-media", status_code=200)
async def get_users_character_images(
    character: CharacterIdIn,
    user=Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    # Fetch media for the current user with character information
    # coerce character id to string because DB stores character IDs as VARCHAR
    try:
        cid = str(character.character_id)
    except Exception:
        # invalid id -- return empty result for robustness
        return JSONResponse(content={"message": "No media found", "media": []}, status_code=200)

    stmt = (
        select(CharacterMedia, Character)
        .outerjoin(Character, CharacterMedia.character_id == Character.id)
        .where(CharacterMedia.user_id == user.id)
        .where(CharacterMedia.character_id == cid)
        .where((CharacterMedia.media_type == "chat_image") | (CharacterMedia.media_type == "chat_video"))
        .order_by(CharacterMedia.created_at.desc())
    )
    result = await db.execute(stmt)
    media_with_characters = result.all()
    
    if not media_with_characters:
        raise HTTPException(status_code=404, detail="No media found")
    
    # Convert ORM objects to JSON-serializable dicts
    media_serialized = []
    for media_obj, character_obj in media_with_characters:
        media_data = {
            "id": media_obj.id,
            "character_id": media_obj.character_id,
            "user_id": media_obj.user_id,
            "media_type": media_obj.media_type,
            "s3_path_gallery": await generate_presigned_url(media_obj.s3_path),
            "mime_type": media_obj.mime_type,
            "created_at": media_obj.created_at.isoformat() if media_obj.created_at is not None else None,
        }
        
        # Add character data for video thumbnails
        if character_obj:
            character_image_url = None
            # Try to get character image URL
            if hasattr(character_obj, 'image_url_s3') and character_obj.image_url_s3:
                character_image_url = await generate_presigned_url(character_obj.image_url_s3)
            elif hasattr(character_obj, 'image_url') and character_obj.image_url:
                character_image_url = character_obj.image_url
            elif hasattr(character_obj, 'img') and character_obj.img:
                character_image_url = character_obj.img
                
            media_data["character"] = {
                "id": character_obj.id,
                "name": character_obj.name,
                "image_url_s3": character_image_url,
                "image_url": character_image_url,
                "img": character_image_url
            }

        media_serialized.append(media_data)

    return JSONResponse(
        content={
            "message": "Media retrieved successfully",
            "media": media_serialized
        },
        status_code=200,
    )


@router.get("/get-character-media", status_code=200)
async def get_character_media(
    character_id: int | None = None,
    db: AsyncSession = Depends(get_db)
):
    """Get media items for a specific character (public). If `character_id` is omitted
    return an empty list to avoid request validation errors (422) from clients that
    call this endpoint without the required query parameter.
    """
    # If no character_id provided, return empty result rather than raising 422
    if character_id is None:
        return JSONResponse(content={"message": "No character_id provided", "media": [], "images": [], "videos": [], "data": []}, status_code=200)
    """Get media items for a specific character (public). Returns same shape as other media endpoints."""
    stmt = (
        select(CharacterMedia, Character)
        .outerjoin(Character, CharacterMedia.character_id == Character.id)
        .where(CharacterMedia.character_id == character_id)
        # Ensure deterministic ordering by adding id DESC as a secondary key.
        .order_by(CharacterMedia.created_at.desc(), CharacterMedia.id.desc())
    )
    result = await db.execute(stmt)
    media_with_characters = result.all()

    # Return empty list rather than 404 to simplify frontend handling
    if not media_with_characters:
        return JSONResponse(content={"message": "No media found", "media": [], "images": [], "videos": [], "data": []}, status_code=200)

    media_serialized = []
    for media_obj, character_obj in media_with_characters:
        media_data = {
            "id": media_obj.id,
            "character_id": media_obj.character_id,
            "user_id": media_obj.user_id,
            "media_type": media_obj.media_type,
            "s3_path_gallery": await generate_presigned_url(media_obj.s3_path),
            "mime_type": media_obj.mime_type,
            "created_at": media_obj.created_at.isoformat() if media_obj.created_at is not None else None,
        }

        # Add character thumbnail info when available
        if character_obj:
            character_image_url = None
            if hasattr(character_obj, 'image_url_s3') and character_obj.image_url_s3:
                character_image_url = await generate_presigned_url(character_obj.image_url_s3)
            elif hasattr(character_obj, 'image_url') and character_obj.image_url:
                character_image_url = character_obj.image_url
            elif hasattr(character_obj, 'img') and character_obj.img:
                character_image_url = character_obj.img

            media_data["character"] = {
                "id": character_obj.id,
                "name": character_obj.name,
                "image_url_s3": character_image_url,
                "image_url": character_image_url,
                "img": character_image_url
            }

        media_serialized.append(media_data)

    images_list = [m for m in media_serialized if m.get('media_type') == 'image']
    videos_list = [m for m in media_serialized if m.get('media_type') == 'video']
    if len(images_list) > 0:
        images_and_videos = [m for m in media_serialized if m.get('media_type') in ('image', 'video')]
        images_key = images_and_videos
    else:
        images_key = videos_list or []

    return JSONResponse(
        content={
            "message": "Media retrieved successfully",
            "media": media_serialized,
            "images": images_key,
            "videos": videos_list,
            "data": media_serialized,
        },
        status_code=200,
    )


@router.get("/download-proxy")
async def download_proxy(url: str, name: str | None = None):
    filename = name or "download.bin"

    async def body_iter():
        try:
            async with httpx.AsyncClient(follow_redirects=True, timeout=None) as client:
                # Open and KEEP the stream INSIDE the generator
                async with client.stream("GET", url) as r:
                    # raise if 4xx/5xx before we start yielding
                    r.raise_for_status()
                    async for chunk in r.aiter_bytes():
                        yield chunk
        except Exception as e:
            # Do NOT re-raise from inside the generator; just end the stream.
            print("download-proxy stream error:", e)

    headers = {
        "Content-Type": "application/octet-stream",
        "Content-Disposition": f'attachment; filename="{filename}"',
        # Add Cache-Control as you like; CORS is typically handled by middleware
        "Cache-Control": "no-store",
    }
    return StreamingResponse(body_iter(), headers=headers)
 
@router.get("/get-default-character-media", status_code=200)
async def get_default_character_media(
    db: AsyncSession = Depends(get_db)
):
    # Fetch media uploaded by users with role 'ADMIN' (case-insensitive)
    # Include character information for video thumbnails
    stmt = (
        select(CharacterMedia, Character)
        .join(User, CharacterMedia.user_id == User.id)
        .outerjoin(Character, CharacterMedia.character_id == Character.id)
        # User.role is an ENUM in Postgres; cast to text before calling lower()
        .where(func.lower(cast(User.role, String)) == "admin")
        .order_by(CharacterMedia.created_at.desc())
    )
    result = await db.execute(stmt)
    media_with_characters = result.all()
    
    if not media_with_characters:
        raise HTTPException(status_code=404, detail="No media found")
    
    # Convert ORM objects to JSON-serializable dicts
    media_serialized = []
    for media_obj, character_obj in media_with_characters:
        media_data = {
            "id": media_obj.id,
            "character_id": media_obj.character_id,
            "user_id": media_obj.user_id,
            "media_type": media_obj.media_type,
            "s3_path_gallery": await generate_presigned_url(media_obj.s3_path),
            "mime_type": media_obj.mime_type,
            "created_at": media_obj.created_at.isoformat() if media_obj.created_at is not None else None,
        }
        
        # Add character data for video thumbnails
        if character_obj:
            character_image_url = None
            # Try to get character image URL
            if hasattr(character_obj, 'image_url_s3') and character_obj.image_url_s3:
                character_image_url = await generate_presigned_url(character_obj.image_url_s3)
            elif hasattr(character_obj, 'image_url') and character_obj.image_url:
                character_image_url = character_obj.image_url
            elif hasattr(character_obj, 'img') and character_obj.img:
                character_image_url = character_obj.img
                
            media_data["character"] = {
                "id": character_obj.id,
                "name": character_obj.name,
                "image_url_s3": character_image_url,
                "image_url": character_image_url,
                "img": character_image_url
            }

        media_serialized.append(media_data)

    # Provide backward-compatible keys so older frontend bundles that expect
    # `images` or `data` or `videos` still work.
    images_list = [m for m in media_serialized if m.get('media_type') == 'image']
    videos_list = [m for m in media_serialized if m.get('media_type') == 'video']
    if len(images_list) > 0:
        images_and_videos = [m for m in media_serialized if m.get('media_type') in ('image', 'video')]
        images_key = images_and_videos
    else:
        images_key = videos_list or []
    return JSONResponse(
        content={
            "message": "Media retrieved successfully",
            "media": media_serialized,
            "images": images_key,
            "videos": videos_list,
            "data": media_serialized,
        },
        status_code=200,
    )



