from fastapi import APIRouter, Depends, UploadFile, File, Form, HTTPException
from fastapi import Request
from fastapi.responses import Response, JSONResponse
import aiohttp, uuid, os
from app.services.voice import store_voice_to_s3
from app.services.voice_chat import process_voice_chat
from app.api.v1.deps import get_current_user
from app.core.database import get_db
from sqlalchemy.ext.asyncio import AsyncSession
from fastapi import HTTPException

router = APIRouter()


@router.post("/voice", response_class=Response)
async def voice():
    # TwiML response to record voice input
    return Response(content="""
    <Response>
        <Say voice="Polly.Joanna">Welcome to the AI assistant. Please speak after the beep. We will process your message shortly.</Say>
        <Record action="/process_recording" method="POST" maxLength="20" timeout="3" playBeep="true" />
        <Say>I didn’t receive anything. Goodbye.</Say>
    </Response>
    """, media_type="application/xml")


@router.post("/process_recording")
async def process_recording(request: Request):
    form = await request.form()
    recording_url = form.get("RecordingUrl")
    call_sid = form.get("CallSid")

    # 1. Download Twilio-recorded audio file
    audio_path = f"/tmp/{uuid.uuid4()}.mp3"
    async with aiohttp.ClientSession() as session:
        async with session.get(recording_url + ".mp3") as resp:
            with open(audio_path, "wb") as f:
                f.write(await resp.read())

    # 2. Transcribe audio using your own API
    # placeholder - left for legacy Twilio flow
    return Response(content="<Response><Say>Thank you. Goodbye.</Say></Response>", media_type="application/xml")



@router.post("/chat")
async def voice_chat_endpoint(
    file: UploadFile = File(...),
    character_id: str | None = Form(None),
    session_id: str | None = Form(None),
    user=Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Receive an audio file from the client, transcribe it, generate chat reply, synthesize cloned voice,
    store audio in S3 and persist chat message.
    Returns voice-to-voice response: { input_url, output_url, transcript }
    """
    try:
        content = await file.read()
    except Exception as e:
        raise HTTPException(status_code=400, detail="Failed to read uploaded file")
    try:
        result = await process_voice_chat(user, content, character_id, session_id)
        if not result:
            # Unexpected empty result -> return structured error
            return JSONResponse(status_code=502, content={"error": "voice_processing_failed", "message": "Voice chat processing returned empty result"})
        return JSONResponse(content={"error": None, "text": None, "audio": result})
    except HTTPException as he:
        # Surface upstream/known errors with richer JSON body so frontend can fallback
        code = getattr(he, 'status_code', 502)
        detail = he.detail if hasattr(he, 'detail') else str(he)
        # Map detail to an error key if possible
        err_key = 'unknown_error'
        if isinstance(detail, str):
            if 'stt_failed' in detail:
                err_key = 'stt_failed'
            elif 'chat_backend' in detail:
                err_key = 'chat_failed'
            elif 'tts' in detail:
                err_key = 'tts_failed'
        return JSONResponse(status_code=code, content={"error": err_key, "message": detail})
    except Exception as e:
        # unexpected error -> 500
        return JSONResponse(status_code=500, content={"error": "internal_error", "message": str(e)})

