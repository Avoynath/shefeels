from sqlalchemy.ext.asyncio import AsyncSession, create_async_engine
from sqlalchemy.orm import sessionmaker
from app.core.config import settings
import ssl
SQLALCHEMY_DATABASE_URL = settings.DATABASE_URL
print("SQLALCHEMY_DATABASE_URL:", SQLALCHEMY_DATABASE_URL)

# ssl_ctx = ssl.create_default_context()
# ssl_ctx.check_hostname = False
# ssl_ctx.verify_mode = ssl.CERT_NONE

# Use reasonable pool settings and turn off verbose SQL logging in production.
# These are low-risk changes that make startup quieter and provide a connection
# pool so subsequent requests are faster.
engine = create_async_engine(
    SQLALCHEMY_DATABASE_URL,
    echo=False,
    pool_pre_ping=True,
    future=True,
    #connect_args={"ssl": ssl_ctx},
    pool_size=5,
    max_overflow=10,
)

AsyncSessionLocal = sessionmaker(engine, class_=AsyncSession, expire_on_commit=False)

async def get_db():
    async with AsyncSessionLocal() as session:
        yield session
